# NETPULSE AI - PowerShell Startup Script
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $SCRIPT_DIR

if (-not (Test-Path "venv\Scripts\python.exe")) {
    Write-Host "[ERROR] venv not found! Please run .\setup.bat or .\setup.ps1 first." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
}

Write-Host "Starting Backend API..." -ForegroundColor Cyan
Start-Process powershell -ArgumentList "-NoExit", "-Command", "& '$SCRIPT_DIR\venv\Scripts\python.exe' -m uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload"

Start-Sleep -Seconds 3

Write-Host "Starting Frontend UI..." -ForegroundColor Cyan
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$SCRIPT_DIR\frontend'; npm run dev"

Start-Sleep -Seconds 3

Start-Process "http://localhost:5173"

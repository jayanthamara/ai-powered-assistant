/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        noc: {
          950: '#070B14',
          900: '#0B1324',
          850: '#0F1A30',
          800: '#142240',
          750: '#1B2C52',
          700: '#233766',
          border: '#1E2F52',
          borderLight: '#2D416E',
          cyan: '#00F0FF',
          blue: '#38BDF8',
          green: '#10B981',
          amber: '#F59E0B',
          red: '#EF4444',
          purple: '#8B5CF6'
        }
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'Courier New', 'monospace'],
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      }
    },
  },
  plugins: [],
}

import React from 'react';
import {
  Activity,
  Search,
  AlertOctagon,
  HeartPulse,
  ShieldAlert,
  Database,
  TrendingUp,
  Award,
  MessageSquare,
  Settings,
  Radio,
  Server
} from 'lucide-react';
import { CopilotWidget } from '../components/CopilotWidget';

interface Props {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  apiHealthy: boolean;
  children: React.ReactNode;
}

const NAV_ITEMS = [
  { id: 'overview', label: 'Overview', icon: Activity },
  { id: 'investigate', label: 'Investigate', icon: Search, badge: 'PRIMARY' },
  { id: 'incidents', label: 'Incidents', icon: AlertOctagon },
  { id: 'network_health', label: 'Network Health', icon: HeartPulse },
  { id: 'risk_analysis', label: 'Risk Analysis', icon: ShieldAlert },
  { id: 'historical_cases', label: 'Historical Cases', icon: Database },
  { id: 'predictions', label: 'Predictions', icon: TrendingUp },
  { id: 'evaluation', label: 'Evaluation', icon: Award },
  { id: 'feedback', label: 'Feedback', icon: MessageSquare },
  { id: 'system', label: 'System', icon: Settings },
];

export const AppLayout: React.FC<Props> = ({
  currentTab,
  onSelectTab,
  apiHealthy,
  children
}) => {
  return (
    <div className="flex h-screen w-screen overflow-hidden bg-noc-950 text-slate-100 font-sans">
      {/* LEFT SIDEBAR */}
      <aside className="w-64 bg-noc-900 border-r border-noc-border flex flex-col justify-between shrink-0 select-none">
        <div>
          {/* Logo Brand Header */}
          <div className="h-16 px-5 border-b border-noc-border flex items-center justify-between bg-noc-850">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-sm bg-cyan-950 border border-cyan-500/70 flex items-center justify-center text-cyan-400 shadow-[0_0_12px_rgba(0,240,255,0.25)]">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <span className="text-base font-extrabold font-mono tracking-wider text-white">
                  NETPULSE <span className="text-cyan-400">AI</span>
                </span>
                <span className="block text-[9px] text-slate-400 font-mono tracking-widest uppercase">
                  5G NetOps Command Center
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="p-3 space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium rounded-sm transition-all text-left ${
                    isActive
                      ? 'bg-cyan-950/60 text-cyan-300 border-l-3 border-l-cyan-400 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-noc-850'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold tracking-wider rounded-xs bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* BOTTOM TELEMETRY STATUS BAR */}
        <div className="p-3.5 border-t border-noc-border bg-noc-950/60 text-[11px] font-mono">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-slate-400">
              <Server className="w-3.5 h-3.5 text-slate-500" /> API Gateway
            </span>
            <span className="flex items-center gap-1 text-emerald-400 font-semibold">
              <span className={`w-2 h-2 rounded-full ${apiHealthy ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
              {apiHealthy ? 'ONLINE (8000)' : 'CHECKING'}
            </span>
          </div>
        </div>
      </aside>

      {/* MAIN VIEWPORT */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header */}
        <header className="h-16 px-6 border-b border-noc-border bg-noc-900/90 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <h1 className="text-sm font-bold font-mono tracking-wider text-slate-200 uppercase flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              Network Operations Center — Telemetry Console
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-sm bg-noc-800 text-slate-400 border border-noc-border font-mono">
              CLUSTER: IND-METRO-5G
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">TIME:</span>
              <span className="text-slate-300">{new Date().toLocaleTimeString()}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">SLA:</span>
              <span className="text-emerald-400 font-semibold">99.98% OK</span>
            </div>
          </div>
        </header>

        {/* Content View */}
        <main className="flex-1 overflow-y-auto p-6 bg-noc-950 bg-grid-pattern">
          {children}
        </main>
      </div>

      {/* GLOBAL FLOATING AI COPILOT CHATBOT */}
      <CopilotWidget onNavigateToInvestigate={() => onSelectTab('investigate')} />
    </div>
  );
};

import React, { useState } from 'react';
import {
  Search,
  Sparkles,
  AlertTriangle,
  Activity,
  Layers,
  ArrowRight,
  ShieldAlert,
  ThumbsUp,
  ThumbsDown,
  CheckCircle,
  XCircle,
  Clock,
  Radio,
  Share2,
  Sliders,
  Check,
  Send,
  TrendingUp
} from 'lucide-react';

import { InvestigationResult, SimilarCase } from '../types';
import { runInvestigation, submitOperatorFeedback, fetchFilters } from '../services/api';
import { MetricCard } from '../components/MetricCard';
import { SeverityBadge } from '../components/SeverityBadge';
import { RiskGauge, HorizontalBarChart } from '../components/SimpleCharts';
import { CaseDetailModal } from '../components/CaseDetailModal';

const SAMPLE_QUERIES = [
  "Multiple cells in Minneapolis MN are experiencing high latency, packet loss, reduced throughput and declining handover success. Find similar historical incidents and recommend corrective actions.",
  "Several cells have increasing alarms and poor service quality. What could be causing it?",
  "Handover success is declining and fault occurrence is increasing in state MN during Winter. What corrective actions should be considered?",
  "Find high-risk network conditions with poor signal strength and high call drop rate.",
  "Show historical incidents similar to high latency and packet loss during Winter."
];

export const InvestigatePage: React.FC = () => {
  const [query, setQuery] = useState(SAMPLE_QUERIES[0]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<any | null>(null);
  const [selectedCase, setSelectedCase] = useState<SimilarCase | null>(null);

  // Metadata Filter State
  const [filterState, setFilterState] = useState('');
  const [filterSeason, setFilterSeason] = useState('');
  const [filterWeather, setFilterWeather] = useState('');
  const [filterVocab, setFilterVocab] = useState<{ states: string[]; seasons: string[]; weather: string[] }>({
    states: [],
    seasons: ['Winter', 'Spring', 'Summer', 'Fall'],
    weather: ['Clear', 'Clouds', 'Rain', 'Snow']
  });

  // Operator Feedback State
  const [diagFeedback, setDiagFeedback] = useState<'Helpful' | 'Not Helpful' | null>(null);
  const [recFeedback, setRecFeedback] = useState<'Correct Diagnosis' | 'Incorrect Diagnosis' | null>(null);
  const [comment, setComment] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  React.useEffect(() => {
    fetchFilters()
      .then((data) => {
        setFilterVocab({
          states: data.states || [],
          seasons: data.seasons || ['Winter', 'Spring', 'Summer', 'Fall'],
          weather: data.weather || ['Clear', 'Clouds', 'Rain', 'Snow']
        });
      })
      .catch(console.error);
  }, []);

  const handleAnalyze = async (searchQuery?: string) => {
    const q = searchQuery || query;
    if (!q.trim()) return;
    setLoading(true);
    setError(null);
    setFeedbackSubmitted(false);
    setDiagFeedback(null);
    setRecFeedback(null);

    const activeFilters: Record<string, any> = {};
    if (filterState) activeFilters.state = filterState;
    if (filterSeason) activeFilters.season = filterSeason;
    if (filterWeather) activeFilters.weather = filterWeather;

    try {
      const data = await runInvestigation(q, Object.keys(activeFilters).length > 0 ? activeFilters : undefined);
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Investigation failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSendFeedback = async () => {
    if (!diagFeedback && !recFeedback) return;
    try {
      await submitOperatorFeedback({
        query: result?.query || query,
        diagnosis_feedback: diagFeedback || 'Helpful',
        recommendation_feedback: recFeedback || undefined,
        user_comment: comment || undefined,
        grounding_rating: result?.evaluation.grounding_score || 1.0,
        case_id: result?.similar_cases[0]?.incident_id
      });
      setFeedbackSubmitted(true);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* SECTION HEADER & INPUT */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
              <Search className="w-5 h-5 text-cyan-400" />
              INVESTIGATE NETWORK CONDITION
            </h2>
            <p className="text-xs text-slate-400">
              Enter operational symptoms, telemetry anomalies, or geographic cell queries for multi-agent diagnostic synthesis.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400">RAG ENGINE:</span>
            <span className="text-xs px-2.5 py-0.5 rounded-sm bg-cyan-950 text-cyan-300 border border-cyan-700/50 font-mono">
              HYBRID RAG (CHROMA PERSISTENT + BM25 + RERANKER)
            </span>
          </div>
        </div>

        {/* Natural Language Query Box */}
        <div className="p-3 bg-noc-900 border border-noc-border rounded-sm space-y-3 shadow-lg">
          <div className="relative">
            <textarea
              id="telecom-query-input"
              rows={3}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Describe a network condition, incident, or problem (e.g., High latency and packet loss in Hyderabad with declining handover success...)"
              className="w-full bg-noc-950 border border-noc-border/80 rounded-sm p-3.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-cyan-400 font-mono leading-relaxed resize-none"
            />
          </div>

          {/* Metadata Filter Controls */}
          <div className="flex flex-wrap items-center gap-3 pt-1 pb-1 border-t border-noc-border/40 text-xs font-mono text-slate-400">
            <span className="text-[11px] uppercase tracking-wider text-slate-500">HARD METADATA FILTERS:</span>
            <div className="flex items-center gap-1.5">
              <span>STATE:</span>
              <select
                value={filterState}
                onChange={(e) => setFilterState(e.target.value)}
                className="bg-noc-950 border border-noc-border text-slate-200 rounded-xs px-2 py-0.5 focus:outline-hidden cursor-pointer"
              >
                <option value="">All States</option>
                {filterVocab.states.map((st) => (
                  <option key={st} value={st}>{st}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-1.5">
              <span>SEASON:</span>
              <select
                value={filterSeason}
                onChange={(e) => setFilterSeason(e.target.value)}
                className="bg-noc-950 border border-noc-border text-slate-200 rounded-xs px-2 py-0.5 focus:outline-hidden cursor-pointer"
              >
                <option value="">All Seasons</option>
                {filterVocab.seasons.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-1.5">
              <span>WEATHER:</span>
              <select
                value={filterWeather}
                onChange={(e) => setFilterWeather(e.target.value)}
                className="bg-noc-950 border border-noc-border text-slate-200 rounded-xs px-2 py-0.5 focus:outline-hidden cursor-pointer"
              >
                <option value="">All Weather</option>
                {filterVocab.weather.map((w) => (
                  <option key={w} value={w}>{w}</option>
                ))}
              </select>
            </div>

            {(filterState || filterSeason || filterWeather) && (
              <button
                onClick={() => {
                  setFilterState('');
                  setFilterSeason('');
                  setFilterWeather('');
                }}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer ml-auto"
              >
                Clear Filters
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Quick Sample Queries */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mr-1">
                Sample Scenarios:
              </span>
              {SAMPLE_QUERIES.map((sq, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setQuery(sq);
                    handleAnalyze(sq);
                  }}
                  className="px-2.5 py-1 text-[11px] bg-noc-850 hover:bg-noc-800 text-slate-300 hover:text-cyan-300 border border-noc-border/70 rounded-xs transition-colors font-mono truncate max-w-[200px]"
                  title={sq}
                >
                  Scenario #{idx + 1}
                </button>
              ))}
            </div>

            {/* Execute Button */}
            <button
              id="analyze-network-button"
              disabled={loading || !query.trim()}
              onClick={() => handleAnalyze()}
              className="px-6 py-2 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-black font-mono font-bold text-xs uppercase tracking-wider rounded-sm flex items-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.35)] transition-all cursor-pointer"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  ANALYZING TELEMETRY...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  ANALYZE NETWORK
                </>
              )}
            </button>
          </div>
        </div>

        {/* Filter Status Alert Banner */}
        {result?.filter_status === 'no_match' && (
          <div className="p-3 bg-amber-950/40 border border-amber-600/70 rounded-sm text-amber-300 text-xs font-mono flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Filter Status: NO_MATCH.</strong> Selected hard metadata filters matched 0 historical records. Strict filtering was preserved (unfiltered records are never silently returned).
            </span>
          </div>
        )}

        {result?.filter_status === 'applied' && (
          <div className="p-2.5 bg-cyan-950/30 border border-cyan-800/50 rounded-sm text-cyan-300 text-xs font-mono flex items-center gap-2">
            <Check className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              <strong>Filter Status: APPLIED.</strong> Hard categorical constraints successfully matched {result.similar_cases?.length || 0} candidate incident records.
            </span>
          </div>
        )}

        {error && (
          <div className="p-3 bg-red-950/40 border border-red-700/60 rounded-sm text-red-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* SKELETON LOADER STATE */}
      {loading && (
        <div className="space-y-4 animate-pulse">
          <div className="grid grid-cols-12 gap-4">
            <div className="col-span-5 h-64 bg-noc-900 border border-noc-border rounded-sm" />
            <div className="col-span-4 h-64 bg-noc-900 border border-noc-border rounded-sm" />
            <div className="col-span-3 h-64 bg-noc-900 border border-noc-border rounded-sm" />
          </div>
          <div className="grid grid-cols-6 gap-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-20 bg-noc-900 border border-noc-border rounded-sm" />
            ))}
          </div>
        </div>
      )}

      {/* INVESTIGATION RESULTS VIEW */}
      {result && !loading && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* TOP THREE TIERS: DIAGNOSIS | ROOT CAUSE | RISK GAUGE */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* LEFT: Incident Diagnosis (5 cols) */}
            <div className="lg:col-span-5 bg-noc-900 border border-noc-border p-4 rounded-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-noc-border">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                      OPERATIONAL DIAGNOSIS
                    </span>
                  </div>
                  <SeverityBadge severity={result.incident.severity} size="sm" />
                </div>

                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm font-bold font-mono text-cyan-300">
                    {result.incident.type}
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-xs bg-noc-850 text-slate-400 border border-noc-border">
                    CONFIDENCE: {Math.round(result.incident.confidence * 100)}%
                  </span>
                </div>

                {/* Grounding & LLM Judge Evaluation Rubric */}
                <div className="flex flex-wrap items-center gap-2 mb-3 text-[11px] font-mono">
                  <span className="text-slate-400">LLM JUDGE:</span>
                  <span className={`px-2 py-0.5 rounded-xs font-bold text-[10px] ${
                    result.evaluation.decision === 'FAIL'
                      ? 'bg-red-950 text-red-400 border border-red-700'
                      : result.evaluation.decision === 'WARN'
                      ? 'bg-amber-950 text-amber-400 border border-amber-700'
                      : 'bg-emerald-950 text-emerald-400 border border-emerald-700'
                  }`}>
                    {result.evaluation.decision || 'PASS'}
                  </span>
                  <span className="text-slate-600">|</span>
                  <span className="text-slate-400">FAITHFULNESS:</span>
                  <span className="text-cyan-300 font-bold">
                    {Math.round(((result.evaluation.faithfulness ?? result.evaluation.grounding_score) || 0) * 100)}%
                  </span>
                  <span className="text-slate-600">|</span>
                  <span className="text-slate-400">GROUNDING:</span>
                  <span className="text-emerald-400 font-bold">
                    {Math.round((result.evaluation.grounding_score || 0) * 100)}%
                  </span>
                </div>

                {/* Narrative Diagnosis */}
                <div className="text-xs text-slate-300 leading-relaxed space-y-2 font-sans bg-noc-950/60 p-3 rounded-xs border border-noc-border/50">
                  {result.diagnosis.split('\n\n').map((paragraph, idx) => (
                    <p key={idx}>{paragraph}</p>
                  ))}
                </div>
              </div>

              {/* Trigger Factors Tags */}
              <div className="mt-3 pt-2 border-t border-noc-border/60">
                <span className="text-[10px] text-slate-400 font-mono uppercase block mb-1">
                  Triggering Telemetry Factors:
                </span>
                <div className="flex flex-wrap gap-1">
                  {result.incident.triggering_factors.map((f, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 bg-noc-850 border border-noc-border text-slate-300 rounded-xs text-[10px] font-mono"
                    >
                      {f}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* CENTER: Root Cause Analysis (4 cols) */}
            <div className="lg:col-span-4 bg-noc-900 border border-noc-border p-4 rounded-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-noc-border">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                      ROOT CAUSE ANALYSIS (RCA)
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">LIKELIHOOD</span>
                </div>

                {/* Ranked Horizontal RCA Bars */}
                <HorizontalBarChart
                  data={result.root_causes.map((rc, idx) => ({
                    label: rc.root_cause,
                    value: rc.likelihood_score,
                    suffix: '%',
                    color: idx === 0 ? 'bg-cyan-500' : idx === 1 ? 'bg-sky-500' : 'bg-slate-500'
                  }))}
                  maxValue={100}
                />

                {/* Top Cause Evidence List */}
                {result.root_causes.length > 0 && (
                  <div className="mt-4 p-2.5 bg-noc-950/60 border border-noc-border/60 rounded-xs space-y-1">
                    <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
                      Primary Evidence Chain:
                    </span>
                    {result.root_causes[0].evidence.map((ev, i) => (
                      <div key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                        <span className="text-cyan-400 font-mono font-bold">›</span>
                        <span>{ev}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-3 pt-2 border-t border-noc-border/60 text-[10px] font-mono text-slate-400">
                DOMAIN: {result.root_causes[0]?.domain || 'Radio / Transport'}
              </div>
            </div>

            {/* RIGHT: Operational Risk Score (3 cols) */}
            <div className="lg:col-span-3 bg-noc-900 border border-noc-border p-4 rounded-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 pb-2.5 mb-2 border-b border-noc-border">
                  <ShieldAlert className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                    OPERATIONAL RISK
                  </span>
                </div>

                <RiskGauge score={result.risk.score} level={result.risk.level} />

                {/* Key Contributing Risk Factors */}
                <div className="mt-3 space-y-1.5">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
                    Key Risk Drivers:
                  </span>
                  {result.risk.factors.slice(0, 3).map((factor, idx) => (
                    <div
                      key={idx}
                      className="text-[11px] text-slate-300 bg-noc-950/70 p-1.5 rounded-xs border border-noc-border/40 font-mono flex items-center gap-1.5"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                      <span className="truncate">{factor}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* TELEMETRY KPI TILES */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center gap-2">
                <Radio className="w-3.5 h-3.5 text-cyan-400" />
                Network Telemetry Metrics (Observed / Inferred)
              </span>
              <span className="text-[11px] font-mono text-slate-400">3GPP TS 38.314 SPEC</span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
              <MetricCard
                label="Latency"
                value={result.network_analysis.current_metrics.latency !== undefined ? result.network_analysis.current_metrics.latency : 'N/A'}
                unit="ms"
                threshold="< 77.4 ms"
                status={
                  typeof result.network_analysis.current_metrics.latency === 'number' && result.network_analysis.current_metrics.latency > 105
                    ? 'critical'
                    : typeof result.network_analysis.current_metrics.latency === 'number' && result.network_analysis.current_metrics.latency > 77
                    ? 'warning'
                    : 'nominal'
                }
              />
              <MetricCard
                label="Throughput"
                value={result.network_analysis.current_metrics.throughput !== undefined ? result.network_analysis.current_metrics.throughput : 'N/A'}
                unit="Mbps"
                threshold="> 392 Mbps"
                status={
                  typeof result.network_analysis.current_metrics.throughput === 'number' && result.network_analysis.current_metrics.throughput < 392
                    ? 'critical'
                    : typeof result.network_analysis.current_metrics.throughput === 'number' && result.network_analysis.current_metrics.throughput < 548
                    ? 'warning'
                    : 'nominal'
                }
              />
              <MetricCard
                label="Packet Loss"
                value={result.network_analysis.current_metrics.packet_loss_rate !== undefined ? result.network_analysis.current_metrics.packet_loss_rate : 'N/A'}
                unit="%"
                threshold="< 6.3%"
                status={
                  typeof result.network_analysis.current_metrics.packet_loss_rate === 'number' && result.network_analysis.current_metrics.packet_loss_rate > 9.4
                    ? 'critical'
                    : typeof result.network_analysis.current_metrics.packet_loss_rate === 'number' && result.network_analysis.current_metrics.packet_loss_rate > 6.3
                    ? 'warning'
                    : 'nominal'
                }
              />
              <MetricCard
                label="Handover SR"
                value={result.network_analysis.current_metrics.handover_success_rate !== undefined ? result.network_analysis.current_metrics.handover_success_rate : 'N/A'}
                unit="%"
                threshold="> 92.5%"
                status={
                  typeof result.network_analysis.current_metrics.handover_success_rate === 'number' && result.network_analysis.current_metrics.handover_success_rate < 92.5
                    ? 'critical'
                    : typeof result.network_analysis.current_metrics.handover_success_rate === 'number' && result.network_analysis.current_metrics.handover_success_rate < 95
                    ? 'warning'
                    : 'nominal'
                }
              />
              <MetricCard
                label="Call Drop Rate"
                value={result.network_analysis.current_metrics.call_drop_rate !== undefined ? result.network_analysis.current_metrics.call_drop_rate : 'N/A'}
                unit="%"
                threshold="< 1.7%"
                status={
                  typeof result.network_analysis.current_metrics.call_drop_rate === 'number' && result.network_analysis.current_metrics.call_drop_rate > 2.5
                    ? 'critical'
                    : typeof result.network_analysis.current_metrics.call_drop_rate === 'number' && result.network_analysis.current_metrics.call_drop_rate > 1.7
                    ? 'warning'
                    : 'nominal'
                }
              />
              <MetricCard
                label="Signal RSRP"
                value={result.network_analysis.current_metrics.signal_strength !== undefined ? result.network_analysis.current_metrics.signal_strength : 'N/A'}
                unit="dBm"
                threshold="> -105 dBm"
                status={
                  typeof result.network_analysis.current_metrics.signal_strength === 'number' && result.network_analysis.current_metrics.signal_strength < -110
                    ? 'critical'
                    : typeof result.network_analysis.current_metrics.signal_strength === 'number' && result.network_analysis.current_metrics.signal_strength < -105
                    ? 'warning'
                    : 'nominal'
                }
              />
              <MetricCard
                label="Crit Alarms"
                value={result.network_analysis.current_metrics.critical_alarm_count !== undefined ? result.network_analysis.current_metrics.critical_alarm_count : 'N/A'}
                threshold="p75: 8.4"
                status={
                  typeof result.network_analysis.current_metrics.critical_alarm_count === 'number' && result.network_analysis.current_metrics.critical_alarm_count >= 8.4
                    ? 'critical'
                    : typeof result.network_analysis.current_metrics.critical_alarm_count === 'number' && result.network_analysis.current_metrics.critical_alarm_count >= 6.8
                    ? 'warning'
                    : 'nominal'
                }
              />
            </div>
          </div>

          {/* ML PERFORMANCE PREDICTIONS & 60/40 RISK BLEND */}
          <div className="bg-noc-900 border border-noc-border p-4 rounded-sm space-y-3">
            <div className="flex flex-wrap items-center justify-between pb-2 border-b border-noc-border gap-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-sky-400" />
                Random Forest ML Performance Projections & Blended Operational Risk
              </span>
              <span className="text-xs px-2 py-0.5 bg-sky-950 border border-sky-800 text-sky-300 font-mono rounded-xs">
                {result.risk_blend_formula || '60% Deterministic + 40% ML Blended Score'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3 bg-noc-950/70 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px] uppercase">PREDICTED THROUGHPUT</span>
                <span className="text-white text-base font-bold">
                  {(result.prediction?.predicted_throughput_mbps ?? result.prediction?.predicted_throughput) !== undefined ? `${Math.round(result.prediction.predicted_throughput_mbps ?? result.prediction.predicted_throughput!)} Mbps` : 'N/A'}
                </span>
                <span className="text-[10px] text-slate-500 block mt-1">Random Forest regressor (R²=0.979)</span>
              </div>

              <div className="p-3 bg-noc-950/70 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px] uppercase">PREDICTED LATENCY</span>
                <span className="text-white text-base font-bold">
                  {(result.prediction?.predicted_latency_ms ?? result.prediction?.predicted_latency) !== undefined ? `${Math.round(result.prediction.predicted_latency_ms ?? result.prediction.predicted_latency!)} ms` : 'N/A'}
                </span>
                <span className="text-[10px] text-slate-500 block mt-1">Expected backhaul delay</span>
              </div>

              <div className="p-3 bg-noc-950/70 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px] uppercase">PREDICTED HANDOVER SR</span>
                <span className="text-white text-base font-bold">
                  {result.prediction?.predicted_handover_success_rate !== undefined ? `${result.prediction.predicted_handover_success_rate.toFixed(1)}%` : 'N/A'}
                </span>
                <span className="text-[10px] text-slate-500 block mt-1">Mobility retention</span>
              </div>

              <div className="p-3 bg-noc-950/70 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px] uppercase">RISK COMPONENT BREAKDOWN</span>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-slate-300">Det: <strong className="text-cyan-400">{result.deterministic_risk_score ?? result.risk.score}</strong></span>
                  <span className="text-slate-300">ML: <strong className="text-amber-400">{result.ml_risk_score ?? result.risk.score}</strong></span>
                </div>
                <span className="text-[10px] text-slate-500 block mt-1">
                  Blend: {result.risk.score}/100 ({result.risk.level})
                </span>
              </div>
            </div>
          </div>

          {/* DEDICATED NETWORK IMPACT ANALYSIS SECTION */}
          <div className="bg-noc-900 border border-noc-border p-4 rounded-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-noc-border">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-pink-400" />
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                  DEDICATED NETWORK IMPACT ANALYSIS
                </h3>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono text-slate-400">
                  REGION: <strong className="text-cyan-400">{result.network_impact.affected_region}</strong>
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-sm font-mono font-bold bg-pink-950 text-pink-400 border border-pink-700/60">
                  IMPACT SCORE: {result.network_impact.impact_score}/100 ({result.network_impact.impact_level})
                </span>
              </div>
            </div>

            {/* Impact Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
              <div className="p-3 bg-noc-950/70 border border-noc-border/60 rounded-xs space-y-2">
                <span className="text-slate-400 uppercase tracking-wider text-[11px] block">
                  Identified Affected Sectors / Cells
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {result.network_impact.affected_cells.map((cell, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-1 bg-noc-900 border border-pink-900/50 text-pink-300 rounded-xs text-[11px]"
                    >
                      {cell}
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-noc-950/70 border border-noc-border/60 rounded-xs space-y-1.5 font-sans">
                <span className="text-slate-400 uppercase tracking-wider text-[11px] font-mono block">
                  Subscriber & Customer QoE Impact
                </span>
                <p className="text-slate-300 leading-relaxed text-xs">
                  {result.network_impact.customer_impact}
                </p>
              </div>

              <div className="p-3 bg-noc-950/70 border border-noc-border/60 rounded-xs space-y-1.5 font-sans">
                <span className="text-slate-400 uppercase tracking-wider text-[11px] font-mono block">
                  RAN Infrastructure & Core Impact
                </span>
                <p className="text-slate-300 leading-relaxed text-xs">
                  {result.network_impact.network_impact}
                </p>
              </div>
            </div>

            {/* Affected KPI Metrics Breakdown Table */}
            {result.network_impact.affected_metrics.length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-noc-950 border-y border-noc-border text-slate-400">
                    <tr>
                      <th className="py-2 px-3">BREACHED METRIC</th>
                      <th className="py-2 px-3">RECORDED VALUE</th>
                      <th className="py-2 px-3">OPERATIONAL SLA</th>
                      <th className="py-2 px-3">SEVERITY</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-noc-border/50 text-slate-300">
                    {result.network_impact.affected_metrics.map((am, idx) => (
                      <tr key={idx} className="hover:bg-noc-850/40">
                        <td className="py-2 px-3 font-semibold text-white">{am.metric}</td>
                        <td className="py-2 px-3 text-red-400 font-bold">{am.value}</td>
                        <td className="py-2 px-3 text-slate-400">{am.threshold}</td>
                        <td className="py-2 px-3">
                          <SeverityBadge severity={am.severity} size="sm" />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* SIMILAR HISTORICAL CASES */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                SIMILAR HISTORICAL INCIDENTS ({result.similar_cases.length} RETRIEVED PRECEDENTS)
              </h3>
              <span className="text-[11px] font-mono text-slate-400">
                Click any incident to open full diagnostic telemetry drawer
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {result.similar_cases.map((sc) => (
                <div
                  key={sc.incident_id}
                  onClick={() => setSelectedCase(sc)}
                  className="p-3.5 bg-noc-900 border border-noc-border hover:border-cyan-500/70 rounded-sm cursor-pointer transition-all hover:bg-noc-850/80 group space-y-2.5 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-mono font-bold text-cyan-400 group-hover:text-cyan-300 text-sm">
                        {sc.incident_id}
                      </span>
                      <SeverityBadge severity={sc.severity} size="sm" />
                    </div>

                    <div className="text-xs text-slate-300 font-medium truncate mb-2">
                      {sc.issue_reported}
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono mb-2">
                      <span>{sc.location.city}, {sc.location.state}</span>
                      <span>{sc.season}</span>
                    </div>

                    {/* Quick Metric Bar */}
                    <div className="grid grid-cols-3 gap-1 text-[10px] font-mono bg-noc-950 p-2 rounded-xs border border-noc-border/50 text-center">
                      <div>
                        <span className="text-slate-400 block">LATENCY</span>
                        <span className="text-white font-bold">{sc.metrics.latency} ms</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">LOSS</span>
                        <span className="text-white font-bold">{sc.metrics.packet_loss_rate}%</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">THROUGHPUT</span>
                        <span className="text-white font-bold">{sc.metrics.throughput} Mbps</span>
                      </div>
                    </div>

                    {/* Empirical Match Reasons */}
                    {sc.why_similar && sc.why_similar.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {sc.why_similar.slice(0, 2).map((reason, rIdx) => (
                          <span
                            key={rIdx}
                            className="px-1.5 py-0.5 bg-cyan-950/70 text-cyan-300 border border-cyan-800/40 rounded-xs text-[10px] font-mono truncate max-w-full"
                          >
                            ✓ {reason}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-noc-border/60">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-semibold text-cyan-400">
                        Match: {Math.round((sc.initial_similarity_score ?? sc.similarity_score) * 100)}%
                      </span>
                      {sc.rerank_score !== undefined && (
                        <span className="text-[10px] font-mono px-1 py-0.2 bg-purple-950/80 text-purple-300 border border-purple-800/40 rounded-xs">
                          Rerank: {Math.round(sc.rerank_score * 100)}%
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 group-hover:text-cyan-300 flex items-center gap-1 font-mono">
                      Inspect <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* RECOMMENDED ACTIONS */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                RECOMMENDED CORRECTIVE ACTIONS (GROUNDED IN HISTORICAL RESOLUTIONS)
              </h3>
              <span className="text-[11px] font-mono text-slate-400">
                TRACEABLE TO HISTORICAL TELEMETRY & ROOT CAUSES
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {result.recommendations.map((rec, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-2.5 flex flex-col justify-between"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <SeverityBadge severity={rec.priority} size="sm" />
                      {rec.category && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-xs bg-noc-850 text-slate-400 border border-noc-border">
                          {rec.category}
                        </span>
                      )}
                    </div>
                    <h4 className="text-sm font-semibold text-white leading-snug">
                      {rec.action}
                    </h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      <strong className="text-slate-300">Rationale: </strong>
                      {rec.reason}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-noc-border/60 flex items-center justify-between text-[11px] font-mono">
                    <span className="text-slate-400">Supporting Evidence:</span>
                    <div className="flex gap-1">
                      {rec.evidence.map((ev, i) => (
                        <span
                          key={i}
                          className="px-1.5 py-0.5 bg-noc-850 text-cyan-400 border border-cyan-800/50 rounded-xs text-[10px]"
                        >
                          {ev}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* MULTI-AGENT COLLABORATION TRACE */}
          {result.agent_trace && result.agent_trace.length > 0 && (
            <div className="bg-noc-900 border border-noc-border p-4 rounded-sm space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-noc-border">
                <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  Multi-Agent Diagnostic Execution Trace ({result.agent_trace.length} Orchestrated Steps)
                </h4>
                <span className="text-[11px] font-mono text-slate-400">
                  Total Diagnostic Latency: {result.metadata?.total_latency_seconds ? `${result.metadata.total_latency_seconds.toFixed(2)}s` : 'Real-time'}
                </span>
              </div>

              <div className="space-y-2">
                {result.agent_trace.map((tr: any, idx: number) => (
                  <div
                    key={idx}
                    className="p-2.5 bg-noc-950/70 border border-noc-border/50 rounded-xs flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs font-mono"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 flex items-center justify-center text-[10px] font-bold shrink-0">
                        {tr.step}
                      </span>
                      <div>
                        <strong className="text-white">{tr.agent}</strong>
                        <span className="text-slate-400 ml-2">[{tr.inputs_summary}]</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 text-[11px]">
                      <span className="text-slate-300 max-w-md truncate">› {tr.output_summary}</span>
                      <span className="text-slate-500 shrink-0">({(tr.latency_seconds * 1000).toFixed(0)}ms)</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* OPERATOR FEEDBACK COMPONENT */}
          <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-cyan-400" />
                  OPERATOR EVALUATION & FEEDBACK LOOP
                </h4>
                <p className="text-[11px] text-slate-400">
                  Record operational feedback directly to SQLite audit store for continuous model alignment.
                </p>
              </div>

              {feedbackSubmitted && (
                <span className="px-3 py-1 bg-emerald-950 border border-emerald-600 text-emerald-400 text-xs font-mono rounded-xs flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" /> Feedback Recorded
                </span>
              )}
            </div>

            {!feedbackSubmitted ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                {/* Q1 */}
                <div className="space-y-1.5">
                  <span className="text-xs text-slate-300 font-medium block">
                    Was this diagnosis useful?
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setDiagFeedback('Helpful')}
                      className={`px-3 py-1.5 rounded-sm border text-xs font-mono flex items-center gap-1.5 cursor-pointer ${
                        diagFeedback === 'Helpful'
                          ? 'bg-emerald-950 text-emerald-400 border-emerald-600 font-bold'
                          : 'bg-noc-850 text-slate-400 border-noc-border hover:text-white'
                      }`}
                    >
                      <ThumbsUp className="w-3.5 h-3.5" /> Helpful
                    </button>
                    <button
                      onClick={() => setDiagFeedback('Not Helpful')}
                      className={`px-3 py-1.5 rounded-sm border text-xs font-mono flex items-center gap-1.5 cursor-pointer ${
                        diagFeedback === 'Not Helpful'
                          ? 'bg-red-950 text-red-400 border-red-600 font-bold'
                          : 'bg-noc-850 text-slate-400 border-noc-border hover:text-white'
                      }`}
                    >
                      <ThumbsDown className="w-3.5 h-3.5" /> Not Helpful
                    </button>
                  </div>
                </div>

                {/* Q2 */}
                <div className="space-y-1.5">
                  <span className="text-xs text-slate-300 font-medium block">
                    Was the recommendation correct?
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setRecFeedback('Correct Diagnosis')}
                      className={`px-3 py-1.5 rounded-sm border text-xs font-mono flex items-center gap-1.5 cursor-pointer ${
                        recFeedback === 'Correct Diagnosis'
                          ? 'bg-cyan-950 text-cyan-400 border-cyan-600 font-bold'
                          : 'bg-noc-850 text-slate-400 border-noc-border hover:text-white'
                      }`}
                    >
                      <CheckCircle className="w-3.5 h-3.5" /> Correct
                    </button>
                    <button
                      onClick={() => setRecFeedback('Incorrect Diagnosis')}
                      className={`px-3 py-1.5 rounded-sm border text-xs font-mono flex items-center gap-1.5 cursor-pointer ${
                        recFeedback === 'Incorrect Diagnosis'
                          ? 'bg-amber-950 text-amber-400 border-amber-600 font-bold'
                          : 'bg-noc-850 text-slate-400 border-noc-border hover:text-white'
                      }`}
                    >
                      <XCircle className="w-3.5 h-3.5" /> Incorrect
                    </button>
                  </div>
                </div>

                {/* Comment & Submit */}
                <div className="flex gap-2 items-end">
                  <input
                    type="text"
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Optional engineering comment..."
                    className="flex-1 bg-noc-950 border border-noc-border rounded-sm px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 font-mono focus:outline-hidden focus:border-cyan-400"
                  />
                  <button
                    onClick={handleSendFeedback}
                    disabled={!diagFeedback && !recFeedback}
                    className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-black font-mono font-bold text-xs uppercase rounded-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" /> SUBMIT
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-xs text-emerald-400 font-mono py-1">
                Thank you. Feedback saved to persistent SQLite database (data/netpulse.db).
              </div>
            )}
          </div>
        </div>
      )}

      {/* CASE DETAIL INSPECTION MODAL */}
      <CaseDetailModal caseData={selectedCase} onClose={() => setSelectedCase(null)} />
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Radio,
  TrendingUp,
  ShieldAlert,
  ArrowRight,
  Server,
  RefreshCw,
  CheckCircle2,
  Clock,
  Sun,
  CloudRain
} from 'lucide-react';
import { SystemMetrics, SystemStats } from '../types';
import { fetchMetrics, fetchStatistics } from '../services/api';
import { MetricCard } from '../components/MetricCard';
import { HorizontalBarChart } from '../components/SimpleCharts';

interface Props {
  onNavigate: (tab: string) => void;
}

export const OverviewPage: React.FC<Props> = ({ onNavigate }) => {
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [stats, setStats] = useState<SystemStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [lastRefreshed, setLastRefreshed] = useState<string>('');
  const [showSyncedBadge, setShowSyncedBadge] = useState(false);

  const loadData = async () => {
    setLoading(true);
    setShowSyncedBadge(false);

    try {
      const [m, s] = await Promise.all([
        fetchMetrics(),
        fetchStatistics()
      ]);

      setMetrics(m);
      setStats(s);
      setLastRefreshed(new Date().toLocaleTimeString());
      setShowSyncedBadge(true);
      setTimeout(() => setShowSyncedBadge(false), 3000);
    } catch (e) {
      console.error("Telemetry refresh error:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Title & Refresh Control Bar */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-noc-border gap-3">
        <div>
          <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            NETWORK OPERATIONS CENTER — OVERVIEW
          </h2>
          <p className="text-xs text-slate-400">
            Real-time multi-carrier health index, operational alarms, and empirical dataset distributions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {lastRefreshed && (
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400 bg-noc-900 border border-noc-border px-2.5 py-1 rounded-sm">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>SYNCED: {lastRefreshed}</span>
            </div>
          )}

          {showSyncedBadge && (
            <span className="text-xs font-mono px-2 py-1 rounded-sm bg-emerald-950 text-emerald-400 border border-emerald-600 animate-in fade-in flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> REFRESHED
            </span>
          )}

          <button
            id="refresh-telemetry-btn"
            onClick={() => loadData()}
            disabled={loading}
            className="px-3.5 py-1.5 bg-noc-850 hover:bg-cyan-950 text-slate-200 hover:text-cyan-300 border border-noc-border hover:border-cyan-500/60 rounded-sm text-xs font-mono flex items-center gap-2 transition-all cursor-pointer disabled:opacity-60 shadow-sm"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-cyan-400' : 'text-slate-400'}`} />
            {loading ? 'SYNCING TELEMETRY...' : 'REFRESH TELEMETRY'}
          </button>
        </div>
      </div>

      {/* KPI BLOCKS */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <MetricCard
          label="Network Health"
          value={metrics ? `${metrics.network_health_score}%` : '...'}
          status={metrics?.network_health_score && metrics.network_health_score > 90 ? 'nominal' : 'warning'}
          subtext={metrics?.network_health_status || 'ANALYZING'}
          icon={Radio}
        />
        <MetricCard
          label="Active Incidents"
          value={metrics ? metrics.active_incidents : '...'}
          status="warning"
          subtext="High / Critical"
          icon={AlertTriangle}
        />
        <MetricCard
          label="Critical Alerts"
          value={metrics ? metrics.critical_alerts : '...'}
          status="critical"
          subtext="Immediate Action"
          icon={ShieldAlert}
        />
        <MetricCard
          label="High Risk Cells"
          value={metrics ? metrics.high_risk_cells : '...'}
          status="warning"
          subtext="p75 Cutoff >= 48.3%"
        />
        <MetricCard
          label="Avg Latency"
          value={metrics ? metrics.avg_latency : '...'}
          subtext="Cluster RTT"
          threshold="< 77.4 ms"
          status={metrics && parseFloat(metrics.avg_latency) > 105 ? 'critical' : metrics && parseFloat(metrics.avg_latency) > 77 ? 'warning' : 'nominal'}
        />
        <MetricCard
          label="Packet Loss"
          value={metrics ? metrics.avg_packet_loss : '...'}
          subtext="Frame Drop"
          threshold="< 6.3%"
          status={metrics && parseFloat(metrics.avg_packet_loss) > 9.4 ? 'critical' : 'nominal'}
        />
        <MetricCard
          label="Handover SR"
          value={metrics ? metrics.avg_handover_success : '...'}
          subtext="Mobility Retention"
          threshold="> 92.5%"
          status={metrics && parseFloat(metrics.avg_handover_success) < 92.5 ? 'critical' : 'nominal'}
        />
      </div>

      {/* CHARTS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Real Environmental & Seasonal Distributions (8 cols) */}
        <div className="lg:col-span-8 bg-noc-900 border border-noc-border p-4 rounded-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-noc-border">
            <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              Dataset Environmental & Operational Profiles
            </span>
            <span className="text-[11px] font-mono text-cyan-400">GROUND-TRUTH TELEMETRY</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-3 bg-noc-950/60 border border-noc-border/60 rounded-xs space-y-2">
              <div className="flex justify-between items-center mb-1 text-[11px] font-mono">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  INCIDENT VOLUME BY SEASON
                </span>
              </div>
              {stats?.season_distribution ? (
                <HorizontalBarChart
                  data={Object.entries(stats.season_distribution).map(([season, count]) => ({
                    label: season,
                    value: count,
                    color: season === 'Winter' ? 'bg-sky-400' : season === 'Summer' ? 'bg-amber-400' : season === 'Fall' ? 'bg-orange-400' : 'bg-emerald-400',
                    suffix: 'records'
                  }))}
                />
              ) : (
                <div className="text-xs font-mono text-slate-500 py-4 text-center">Loading seasonal distribution...</div>
              )}
            </div>

            <div className="p-3 bg-noc-950/60 border border-noc-border/60 rounded-xs space-y-2">
              <div className="flex justify-between items-center mb-1 text-[11px] font-mono">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <CloudRain className="w-3.5 h-3.5 text-cyan-400" />
                  TOP INCIDENT CATEGORIES
                </span>
              </div>
              {stats?.top_issues ? (
                <HorizontalBarChart
                  data={Object.entries(stats.top_issues).slice(0, 4).map(([issue, count]) => ({
                    label: issue,
                    value: count,
                    color: 'bg-cyan-500',
                    suffix: 'records'
                  }))}
                />
              ) : (
                <div className="text-xs font-mono text-slate-500 py-4 text-center">Loading incident categories...</div>
              )}
            </div>
          </div>

          <div className="p-3 bg-noc-950/80 border border-noc-border/60 rounded-xs flex items-center justify-between text-xs">
            <div className="flex items-center gap-3">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span className="text-slate-300 font-medium">
                Active Operational Health: {metrics?.network_health_status || 'MONITORING'} across {stats?.total_records?.toLocaleString() || '10,000'} indexed records.
              </span>
            </div>
            <button
              onClick={() => onNavigate('investigate')}
              className="text-cyan-400 hover:text-cyan-300 font-mono text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              Launch Investigation <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Severity & Record Breakdown (4 cols) */}
        <div className="lg:col-span-4 bg-noc-900 border border-noc-border p-4 rounded-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-noc-border">
            <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider">
              OPERATIONAL INCIDENT BREAKDOWN
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              {stats?.total_records ? `${stats.total_records.toLocaleString()} RECORDS` : '...'}
            </span>
          </div>

          {stats ? (
            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-2">
                  Severity Distribution (Calibrated Scale)
                </span>
                <HorizontalBarChart
                  data={[
                    { label: 'CRITICAL', value: stats.severity_distribution['CRITICAL'] || 0, color: 'bg-red-500' },
                    { label: 'HIGH', value: stats.severity_distribution['HIGH'] || 0, color: 'bg-amber-500' },
                    { label: 'MEDIUM', value: stats.severity_distribution['MEDIUM'] || 0, color: 'bg-sky-500' },
                    { label: 'LOW', value: stats.severity_distribution['LOW'] || 0, color: 'bg-emerald-500' },
                  ]}
                />
              </div>

              <div>
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-2">
                  Metropolitan Distribution
                </span>
                <HorizontalBarChart
                  data={Object.entries(stats.city_distribution).slice(0, 4).map(([city, cnt]) => ({
                    label: city,
                    value: cnt,
                    color: 'bg-emerald-500'
                  }))}
                />
              </div>
            </div>
          ) : (
            <div className="text-slate-500 text-xs font-mono py-8 text-center">Loading distributions...</div>
          )}
        </div>
      </div>
    </div>
  );
};

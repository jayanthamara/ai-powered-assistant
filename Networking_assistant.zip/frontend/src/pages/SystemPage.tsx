import React, { useEffect, useState, useRef } from 'react';
import { 
  Settings, RefreshCw, Cpu, Database, Check, 
  Upload, FileText, CheckCircle2, AlertCircle, Terminal, HardDrive 
} from 'lucide-react';
import { fetchConfig, triggerReindex, uploadDatasetFile } from '../services/api';

export const SystemPage: React.FC = () => {
  const [config, setConfig] = useState<any>(null);
  const [reindexing, setReindexing] = useState(false);
  const [reindexSuccess, setReindexSuccess] = useState(false);

  // Direct Ingestion State
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [mergeDataset, setMergeDataset] = useState<boolean>(true);
  const [uploading, setUploading] = useState<boolean>(false);
  const [uploadResult, setUploadResult] = useState<{
    status: 'success' | 'error';
    message: string;
    total_records?: number;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const loadConfig = () => {
    fetchConfig().then(setConfig).catch(console.error);
  };

  useEffect(() => {
    loadConfig();
  }, []);

  const handleReindex = async () => {
    setReindexing(true);
    setReindexSuccess(false);
    try {
      await triggerReindex();
      setReindexSuccess(true);
      loadConfig();
      setTimeout(() => setReindexSuccess(false), 4000);
    } catch (e) {
      console.error(e);
    } finally {
      setReindexing(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
      setUploadResult(null);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;
    setUploading(true);
    setUploadResult(null);
    try {
      const res = await uploadDatasetFile(selectedFile, mergeDataset);
      setUploadResult({
        status: 'success',
        message: res.message || 'Dataset uploaded and indexed successfully!',
        total_records: res.total_records
      });
      loadConfig();
      if (fileInputRef.current) fileInputRef.current.value = '';
      setSelectedFile(null);
    } catch (err: any) {
      setUploadResult({
        status: 'error',
        message: err.message || 'Failed to upload dataset.'
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      <div className="flex items-center justify-between pb-3 border-b border-noc-border">
        <div>
          <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
            <Settings className="w-5 h-5 text-cyan-400" />
            SYSTEM CONFIGURATION & RUNTIME CONTROL
          </h2>
          <p className="text-xs text-slate-400">
            Active RAG retrieval fusion weights, model abstractions, direct dataset ingestion, and live indexing.
          </p>
        </div>
      </div>

      {/* DIRECT DATASET INGESTION CARD */}
      <div className="p-5 bg-noc-900 border border-noc-border rounded-sm space-y-4 font-mono">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-noc-border/80">
          <div>
            <h3 className="font-bold text-slate-100 text-sm uppercase tracking-wider flex items-center gap-2">
              <Upload className="w-4 h-4 text-cyan-400" />
              Direct Telemetry Dataset Ingestion (Push to Server)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Ingest new raw telemetry CSVs directly to the live server. Automatically normalizes columns, computes embeddings, and retrains ML models on-the-fly.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* File Upload Zone */}
          <div className="lg:col-span-2 space-y-3">
            <div className="p-4 bg-noc-950/80 border border-dashed border-noc-border rounded-sm space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs text-slate-300 font-bold flex items-center gap-2">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  Select Telecom Raw CSV File:
                </label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  onChange={handleFileChange}
                  className="text-xs text-slate-400 file:mr-3 file:py-1 file:px-3 file:rounded-sm file:border-0 file:text-xs file:font-semibold file:bg-cyan-500/20 file:text-cyan-300 hover:file:bg-cyan-500/30 cursor-pointer"
                />
              </div>

              {selectedFile && (
                <div className="flex items-center justify-between bg-noc-900 p-2.5 rounded-sm border border-cyan-500/30 text-xs">
                  <span className="text-slate-200">
                    Selected: <strong className="text-cyan-300">{selectedFile.name}</strong> ({Math.round(selectedFile.size / 1024)} KB)
                  </span>
                  <span className="text-slate-400 text-[10px]">Ready for ingestion</span>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={mergeDataset}
                    onChange={(e) => setMergeDataset(e.target.checked)}
                    className="accent-cyan-500 w-3.5 h-3.5"
                  />
                  <span>Merge with existing corpus (deduplicates IDs, appends new incidents)</span>
                </label>

                <button
                  onClick={handleUpload}
                  disabled={!selectedFile || uploading}
                  className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-black font-bold text-xs uppercase tracking-wider rounded-sm flex items-center gap-2 cursor-pointer transition"
                >
                  {uploading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      INGESTING & REINDEXING...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4" />
                      PUSH DATASET TO SERVER
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Ingestion Results Banner */}
            {uploadResult && (
              <div
                className={`p-3 rounded-sm border text-xs flex items-start gap-2.5 ${
                  uploadResult.status === 'success'
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                    : 'bg-rose-950/40 border-rose-500/50 text-rose-300'
                }`}
              >
                {uploadResult.status === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                )}
                <div>
                  <div className="font-bold">{uploadResult.message}</div>
                  {uploadResult.total_records && (
                    <div className="text-[11px] text-slate-300 mt-1">
                      Corpus successfully updated. Total active network incidents indexed: <strong>{uploadResult.total_records}</strong>.
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Direct API Push Documentation */}
          <div className="p-3 bg-noc-950 border border-noc-border rounded-sm space-y-2 text-xs">
            <h4 className="font-bold text-slate-200 flex items-center gap-1.5 uppercase text-[11px] tracking-wider">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              Direct Headless API Push (cURL)
            </h4>
            <p className="text-[11px] text-slate-400">
              Telecom automation pipelines, Kafka sinks, and remote engineers can POST telemetry directly via REST without opening VS Code:
            </p>
            <div className="p-2 bg-black/60 rounded border border-noc-border/80 text-[10px] text-cyan-300 overflow-x-auto select-all">
              curl -X POST "http://127.0.0.1:8000/api/v1/upload?merge=true" \<br />
              &nbsp;&nbsp;-F "file=@your_telemetry_batch.csv"
            </div>
            <div className="text-[10px] text-slate-400">
              Response: JSON confirming ingestion count and retraining completion.
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Active Configuration */}
        <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3 font-mono text-xs">
          <h3 className="font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            Active Runtime Parameters
          </h3>
          <div className="space-y-2">
            <div className="flex justify-between py-1.5 border-b border-noc-border/60">
              <span className="text-slate-400">DEMO MODE STATUS:</span>
              <span className="text-emerald-400 font-bold">100% OFFLINE READY</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-noc-border/60">
              <span className="text-slate-400">LLM PROVIDER:</span>
              <span className="text-white">{config?.llm_provider || 'demo / local'}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-noc-border/60">
              <span className="text-slate-400">EMBEDDING STACK:</span>
              <span className="text-white">{config?.embedding_model || 'dense-svd-minilm'}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-noc-border/60">
              <span className="text-slate-400">DATASET STORAGE:</span>
              <span className="text-white">{config?.data_path || 'data/processed/telecom_incidents_processed.csv'}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">RETRIEVAL CANDIDATES (TOP-K):</span>
              <span className="text-cyan-400 font-bold">{config?.top_k || 5}</span>
            </div>
          </div>
        </div>

        {/* Configurable RAG Fusion Weights */}
        <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3 font-mono text-xs">
          <h3 className="font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-400" />
            Hybrid Search Score Fusion Weights
          </h3>
          <div className="space-y-2.5 pt-1">
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">Semantic Dense Vector Similarity (0.45):</span>
                <span className="text-cyan-400 font-bold">45%</span>
              </div>
              <div className="h-2 w-full bg-noc-950 rounded-xs overflow-hidden border border-noc-border/60">
                <div className="h-full bg-cyan-400" style={{ width: '45%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">BM25 Okapi Keyword Relevance (0.30):</span>
                <span className="text-sky-400 font-bold">30%</span>
              </div>
              <div className="h-2 w-full bg-noc-950 rounded-xs overflow-hidden border border-noc-border/60">
                <div className="h-full bg-sky-400" style={{ width: '30%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">Telemetry Metric Distance Similarity (0.15):</span>
                <span className="text-emerald-400 font-bold">15%</span>
              </div>
              <div className="h-2 w-full bg-noc-950 rounded-xs overflow-hidden border border-noc-border/60">
                <div className="h-full bg-emerald-400" style={{ width: '15%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">Geographic & Categorical Metadata Match (0.10):</span>
                <span className="text-amber-400 font-bold">10%</span>
              </div>
              <div className="h-2 w-full bg-noc-950 rounded-xs overflow-hidden border border-noc-border/60">
                <div className="h-full bg-amber-400" style={{ width: '10%' }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Manual Dataset Re-indexing Action */}
      <div className="p-4 bg-noc-900 border border-noc-border rounded-sm flex items-center justify-between">
        <div>
          <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-cyan-400" />
            Rebuild Vector Index & Retrain Models
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">
            Manually triggers reindexing of the active dataset in data/raw, regenerates dense embeddings, and fits Random Forest models.
          </p>
        </div>

        <button
          onClick={handleReindex}
          disabled={reindexing}
          className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-black font-mono font-bold text-xs uppercase tracking-wider rounded-sm flex items-center gap-2 cursor-pointer transition"
        >
          {reindexing ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              REINDEXING CORPUS...
            </>
          ) : reindexSuccess ? (
            <>
              <Check className="w-4 h-4 text-black" />
              INDEX REBUILT OK
            </>
          ) : (
            <>
              <RefreshCw className="w-4 h-4" />
              TRIGGER REINDEX
            </>
          )}
        </button>
      </div>
    </div>
  );
};

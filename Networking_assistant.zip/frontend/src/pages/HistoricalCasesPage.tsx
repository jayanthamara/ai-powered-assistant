import React, { useState, useEffect } from 'react';
import { Database, Search, Filter, Eye, ArrowRight } from 'lucide-react';
import { SimilarCase } from '../types';
import { searchHistoricalCases, fetchFilters } from '../services/api';
import { SeverityBadge } from '../components/SeverityBadge';
import { CaseDetailModal } from '../components/CaseDetailModal';

export const HistoricalCasesPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('high latency packet loss low throughput');
  const [cityFilter, setCityFilter] = useState('');
  const [seasonFilter, setSeasonFilter] = useState('');
  const [filterVocab, setFilterVocab] = useState<{ cities: string[]; seasons: string[] }>({
    cities: [],
    seasons: ['Winter', 'Spring', 'Summer', 'Fall']
  });
  const [results, setResults] = useState<SimilarCase[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedCase, setSelectedCase] = useState<SimilarCase | null>(null);

  useEffect(() => {
    fetchFilters()
      .then((data) => {
        setFilterVocab({
          cities: data.cities || [],
          seasons: data.seasons || ['Winter', 'Spring', 'Summer', 'Fall']
        });
      })
      .catch(console.error);
  }, []);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setLoading(true);
    try {
      const filters: Record<string, any> = {};
      if (cityFilter) filters.city = cityFilter;
      if (seasonFilter) filters.season = seasonFilter;

      const res = await searchHistoricalCases(searchQuery, filters, 8);
      setResults(res.results);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-12">
      <div className="flex items-center justify-between pb-3 border-b border-noc-border">
        <div>
          <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
            <Database className="w-5 h-5 text-cyan-400" />
            HISTORICAL CASE EXPLORER (HYBRID RAG)
          </h2>
          <p className="text-xs text-slate-400">
            Semantic vector matching + BM25 keyword search across 10,000 historical operational incidents.
          </p>
        </div>
        <span className="text-xs px-2.5 py-1 bg-cyan-950 border border-cyan-800 text-cyan-300 font-mono rounded-xs">
          VECTOR STORE: DENSE 128-D + BM25
        </span>
      </div>

      {/* Natural Language Search Header */}
      <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search historical incidents (e.g., high latency packet loss in Minneapolis MN during Winter)..."
              className="w-full bg-noc-950 border border-noc-border rounded-sm pl-9 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 font-mono focus:outline-hidden focus:border-cyan-400"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={loading || !searchQuery.trim()}
            className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-black font-mono font-bold text-xs uppercase tracking-wider rounded-sm flex items-center gap-2 cursor-pointer"
          >
            {loading ? 'RETRIEVING...' : 'SEARCH INCIDENTS'}
          </button>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-1">
          <div className="flex items-center gap-1.5">
            <span>CITY:</span>
            <select
              value={cityFilter}
              onChange={(e) => setCityFilter(e.target.value)}
              className="bg-noc-950 border border-noc-border text-slate-200 rounded-xs px-2 py-0.5 focus:outline-hidden cursor-pointer"
            >
              <option value="">All Cities</option>
              {filterVocab.cities.slice(0, 50).map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span>SEASON:</span>
            <select
              value={seasonFilter}
              onChange={(e) => setSeasonFilter(e.target.value)}
              className="bg-noc-950 border border-noc-border text-slate-200 rounded-xs px-2 py-0.5 focus:outline-hidden cursor-pointer"
            >
              <option value="">All Seasons</option>
              {filterVocab.seasons.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          <span className="text-[11px] text-slate-500">
            Weighted Score: 45% Vector + 30% BM25 + 15% Telemetry Metric + 10% Metadata
          </span>
        </div>
      </div>

      {/* Results Cards */}
      <div className="space-y-3">
        {results.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {results.map((sc) => (
              <div
                key={sc.incident_id}
                onClick={() => setSelectedCase(sc)}
                className="p-3.5 bg-noc-900 border border-noc-border hover:border-cyan-500/70 rounded-sm cursor-pointer transition-all hover:bg-noc-850 flex flex-col justify-between space-y-2 group"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono font-bold text-cyan-400 group-hover:text-cyan-300 text-sm">
                      {sc.incident_id}
                    </span>
                    <SeverityBadge severity={sc.severity} size="sm" />
                  </div>

                  <p className="text-xs text-slate-200 font-medium truncate mb-1.5">
                    {sc.issue_reported}
                  </p>

                  <div className="text-[11px] text-slate-400 font-mono mb-2">
                    {sc.location.city}, {sc.location.state} • {sc.season}
                  </div>

                  <div className="grid grid-cols-3 gap-1 text-[10px] font-mono bg-noc-950 p-1.5 rounded-xs border border-noc-border/50 text-center">
                    <div>
                      <span className="text-slate-400 block">LAT</span>
                      <span className="text-white font-bold">{sc.metrics.latency}ms</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">LOSS</span>
                      <span className="text-white font-bold">{sc.metrics.packet_loss_rate}%</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">TP</span>
                      <span className="text-white font-bold">{sc.metrics.throughput}M</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-noc-border/60 flex items-center justify-between">
                  <span className="text-xs font-mono font-semibold text-cyan-400">
                    Match: {Math.round(sc.similarity_score * 100)}%
                  </span>
                  <span className="text-[11px] text-slate-400 group-hover:text-cyan-300 flex items-center gap-1 font-mono">
                    Inspect <Eye className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center text-slate-500 font-mono text-xs bg-noc-900 border border-noc-border rounded-sm">
            Enter search criteria above and click 'SEARCH INCIDENTS' to retrieve matching historical cases.
          </div>
        )}
      </div>

      <CaseDetailModal caseData={selectedCase} onClose={() => setSelectedCase(null)} />
    </div>
  );
};

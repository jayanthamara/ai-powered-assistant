import React, { useEffect, useState } from 'react';
import { MessageSquare, ThumbsUp, CheckCircle, Database, RefreshCw } from 'lucide-react';
import { SystemStats } from '../types';
import { fetchStatistics, fetchFeedback } from '../services/api';
import { MetricCard } from '../components/MetricCard';

export const FeedbackPage: React.FC = () => {
  const [stats, setStats] = useState<SystemStats | null>(null);
  const [entries, setEntries] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [s, fb] = await Promise.all([
        fetchStatistics().catch(() => null),
        fetchFeedback().catch(() => ({ feedback_entries: [] }))
      ]);
      setStats(s);
      setEntries(fb?.feedback_entries || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const fb = stats?.feedback_stats;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      <div className="flex items-center justify-between pb-3 border-b border-noc-border">
        <div>
          <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-cyan-400" />
            OPERATOR FEEDBACK & CONTINUOUS IMPROVEMENT
          </h2>
          <p className="text-xs text-slate-400">
            Active operator feedback recorded in SQLite database powering continuous candidate reranking.
          </p>
        </div>
        <button
          onClick={loadData}
          disabled={loading}
          className="px-3 py-1 bg-noc-850 hover:bg-noc-800 text-slate-300 border border-noc-border rounded-xs text-xs font-mono flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh Votes
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricCard
          label="Total Operator Votes"
          value={fb?.total_feedback_entries ?? 0}
          status="nominal"
          icon={MessageSquare}
        />
        <MetricCard
          label="Positive Rating"
          value={fb && fb.total_feedback_entries > 0 ? `${Math.round(fb.positive_rate * 100)}%` : 'No Votes Yet'}
          status="nominal"
          subtext="Helpful / Correct"
          icon={ThumbsUp}
        />
        <MetricCard
          label="Audited Investigations"
          value={fb?.total_queries_logged ?? 0}
          status="nominal"
          subtext="Logged in SQLite DB"
          icon={Database}
        />
        <MetricCard
          label="Re-ranking Pipeline"
          value="ACTIVE"
          status="nominal"
          subtext="Bounded +/-0.06 adjustment"
          icon={CheckCircle}
        />
      </div>

      {/* Recent Feedback Submissions Table */}
      <div className="bg-noc-900 border border-noc-border rounded-sm overflow-hidden space-y-2 p-4">
        <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">
          Recorded Operator Feedback Submissions ({entries.length} Entries)
        </h3>
        <p className="text-xs text-slate-400 font-mono">
          Feedback is stored in SQLite and directly applies bounded per-case score adjustments during RAG candidate reranking.
        </p>

        {entries.length > 0 ? (
          <div className="overflow-x-auto pt-2">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-noc-950 border-y border-noc-border text-slate-400">
                <tr>
                  <th className="py-2 px-3">TIMESTAMP</th>
                  <th className="py-2 px-3">QUERY</th>
                  <th className="py-2 px-3">INCIDENT TYPE</th>
                  <th className="py-2 px-3">DIAGNOSIS VOTE</th>
                  <th className="py-2 px-3">RECOMMENDATION VOTE</th>
                  <th className="py-2 px-3">TARGET CASE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-noc-border/40 text-slate-300">
                {entries.map((e, idx) => (
                  <tr key={idx} className="hover:bg-noc-850/40">
                    <td className="py-2 px-3 text-slate-500">{e.timestamp?.slice(0, 19) || 'Just now'}</td>
                    <td className="py-2 px-3 text-white max-w-xs truncate">{e.query}</td>
                    <td className="py-2 px-3 text-cyan-300">{e.incident_type || 'N/A'}</td>
                    <td className="py-2 px-3">
                      <span className={`px-1.5 py-0.5 rounded-xs text-[10px] ${
                        e.diagnosis_feedback === 'Helpful' ? 'bg-emerald-950 text-emerald-300' : 'bg-red-950 text-red-300'
                      }`}>
                        {e.diagnosis_feedback}
                      </span>
                    </td>
                    <td className="py-2 px-3">
                      <span className={`px-1.5 py-0.5 rounded-xs text-[10px] ${
                        e.recommendation_feedback === 'Correct Diagnosis' || e.recommendation_feedback === 'Effective Action'
                          ? 'bg-emerald-950 text-emerald-300'
                          : 'bg-amber-950 text-amber-300'
                      }`}>
                        {e.recommendation_feedback || 'N/A'}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-slate-400">{e.case_id || 'Global'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-8 text-center text-xs font-mono text-slate-500 border border-dashed border-noc-border/60 rounded-xs">
            No operator feedback entries recorded yet. Submit feedback on the Investigate page to populate this audit store.
          </div>
        )}
      </div>

      <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3 text-xs">
        <h3 className="font-mono font-bold text-slate-200 uppercase tracking-wider">
          Architecture Design Note: Active Feedback Loop
        </h3>
        <p className="text-slate-400 leading-relaxed font-mono">
          As required by telecom engineering guidelines, NETPULSE AI persists operator evaluations directly to
          <code className="text-cyan-400 mx-1">data/netpulse.db</code> via SQLite. The feedback loop records whether diagnoses
          were verified as accurate and whether recommended actions were effective. The reranker in
          <code className="text-cyan-400 mx-1">TelecomReranker</code> reads recorded votes to apply a bounded (+/-0.06) adjustment
          to retrieved case similarity scores, preventing arbitrary ranking drift while learning from operational consensus.
        </p>
      </div>
    </div>
  );
};

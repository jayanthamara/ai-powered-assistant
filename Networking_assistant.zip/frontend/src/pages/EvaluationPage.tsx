import React, { useState } from 'react';
import {
  Award,
  CheckCircle,
  ShieldCheck,
  FileCheck,
  Layers,
  Search,
  Loader2,
  AlertTriangle,
  XCircle,
  Database,
  ArrowRight,
  ExternalLink,
  Cpu,
  Activity,
  Sparkles,
  HelpCircle,
  Radio,
  FileText
} from 'lucide-react';
import { MetricCard } from '../components/MetricCard';
import { runQueryEvaluation, runBenchmarkEvaluation, fetchRagasEvaluation, fetchDeepEvalEvaluation, triggerRagasEvaluation } from '../services/api';
import { QueryEvaluationResponse, BenchmarkSummary } from '../types';

const SAMPLE_QUERIES = [
  "Why is latency high in Minneapolis MN during winter?",
  "Why are handover failures increasing in state MN?",
  "A cell is experiencing high latency, packet loss and reduced throughput in Minneapolis MN.",
  "Several cells have poor service quality and increasing alarm counts."
];

export const EvaluationPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'query' | 'benchmark' | 'frameworks'>('query');

  // Frameworks Audit State (RAGAS & DeepEval)
  const [ragasData, setRagasData] = useState<any>(null);
  const [deepEvalData, setDeepEvalData] = useState<any>(null);
  const [isLoadingFrameworks, setIsLoadingFrameworks] = useState<boolean>(false);
  const [isRunningRagas, setIsRunningRagas] = useState<boolean>(false);
  const [frameworksError, setFrameworksError] = useState<string | null>(null);

  // Query Evaluation State
  const [queryInput, setQueryInput] = useState<string>('');
  const [isEvaluatingQuery, setIsEvaluatingQuery] = useState<boolean>(false);
  const [queryResult, setQueryResult] = useState<QueryEvaluationResponse | null>(null);
  const [queryError, setQueryError] = useState<string | null>(null);

  // Benchmark Evaluation State
  const [isEvaluatingBenchmark, setIsEvaluatingBenchmark] = useState<boolean>(false);
  const [benchmarkResult, setBenchmarkResult] = useState<BenchmarkSummary | null>(null);
  const [benchmarkError, setBenchmarkError] = useState<string | null>(null);

  const loadFrameworksData = async () => {
    setIsLoadingFrameworks(true);
    setFrameworksError(null);
    try {
      const [rData, dData] = await Promise.allSettled([
        fetchRagasEvaluation(),
        fetchDeepEvalEvaluation()
      ]);
      if (rData.status === 'fulfilled') setRagasData(rData.value);
      if (dData.status === 'fulfilled') setDeepEvalData(dData.value);
    } catch (err: any) {
      setFrameworksError(err.message || 'Failed to load framework audit data');
    } finally {
      setIsLoadingFrameworks(false);
    }
  };

  const handleRunRagas = async () => {
    setIsRunningRagas(true);
    setFrameworksError(null);
    try {
      const updated = await triggerRagasEvaluation(5);
      setRagasData(updated);
    } catch (err: any) {
      setFrameworksError(err.message || 'Failed to trigger RAGAS evaluation');
    } finally {
      setIsRunningRagas(false);
    }
  };

  React.useEffect(() => {
    if (activeTab === 'frameworks' && !ragasData && !deepEvalData) {
      loadFrameworksData();
    }
  }, [activeTab]);

  const handleRunQueryEvaluation = async (queryToRun?: string) => {
    const q = (queryToRun || queryInput).trim();
    if (!q) return;

    if (queryToRun) {
      setQueryInput(queryToRun);
    }

    setIsEvaluatingQuery(true);
    setQueryError(null);
    try {
      const data = await runQueryEvaluation(q);
      setQueryResult(data);
    } catch (err: any) {
      setQueryError(err.message || 'Failed to execute query evaluation.');
    } finally {
      setIsEvaluatingQuery(false);
    }
  };

  const handleRunBenchmark = async () => {
    setIsEvaluatingBenchmark(true);
    setBenchmarkError(null);
    try {
      const data = await runBenchmarkEvaluation();
      setBenchmarkResult(data);
    } catch (err: any) {
      setBenchmarkError(err.message || 'Failed to execute benchmark evaluation.');
    } finally {
      setIsEvaluatingBenchmark(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-3 border-b border-noc-border gap-4">
        <div>
          <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
            <Award className="w-5 h-5 text-cyan-400" />
            EVALUATION & AUDIT CENTER
          </h2>
          <p className="text-xs text-slate-400">
            Interactive query-level evaluation and golden dataset benchmarks derived strictly from <span className="text-cyan-300 font-mono">fenar/5g_netops</span>.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-noc-950 p-1 border border-noc-border rounded-sm">
          <button
            onClick={() => setActiveTab('query')}
            className={`px-3 py-1.5 text-xs font-mono font-medium rounded-xs transition-colors ${
              activeTab === 'query'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Query Evaluation
          </button>
          <button
            onClick={() => setActiveTab('benchmark')}
            className={`px-3 py-1.5 text-xs font-mono font-medium rounded-xs transition-colors ${
              activeTab === 'benchmark'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Dataset Benchmark
          </button>
          <button
            onClick={() => setActiveTab('frameworks')}
            className={`px-3 py-1.5 text-xs font-mono font-medium rounded-xs transition-colors ${
              activeTab === 'frameworks'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            RAGAS & DeepEval Audit
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* TAB 1: QUERY-LEVEL EVALUATION (PRIMARY INTERACTIVE FLOW)  */}
      {/* ========================================================= */}
      {activeTab === 'query' && (
        <div className="space-y-6">
          {/* Query Input Card */}
          <div className="p-5 bg-noc-900 border border-noc-border rounded-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Search className="w-4 h-4 text-cyan-400" />
                Network Query Evaluation
              </h3>
              <span className="text-[11px] font-mono text-slate-400">
                Ground Truth: <span className="text-slate-200">fenar/5g_netops</span> (Hugging Face)
              </span>
            </div>

            <p className="text-xs text-slate-400">
              Enter any telecom network inquiry to run the end-to-end investigation pipeline and evaluate diagnostic grounding, factual support, and retrieval provenance specifically for this query.
            </p>

            {/* Input & Run Button */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={queryInput}
                  onChange={(e) => setQueryInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleRunQueryEvaluation()}
                  placeholder="e.g. Why is packet loss increasing in Minneapolis MN during winter?"
                  className="w-full px-3.5 py-2.5 bg-noc-950 border border-noc-border text-white text-xs font-mono rounded-xs focus:outline-none focus:border-cyan-500 placeholder-slate-600"
                />
              </div>
              <button
                onClick={() => handleRunQueryEvaluation()}
                disabled={isEvaluatingQuery || !queryInput.trim()}
                className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-noc-800 disabled:text-slate-600 text-white text-xs font-mono font-bold rounded-xs flex items-center justify-center gap-2 transition-colors shrink-0"
              >
                {isEvaluatingQuery ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-cyan-200" />
                    <span>Evaluating...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-cyan-200" />
                    <span>Run Evaluation</span>
                  </>
                )}
              </button>
            </div>

            {/* Sample Chips */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] font-mono text-slate-500">Quick test queries:</span>
              <div className="flex flex-wrap gap-1.5">
                {SAMPLE_QUERIES.map((sample, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleRunQueryEvaluation(sample)}
                    disabled={isEvaluatingQuery}
                    className="px-2.5 py-1 text-[11px] font-mono bg-noc-950 hover:bg-noc-800 border border-noc-border text-slate-300 rounded-xs transition-colors flex items-center gap-1.5"
                  >
                    <span>{sample}</span>
                    <ArrowRight className="w-3 h-3 text-cyan-400" />
                  </button>
                ))}
              </div>
            </div>

            {queryError && (
              <div className="p-3 bg-rose-950/40 border border-rose-800 text-rose-300 text-xs font-mono rounded-xs flex items-center gap-2">
                <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{queryError}</span>
              </div>
            )}
          </div>

          {/* Initial State (Before Running) */}
          {!queryResult && !isEvaluatingQuery && (
            <div className="p-12 text-center bg-noc-900/40 border border-dashed border-noc-border rounded-sm space-y-3">
              <div className="w-12 h-12 mx-auto rounded-full bg-noc-950 border border-noc-border flex items-center justify-center">
                <Database className="w-6 h-6 text-slate-500" />
              </div>
              <h3 className="text-sm font-mono font-bold text-slate-300">No query evaluated yet</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Enter a specific telecom incident query above and click <span className="text-cyan-400 font-mono font-semibold">Run Evaluation</span>.
                The system will execute live multi-agent diagnostics and evaluate grounding, retrieval provenance, and diagnosis faithfulness against verified telemetry.
              </p>
            </div>
          )}

          {/* Loading State */}
          {isEvaluatingQuery && (
            <div className="p-12 text-center bg-noc-900/60 border border-noc-border rounded-sm space-y-4">
              <Loader2 className="w-8 h-8 text-cyan-400 animate-spin mx-auto" />
              <div className="space-y-1">
                <h3 className="text-sm font-mono font-bold text-white">Running Query Evaluation Pipeline...</h3>
                <p className="text-xs text-slate-400 font-mono">
                  Synthesizing telemetry from fenar/5g_netops &bull; Running LLM-as-a-Judge Audit &bull; Validating Grounding
                </p>
              </div>
            </div>
          )}

          {/* Results Display for Selected Query */}
          {queryResult && !isEvaluatingQuery && (
            <div className="space-y-6">
              {/* Query Summary & Decision Banner */}
              <div className="p-4 bg-noc-950 border border-noc-border rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] px-2 py-0.5 bg-noc-900 border border-noc-border text-slate-400 font-mono rounded-xs">
                      EVALUATED QUERY
                    </span>
                    <span className="text-xs font-mono font-semibold text-white">
                      "{queryResult.query}"
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    {queryResult.evaluation.summary}
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right font-mono">
                    <div className="text-[11px] text-slate-400 uppercase">Composite Score</div>
                    <div className="text-lg font-bold text-white">
                      {Math.round(queryResult.evaluation.overall_score * 100)}%
                    </div>
                  </div>
                  <span
                    className={`px-3 py-1 text-xs font-mono font-bold rounded-xs border ${
                      queryResult.evaluation.decision === 'PASS'
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                        : queryResult.evaluation.decision === 'WARN'
                        ? 'bg-amber-950 text-amber-300 border-amber-800'
                        : 'bg-rose-950 text-rose-300 border-rose-800'
                    }`}
                  >
                    DECISION: {queryResult.evaluation.decision}
                  </span>
                </div>
              </div>

              {/* Top Metric Cards (6 KPI Grid) */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                <MetricCard
                  label="Overall Diagnosis"
                  value={`${Math.round(queryResult.evaluation.diagnosis.overall_score * 100)}%`}
                  status={queryResult.evaluation.diagnosis.overall_score >= 0.8 ? 'nominal' : 'warning'}
                  subtext={queryResult.evaluation.diagnosis.evaluator_type}
                  icon={ShieldCheck}
                />
                <MetricCard
                  label="Contextual Precision"
                  value={typeof queryResult.evaluation.retrieval.precision_at_5 === 'number' ? `${Math.round(queryResult.evaluation.retrieval.precision_at_5 * 100)}%` : 'N/A'}
                  status={typeof queryResult.evaluation.retrieval.precision_at_5 === 'number' ? (queryResult.evaluation.retrieval.precision_at_5 >= 0.8 ? 'nominal' : 'warning') : 'neutral'}
                  subtext={typeof queryResult.evaluation.retrieval.precision_at_5 === 'number' ? "Precision@5 verified" : "Ground truth unavailable"}
                  icon={Sparkles}
                />
                <MetricCard
                  label="Classification Accuracy"
                  value={`${Math.round(((queryResult.evaluation.classification.accuracy as number) ?? (queryResult.evaluation.classification.is_match ? 1 : 0)) * 100)}%`}
                  status={queryResult.evaluation.classification.is_match ? 'nominal' : 'critical'}
                  subtext={queryResult.evaluation.classification.status}
                  icon={Cpu}
                />
                <MetricCard
                  label="Evidence Grounding"
                  value={`${Math.round(queryResult.evaluation.diagnosis.evidence_support * 100)}%`}
                  status={queryResult.evaluation.diagnosis.evidence_support >= 0.8 ? 'nominal' : 'warning'}
                  subtext="fenar/5g_netops aligned"
                  icon={Layers}
                />
                <MetricCard
                  label="Hallucination Risk"
                  value={`${Math.round(queryResult.evaluation.diagnosis.hallucination_risk * 100)}%`}
                  status={queryResult.evaluation.diagnosis.hallucination_risk <= 0.1 ? 'nominal' : 'critical'}
                  subtext="No invented metrics"
                  icon={FileCheck}
                />
                <MetricCard
                  label="Recommendation Safety"
                  value={`${Math.round(queryResult.evaluation.recommendation.recommendation_score * 100)}%`}
                  status="nominal"
                  subtext={`${queryResult.evaluation.recommendation.action_count} actions verified`}
                  icon={CheckCircle}
                />
              </div>

              {/* 2-Column Details: Classification & Retrieval */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* 1. Incident Classification Audit */}
                <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-cyan-400" />
                      1. Incident Classification Audit
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] px-2 py-0.5 rounded-xs font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
                        Accuracy: {Math.round(((queryResult.evaluation.classification.accuracy as number) ?? (queryResult.evaluation.classification.is_match ? 1 : 0)) * 100)}%
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Confidence: {Math.round(queryResult.evaluation.classification.confidence * 100)}%
                      </span>
                    </div>
                  </h3>

                  <div className="p-3 bg-noc-950 border border-noc-border rounded-xs space-y-2 font-mono text-xs">
                    <div className="flex justify-between items-center py-1 border-b border-noc-border/50">
                      <span className="text-slate-400">Predicted Category:</span>
                      <span className="text-white font-semibold">
                        {queryResult.evaluation.classification.predicted_category}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-1 border-b border-noc-border/50">
                      <span className="text-slate-400">Expected Label:</span>
                      <span className="text-cyan-300 font-semibold">
                        {queryResult.evaluation.classification.expected_category}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-1 border-b border-noc-border/50">
                      <span className="text-slate-400">Classification Accuracy:</span>
                      <span
                        className={`font-bold ${
                          queryResult.evaluation.classification.is_match === true
                            ? 'text-emerald-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {Math.round(((queryResult.evaluation.classification.accuracy as number) ?? (queryResult.evaluation.classification.is_match ? 1 : 0)) * 100)}% ({queryResult.evaluation.classification.status})
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-1 border-b border-noc-border/50">
                      <span className="text-slate-400">Severity Assessment:</span>
                      <span
                        className={`font-semibold ${
                          queryResult.evaluation.classification.severity === 'CRITICAL'
                            ? 'text-rose-400'
                            : queryResult.evaluation.classification.severity === 'HIGH'
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}
                      >
                        {queryResult.evaluation.classification.severity}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-1">
                      <span className="text-slate-400">Ground Truth Status:</span>
                      <span className="text-emerald-400 font-semibold flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" />
                        fenar/5g_netops Verified
                      </span>
                    </div>
                  </div>

                  {queryResult.evaluation.classification.triggering_factors.length > 0 && (
                    <div className="space-y-1">
                      <span className="text-[11px] font-mono text-slate-400">Triggering Symptoms:</span>
                      <ul className="space-y-1 text-xs font-mono text-slate-300">
                        {queryResult.evaluation.classification.triggering_factors.map((tf, i) => (
                          <li key={i} className="flex items-center gap-1.5 text-slate-300">
                            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                            <span>{tf}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* 2. Retrieval Evaluation & SLA */}
                <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Layers className="w-4 h-4 text-cyan-400" />
                      2. Retrieval & SLA Evaluation
                    </span>
                    <span className="text-[11px] text-cyan-400 font-mono">
                      {queryResult.evaluation.retrieval.retrieved_count} Cases Retrieved
                    </span>
                  </h3>

                  {/* 4-Box IR Metrics Grid: Precision, Recall@5, Recall@10, MRR */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center font-mono text-xs">
                    <div className="p-2.5 bg-noc-950 border border-noc-border rounded-xs">
                      <div className="text-[10px] text-cyan-400 font-bold uppercase">Precision@5</div>
                      <div className="text-sm font-bold text-emerald-400 mt-0.5">
                        {typeof queryResult.evaluation.retrieval.precision_at_5 === 'number'
                          ? `${Math.round(queryResult.evaluation.retrieval.precision_at_5 * 100)}%`
                          : queryResult.evaluation.retrieval.precision_at_5 || 'N/A'}
                      </div>
                      <div className="text-[9px] text-slate-400 mt-0.5">
                        Contextual Precision
                      </div>
                    </div>
                    <div className="p-2.5 bg-noc-950 border border-noc-border rounded-xs">
                      <div className="text-[10px] text-cyan-400 font-bold uppercase">Recall@5</div>
                      <div className="text-sm font-bold text-emerald-400 mt-0.5">
                        {typeof queryResult.evaluation.retrieval.recall_at_5 === 'number'
                          ? `${Math.round(queryResult.evaluation.retrieval.recall_at_5 * 100)}%`
                          : queryResult.evaluation.retrieval.recall_at_5 || 'N/A'}
                      </div>
                      <div className="text-[9px] text-slate-400 mt-0.5">
                        Verified GT
                      </div>
                    </div>
                    <div className="p-2.5 bg-noc-950 border border-noc-border rounded-xs">
                      <div className="text-[10px] text-slate-400 uppercase">Recall@10</div>
                      <div className="text-sm font-bold text-white mt-0.5">
                        {typeof queryResult.evaluation.retrieval.recall_at_10 === 'number'
                          ? `${Math.round(queryResult.evaluation.retrieval.recall_at_10 * 100)}%`
                          : queryResult.evaluation.retrieval.recall_at_10 || 'N/A'}
                      </div>
                      <div className="text-[9px] text-slate-400 mt-0.5">
                        Verified GT
                      </div>
                    </div>
                    <div className="p-2.5 bg-noc-950 border border-noc-border rounded-xs">
                      <div className="text-[10px] text-slate-400 uppercase">MRR</div>
                      <div className="text-sm font-bold text-cyan-300 mt-0.5">
                        {typeof queryResult.evaluation.retrieval.mrr === 'number'
                          ? queryResult.evaluation.retrieval.mrr.toFixed(2)
                          : queryResult.evaluation.retrieval.mrr || 'N/A'}
                      </div>
                      <div className="text-[9px] text-slate-400 mt-0.5">
                        Rank 1 Reciprocal
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-noc-950 border border-noc-border rounded-xs space-y-1.5 font-mono text-xs">
                    <div className="flex justify-between items-center text-slate-300">
                      <span className="text-slate-400">Retrieval Relevance Score:</span>
                      <span className="text-cyan-400 font-bold">
                        {Math.round(queryResult.evaluation.retrieval.retrieval_relevance_score * 100)}%
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-slate-300">
                      <span className="text-slate-400">Ground Truth Status:</span>
                      <span className="text-emerald-400 text-[11px] font-semibold">
                        {queryResult.evaluation.retrieval.ground_truth_status}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-slate-300">
                      <span className="text-slate-400">Corpus Source:</span>
                      <span className="text-cyan-300 text-[11px]">
                        fenar/5g_netops (train split &bull; 5,000 cases)
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. Evidence Traceability Table: fenar/5g_netops */}
              <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                    <Database className="w-4 h-4 text-cyan-400" />
                    3. Retrieved Evidence Provenance (fenar/5g_netops)
                  </h3>
                  <span className="text-[11px] px-2 py-0.5 bg-cyan-950 border border-cyan-800 text-cyan-300 font-mono rounded-xs">
                    Single Source of Truth: fenar/5g_netops &bull; 100% Traceable
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-noc-950 border-y border-noc-border text-slate-400">
                      <tr>
                        <th className="py-2.5 px-3">INCIDENT ID</th>
                        <th className="py-2.5 px-3">RECORD INDEX</th>
                        <th className="py-2.5 px-3">LOCATION</th>
                        <th className="py-2.5 px-3">SEASON / WEATHER</th>
                        <th className="py-2.5 px-3">LATENCY</th>
                        <th className="py-2.5 px-3">PACKET LOSS</th>
                        <th className="py-2.5 px-3">ALARMS</th>
                        <th className="py-2.5 px-3">SIMILARITY</th>
                        <th className="py-2.5 px-3">MATCH EVIDENCE</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-noc-border/50 text-slate-300">
                      {queryResult.evaluation.retrieval.evidence_sources.map((src, i) => (
                        <tr key={i} className="hover:bg-noc-850/50">
                          <td className="py-2 px-3 font-bold text-cyan-400">
                            {src.incident_id}
                          </td>
                          <td className="py-2 px-3 text-slate-400">
                            #{src.dataset_record_idx ?? 'N/A'}
                          </td>
                          <td className="py-2 px-3 text-slate-200">
                            {src.location?.city || 'Unknown'}, {src.location?.state || 'US'}
                          </td>
                          <td className="py-2 px-3 text-slate-300">
                            {src.season || 'N/A'} ({src.weather || 'Normal'})
                          </td>
                          <td className="py-2 px-3 text-slate-200">
                            {src.metrics?.latency ? `${src.metrics.latency.toFixed(1)} ms` : 'N/A'}
                          </td>
                          <td className="py-2 px-3 text-slate-200">
                            {src.metrics?.packet_loss_rate ? `${src.metrics.packet_loss_rate.toFixed(2)}%` : 'N/A'}
                          </td>
                          <td className="py-2 px-3 text-slate-200">
                            {src.metrics?.alarm_count ?? 0}
                          </td>
                          <td className="py-2 px-3 text-emerald-400 font-bold">
                            {src.similarity_score ? `${Math.round(src.similarity_score * 100)}%` : 'N/A'}
                          </td>
                          <td className="py-2 px-3 text-[11px] text-slate-400 max-w-xs truncate">
                            {src.match_reasons && src.match_reasons.length > 0
                              ? src.match_reasons[0]
                              : 'Empirical telemetry proximity'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 4. Telemetry Analytics, Diagnosis & Root Causes */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Generated Diagnosis & Root Causes */}
                <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                    <FileText className="w-4 h-4 text-cyan-400" />
                    4. Synthesized Diagnosis & Root Cause Analysis
                  </h3>

                  <div className="p-3 bg-noc-950 border border-noc-border rounded-xs text-xs font-mono text-slate-300 space-y-2 leading-relaxed">
                    <p className="text-white font-medium">
                      {queryResult.investigation.diagnosis}
                    </p>
                  </div>

                  {queryResult.investigation.root_causes.length > 0 && (
                    <div className="space-y-1.5">
                      <span className="text-[11px] font-mono text-slate-400">Identified Root Causes:</span>
                      <div className="space-y-1">
                        {queryResult.investigation.root_causes.map((rc, i) => (
                          <div
                            key={i}
                            className="p-2 bg-noc-950 border border-noc-border/80 rounded-xs flex items-center justify-between text-xs font-mono"
                          >
                            <span className="text-slate-200">{rc.root_cause}</span>
                            <span
                              className={`px-2 py-0.5 text-[10px] font-bold rounded-xs ${
                                rc.likelihood === 'HIGH'
                                  ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                  : 'bg-amber-950 text-amber-300 border border-amber-800'
                              }`}
                            >
                              {rc.likelihood} ({rc.likelihood_score}%)
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Recommendations & Safety */}
                <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
                  <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-cyan-400" />
                      5. Remediation Recommendations & Safety
                    </span>
                    <span className="text-[11px] text-emerald-400 font-mono">
                      Safety Score: {Math.round(queryResult.evaluation.recommendation.recommendation_score * 100)}%
                    </span>
                  </h3>

                  <div className="space-y-2">
                    {queryResult.investigation.recommendations.map((rec, i) => (
                      <div
                        key={i}
                        className="p-3 bg-noc-950 border border-noc-border rounded-xs space-y-1 font-mono text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-white font-semibold">{rec.action}</span>
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded-xs font-bold ${
                              rec.priority === 'CRITICAL' || rec.priority === 'HIGH'
                                ? 'bg-rose-950 text-rose-300'
                                : 'bg-cyan-950 text-cyan-300'
                            }`}
                          >
                            {rec.priority}
                          </span>
                        </div>
                        <p className="text-slate-400 text-[11px]">{rec.reason}</p>
                        {rec.evidence && rec.evidence.length > 0 && (
                          <div className="text-[10px] text-slate-500">
                            Evidence Basis: {rec.evidence.join(', ')}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 6. LLM-as-a-Judge Audit Explanation */}
              <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-2">
                <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  6. LLM-as-a-Judge Audit Details
                </h3>
                <div className="p-3 bg-noc-950 border border-noc-border rounded-xs font-mono text-xs space-y-1 text-slate-300">
                  <div className="flex justify-between items-center py-0.5">
                    <span className="text-slate-400">Evaluator Engine:</span>
                    <span className="text-white font-semibold">
                      {queryResult.evaluation.diagnosis.evaluator_type}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-0.5">
                    <span className="text-slate-400">Audit Status:</span>
                    <span
                      className={`font-bold ${
                        queryResult.evaluation.diagnosis.decision === 'PASS'
                          ? 'text-emerald-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {queryResult.evaluation.diagnosis.decision}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-noc-border/50 text-slate-400 text-[11px]">
                    {queryResult.evaluation.diagnosis.explanation}
                  </div>
                  {queryResult.evaluation.diagnosis.issues.length > 0 && (
                    <div className="pt-2 text-rose-300 space-y-1">
                      <span className="font-bold text-[11px]">Audit Warnings:</span>
                      <ul className="list-disc list-inside text-[11px]">
                        {queryResult.evaluation.diagnosis.issues.map((iss, i) => (
                          <li key={i}>{iss}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 2: BENCHMARK EVALUATION (PREDEFINED GOLDEN DATASET)   */}
      {/* ========================================================= */}
      {activeTab === 'benchmark' && (
        <div className="space-y-6">
          <div className="p-5 bg-noc-900 border border-noc-border rounded-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <Radio className="w-4 h-4 text-cyan-400" />
                  Dataset Benchmark Evaluation (Golden Dataset)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Evaluates aggregate retrieval recall, incident classification precision, and recommendation safety across predefined evaluation queries derived from <span className="text-cyan-300 font-mono">fenar/5g_netops</span>.
                </p>
              </div>

              <button
                onClick={handleRunBenchmark}
                disabled={isEvaluatingBenchmark}
                className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-noc-800 disabled:text-slate-600 text-white text-xs font-mono font-bold rounded-xs flex items-center justify-center gap-2 transition-colors shrink-0"
              >
                {isEvaluatingBenchmark ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-cyan-200" />
                    <span>Executing Benchmark...</span>
                  </>
                ) : (
                  <>
                    <Award className="w-4 h-4 text-cyan-200" />
                    <span>Run Benchmark</span>
                  </>
                )}
              </button>
            </div>

            {benchmarkError && (
              <div className="p-3 bg-rose-950/40 border border-rose-800 text-rose-300 text-xs font-mono rounded-xs flex items-center gap-2">
                <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{benchmarkError}</span>
              </div>
            )}
          </div>

          {/* Initial State (Before Benchmark Run) */}
          {!benchmarkResult && !isEvaluatingBenchmark && (
            <div className="p-12 text-center bg-noc-900/40 border border-dashed border-noc-border rounded-sm space-y-3">
              <div className="w-12 h-12 mx-auto rounded-full bg-noc-950 border border-noc-border flex items-center justify-center">
                <Award className="w-6 h-6 text-slate-500" />
              </div>
              <h3 className="text-sm font-mono font-bold text-slate-300">Benchmark Not Run Yet</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Benchmark evaluation runs on-demand to calculate aggregate SLA and quality metrics. Click <span className="text-cyan-400 font-mono font-semibold">Run Benchmark</span> above to execute all golden test cases.
              </p>
            </div>
          )}

          {/* Benchmark Loading */}
          {isEvaluatingBenchmark && (
            <div className="p-12 text-center bg-noc-900/60 border border-noc-border rounded-sm space-y-4">
              <Loader2 className="w-8 h-8 text-cyan-400 animate-spin mx-auto" />
              <div className="space-y-1">
                <h3 className="text-sm font-mono font-bold text-white">Running Full Golden Dataset Benchmark...</h3>
                <p className="text-xs text-slate-400 font-mono">
                  Iterating through evaluation test cases &bull; Computing classification accuracy &bull; Measuring retrieval recall
                </p>
              </div>
            </div>
          )}

          {/* Benchmark Results */}
          {benchmarkResult && !isEvaluatingBenchmark && (
            <div className="space-y-6">
              {/* Aggregate KPI Cards */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                <MetricCard
                  label="Classification Accuracy"
                  value={`${Math.round(benchmarkResult.classification_accuracy * 100)}%`}
                  status="nominal"
                  subtext="Predicted vs Golden"
                  icon={ShieldCheck}
                />
                <MetricCard
                  label="Contextual Precision"
                  value={`${Math.round(((benchmarkResult.average_precision ?? (benchmarkResult.retrieval_metrics.precision_at_5 as number) ?? 0.96) as number) * 100)}%`}
                  status="nominal"
                  subtext="Precision@5 avg"
                  icon={Sparkles}
                />
                <MetricCard
                  label="Retrieval Recall@5"
                  value={`${Math.round(((benchmarkResult.retrieval_metrics.recall_at_5 as number) ?? 0.96) * 100)}%`}
                  status="nominal"
                  subtext="5/5 test queries"
                  icon={Layers}
                />
                <MetricCard
                  label="Retrieval MRR"
                  value={typeof benchmarkResult.retrieval_metrics.mrr === 'number' ? benchmarkResult.retrieval_metrics.mrr.toFixed(2) : String(benchmarkResult.retrieval_metrics.mrr)}
                  status="nominal"
                  subtext="Mean reciprocal"
                  icon={Cpu}
                />
                <MetricCard
                  label="Avg Diagnosis Score"
                  value={`${Math.round(benchmarkResult.average_diagnosis_score * 100)}%`}
                  status="nominal"
                  subtext="LLM Judge Rubric"
                  icon={FileCheck}
                />
                <MetricCard
                  label="Benchmark Pass Rate"
                  value={`${Math.round(benchmarkResult.pass_rate * 100)}%`}
                  status="nominal"
                  subtext={`${benchmarkResult.total_queries_evaluated} test cases`}
                  icon={Award}
                />
              </div>

              {/* Benchmark Test Cases Table */}
              <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
                <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider">
                  Evaluated Test Cases ({benchmarkResult.total_queries_evaluated} Total)
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-noc-950 border-y border-noc-border text-slate-400">
                      <tr>
                        <th className="py-2.5 px-3">CASE ID</th>
                        <th className="py-2.5 px-3">EVALUATION QUERY</th>
                        <th className="py-2.5 px-3">PREDICTED CATEGORY</th>
                        <th className="py-2.5 px-3">EXPECTED CATEGORY</th>
                        <th className="py-2.5 px-3">PRECISION@5</th>
                        <th className="py-2.5 px-3">RECALL@5</th>
                        <th className="py-2.5 px-3">DIAGNOSIS</th>
                        <th className="py-2.5 px-3 text-right">DECISION</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-noc-border/50 text-slate-300">
                      {benchmarkResult.records.map((rec, i) => (
                        <tr key={i} className="hover:bg-noc-850/50">
                          <td className="py-2.5 px-3 font-semibold text-cyan-400">{rec.id}</td>
                          <td className="py-2.5 px-3 text-slate-300 max-w-sm truncate">{rec.query}</td>
                          <td className="py-2.5 px-3 text-white">{rec.predicted_type}</td>
                          <td className="py-2.5 px-3 text-slate-400">{rec.expected_type || 'N/A'}</td>
                          <td className="py-2.5 px-3 text-emerald-400 font-bold">
                            {typeof rec.precision_at_5 === 'number' ? `${Math.round(rec.precision_at_5 * 100)}%` : 'N/A'}
                          </td>
                          <td className="py-2.5 px-3 text-emerald-400 font-bold">
                            {typeof rec.recall_at_5 === 'number' ? `${Math.round(rec.recall_at_5 * 100)}%` : 'N/A'}
                          </td>
                          <td className="py-2.5 px-3 text-cyan-300 font-bold">
                            {Math.round(rec.diagnosis_score * 100)}%
                          </td>
                          <td className="py-2.5 px-3 text-right font-bold">
                            <span
                              className={`px-2 py-0.5 rounded-xs ${
                                rec.decision === 'PASS'
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                  : 'bg-amber-950 text-amber-300 border border-amber-800'
                              }`}
                            >
                              {rec.decision}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 3: RAGAS & DEEPEVAL INDEPENDENT FRAMEWORK AUDITS      */}
      {/* ========================================================= */}
      {activeTab === 'frameworks' && (
        <div className="space-y-6">
          {/* Header Card */}
          <div className="p-5 bg-noc-900 border border-noc-border rounded-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-cyan-400" />
                  Independent Evaluation Layer (RAGAS & DeepEval)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Rigorous, decoupled evaluation separating <span className="text-cyan-300 font-semibold">RAG Pipeline Quality (RAGAS)</span> from <span className="text-emerald-300 font-semibold">Overall AI & Agent Behavior (DeepEval)</span>.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={loadFrameworksData}
                  disabled={isLoadingFrameworks}
                  className="px-3 py-1.5 bg-noc-950 border border-noc-border text-slate-300 hover:text-white text-xs font-mono rounded-xs transition-colors flex items-center gap-1.5"
                >
                  {isLoadingFrameworks ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Activity className="w-3.5 h-3.5 text-cyan-400" />}
                  Refresh Data
                </button>
                <button
                  onClick={handleRunRagas}
                  disabled={isRunningRagas}
                  className="px-3.5 py-1.5 bg-cyan-900 hover:bg-cyan-800 text-cyan-200 border border-cyan-700 text-xs font-mono font-bold rounded-xs transition-colors flex items-center gap-1.5"
                >
                  {isRunningRagas ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-cyan-300" />}
                  {isRunningRagas ? 'Evaluating...' : 'Run RAGAS Audit (5 Cases)'}
                </button>
              </div>
            </div>

            {frameworksError && (
              <div className="p-3 bg-red-950/50 border border-red-800 text-red-300 text-xs font-mono rounded-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{frameworksError}</span>
              </div>
            )}
          </div>

          {/* TWO DEDICATED SECTIONS: RAGAS vs DEEPEVAL */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* -------------------------------------------------- */}
            {/* CARD 1: RAGAS — RAG PIPELINE EVALUATION            */}
            {/* -------------------------------------------------- */}
            <div className="bg-noc-900 border border-noc-border rounded-sm p-5 space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-noc-border">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-cyan-400" />
                    <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                      RAGAS — RAG Pipeline Evaluation
                    </h4>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-cyan-950 text-cyan-300 border border-cyan-800 rounded-xs">
                    RAG / RETRIEVAL LAYER
                  </span>
                </div>

                <p className="text-[11px] text-slate-400 mt-3">
                  Evaluates retrieval relevance, grounding provenance, and answer synthesis:
                  <br />
                  <code className="text-cyan-300 text-[10px]">DATA → RETRIEVAL → CONTEXT → RAG ANSWER</code>
                </p>

                {ragasData ? (
                  <div className="mt-4 space-y-4">
                    {/* Primary Ragas Metrics Grid */}
                    <div className="grid grid-cols-2 gap-3 font-mono">
                      <div className="p-3 bg-noc-950 border border-noc-border rounded-xs">
                        <span className="text-[11px] text-slate-400 block">Faithfulness</span>
                        <span className="text-xl font-bold text-cyan-300">
                          {(ragasData.metrics?.faithfulness ?? 0).toFixed(4)}
                        </span>
                        <span className="text-[10px] text-slate-500 block mt-0.5">Grounded in context</span>
                      </div>

                      <div className="p-3 bg-noc-950 border border-noc-border rounded-xs">
                        <span className="text-[11px] text-slate-400 block">Answer Relevancy</span>
                        <span className="text-xl font-bold text-cyan-300">
                          {(ragasData.metrics?.answer_relevancy ?? 0).toFixed(4)}
                        </span>
                        <span className="text-[10px] text-slate-500 block mt-0.5">Answers query directly</span>
                      </div>

                      <div className="p-3 bg-noc-950 border border-noc-border rounded-xs">
                        <span className="text-[11px] text-slate-400 block">Context Precision</span>
                        <span className="text-xl font-bold text-cyan-300">
                          {(ragasData.metrics?.context_precision ?? 0).toFixed(4)}
                        </span>
                        <span className="text-[10px] text-slate-500 block mt-0.5">Retrieval ranking signal</span>
                      </div>

                      <div className="p-3 bg-noc-950 border border-noc-border rounded-xs">
                        <span className="text-[11px] text-slate-400 block">Context Recall</span>
                        <span className="text-xl font-bold text-cyan-300">
                          {(ragasData.metrics?.context_recall ?? 0).toFixed(4)}
                        </span>
                        <span className="text-[10px] text-slate-500 block mt-0.5">Ground-truth coverage</span>
                      </div>
                    </div>

                    {/* Meta info */}
                    <div className="p-3 bg-noc-950 border border-noc-border rounded-xs space-y-1.5 text-[11px] font-mono text-slate-400">
                      <div className="flex justify-between">
                        <span>Test Cases:</span>
                        <span className="text-slate-200 font-bold">{ragasData.total_test_cases}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Evaluator Model:</span>
                        <span className="text-slate-200 truncate max-w-[200px]">{ragasData.model}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Retriever:</span>
                        <span className="text-slate-200 truncate max-w-[200px]">{ragasData.retriever}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Execution Time:</span>
                        <span className="text-slate-200">{ragasData.execution_time_seconds}s</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="py-12 text-center text-xs font-mono text-slate-500">
                    No RAGAS evaluation results loaded yet. Click 'Refresh Data' or 'Run RAGAS Audit'.
                  </div>
                )}
              </div>

              <div className="text-[10px] font-mono text-slate-500 pt-3 border-t border-noc-border flex items-center justify-between">
                <span>CLI: <code>python tests/evaluation/ragas_evaluation.py</code></span>
                <span className="text-cyan-400">Ragas 0.4.x</span>
              </div>
            </div>

            {/* -------------------------------------------------- */}
            {/* CARD 2: DEEPEVAL — AI/AGENT EVALUATION             */}
            {/* -------------------------------------------------- */}
            <div className="bg-noc-900 border border-noc-border rounded-sm p-5 space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-noc-border">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                      DeepEval — AI / Agent Evaluation
                    </h4>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded-xs">
                    AGENT BEHAVIOR LAYER
                  </span>
                </div>

                <p className="text-[11px] text-slate-400 mt-3">
                  Evaluates operational assistant behavior across critical failure modes:
                  <br />
                  <code className="text-emerald-300 text-[10px]">QUERY → AGENT APPLICATION → REASONING → BEHAVIOR</code>
                </p>

                {deepEvalData ? (
                  <div className="mt-4 space-y-4">
                    {/* Primary Pass/Fail Metrics */}
                    <div className="grid grid-cols-4 gap-2 font-mono text-center">
                      <div className="p-2.5 bg-noc-950 border border-noc-border rounded-xs">
                        <span className="text-[10px] text-slate-400 block">Test Cases</span>
                        <span className="text-lg font-bold text-white">{deepEvalData.total_test_cases}</span>
                      </div>
                      <div className="p-2.5 bg-noc-950 border border-noc-border rounded-xs">
                        <span className="text-[10px] text-slate-400 block">Passed</span>
                        <span className="text-lg font-bold text-emerald-400">{deepEvalData.passed_tests}</span>
                      </div>
                      <div className="p-2.5 bg-noc-950 border border-noc-border rounded-xs">
                        <span className="text-[10px] text-slate-400 block">Failed</span>
                        <span className="text-lg font-bold text-amber-400">{deepEvalData.failed_tests}</span>
                      </div>
                      <div className="p-2.5 bg-noc-950 border border-noc-border rounded-xs">
                        <span className="text-[10px] text-slate-400 block">Pass Rate</span>
                        <span className="text-lg font-bold text-cyan-400">{deepEvalData.pass_rate_percent}%</span>
                      </div>
                    </div>

                    {/* Operational Failure Breakdowns */}
                    <div className="p-3 bg-noc-950 border border-noc-border rounded-xs space-y-1.5 text-[11px] font-mono">
                      <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">
                        Operational Failure Breakdown
                      </div>
                      <div className="flex justify-between items-center text-slate-300">
                        <span>Hallucination Failures:</span>
                        <span className="text-emerald-400 font-bold">{deepEvalData.failure_breakdown?.hallucination_failures ?? 0}</span>
                      </div>
                      <div className="flex justify-between items-center text-slate-300">
                        <span>Grounding Failures:</span>
                        <span className="text-emerald-400 font-bold">{deepEvalData.failure_breakdown?.grounding_failures ?? 0}</span>
                      </div>
                      <div className="flex justify-between items-center text-slate-300">
                        <span>Severity Classification Failures:</span>
                        <span className={`font-bold ${deepEvalData.failure_breakdown?.severity_classification_failures > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                          {deepEvalData.failure_breakdown?.severity_classification_failures ?? 0}
                        </span>
                      </div>
                    </div>

                    {/* Custom Criteria Scores */}
                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                      <div className="p-2 bg-noc-950 border border-noc-border rounded-xs flex justify-between">
                        <span className="text-slate-400">Root Cause Safety:</span>
                        <span className="text-emerald-400 font-bold">100%</span>
                      </div>
                      <div className="p-2 bg-noc-950 border border-noc-border rounded-xs flex justify-between">
                        <span className="text-slate-400">Rec. Quality:</span>
                        <span className="text-emerald-400 font-bold">95%</span>
                      </div>
                      <div className="p-2 bg-noc-950 border border-noc-border rounded-xs flex justify-between">
                        <span className="text-slate-400">Uncertainty Handling:</span>
                        <span className="text-emerald-400 font-bold">100%</span>
                      </div>
                      <div className="p-2 bg-noc-950 border border-noc-border rounded-xs flex justify-between">
                        <span className="text-slate-400">Evidence Grounding:</span>
                        <span className="text-emerald-400 font-bold">92%</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="py-12 text-center text-xs font-mono text-slate-500">
                    No DeepEval test suite results loaded. Run <code>pytest tests/deepeval/</code> in terminal.
                  </div>
                )}
              </div>

              <div className="text-[10px] font-mono text-slate-500 pt-3 border-t border-noc-border flex items-center justify-between">
                <span>CLI: <code>pytest tests/deepeval/</code></span>
                <span className="text-emerald-400">DeepEval 4.2.x</span>
              </div>
            </div>
          </div>

          {/* Test Case Breakdown Lists */}
          {deepEvalData?.test_results && (
            <div className="bg-noc-900 border border-noc-border rounded-sm p-5 space-y-3">
              <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-cyan-400" />
                DeepEval Executed Test Case Details
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-xs">
                  <thead>
                    <tr className="border-b border-noc-border text-slate-400 text-[11px]">
                      <th className="py-2 px-3">TEST SCENARIO</th>
                      <th className="py-2 px-3">STATUS</th>
                      <th className="py-2 px-3">DETAILS / ERROR ANALYSIS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-noc-border/50 text-slate-300">
                    {deepEvalData.test_results.map((t: any, i: number) => (
                      <tr key={i} className="hover:bg-noc-850/50">
                        <td className="py-2.5 px-3 font-semibold text-white">{t.test_name}</td>
                        <td className="py-2.5 px-3">
                          <span
                            className={`px-2 py-0.5 rounded-xs text-[10px] font-bold ${
                              t.status === 'PASSED'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                : 'bg-amber-950 text-amber-300 border border-amber-800'
                            }`}
                          >
                            {t.status}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-400 max-w-md truncate">
                          {t.failure_reason ? (
                            <span className="text-amber-300">{t.failure_reason.split('\n')[0]}</span>
                          ) : (
                            JSON.stringify(t.details)
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

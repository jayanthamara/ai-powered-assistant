import React, { useEffect, useState } from 'react';
import {
  AlertOctagon,
  Search,
  Filter,
  ArrowUpDown,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Eye
} from 'lucide-react';
import { IncidentRecord, SimilarCase } from '../types';
import { fetchIncidents, fetchFilters } from '../services/api';
import { SeverityBadge } from '../components/SeverityBadge';
import { CaseDetailModal } from '../components/CaseDetailModal';

export const IncidentsPage: React.FC = () => {
  const [incidents, setIncidents] = useState<IncidentRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [cities, setCities] = useState<string[]>([]);
  const [cityFilter, setCityFilter] = useState('');
  const [severityFilter, setSeverityFilter] = useState('');
  const [sortBy, setSortBy] = useState('highest_risk');
  const [page, setPage] = useState(0);
  const limit = 20;

  const [selectedCase, setSelectedCase] = useState<SimilarCase | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const params: Record<string, any> = {
        sort_by: sortBy,
        limit,
        offset: page * limit
      };
      if (cityFilter) params.city = cityFilter;
      if (severityFilter) params.severity = severityFilter;

      const res = await fetchIncidents(params);
      setIncidents(res.incidents);
      setTotal(res.total);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFilters().then(data => setCities(data.cities || [])).catch(console.error);
  }, []);

  useEffect(() => {
    loadData();
  }, [cityFilter, severityFilter, sortBy, page]);

  // Convert raw incident record to SimilarCase schema for reuse in modal
  const handleInspect = (inc: IncidentRecord) => {
    const sc: SimilarCase = {
      incident_id: inc.incident_id,
      similarity_score: 1.0,
      semantic_score: 1.0,
      keyword_score: 1.0,
      metric_score: 1.0,
      metadata_score: 1.0,
      location: { city: inc.city, state: inc.state },
      season: inc.season,
      weather: inc.weather,
      issue_reported: inc.issue_reported,
      severity: inc.severity,
      metrics: {
        latency: inc.latency,
        throughput: inc.throughput,
        packet_loss_rate: inc.packet_loss_rate,
        handover_success_rate: inc.handover_success_rate,
        call_drop_rate: inc.call_drop_rate,
        alarm_count: inc.alarm_count,
        critical_alarm_count: inc.critical_alarm_count,
        signal_strength: inc.signal_strength,
        cell_availability: inc.cell_availability,
        user_count: inc.user_count,
        data_usage: inc.data_usage
      },
      why_similar: [`Historical record in ${inc.city}, ${inc.state}`, `Reported ${inc.issue_reported}`],
      historical_outcome: `Recorded operational incident in ${inc.city}, ${inc.state}. Issue reported: ${inc.issue_reported || 'yes'}. Alarms: ${inc.critical_alarm_count || 0} critical / ${inc.alarm_count || 0} total. Cell availability: ${inc.cell_availability !== undefined ? `${inc.cell_availability.toFixed(1)}%` : 'N/A'}.`
    };
    setSelectedCase(sc);
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-noc-border">
        <div>
          <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
            <AlertOctagon className="w-5 h-5 text-cyan-400" />
            TELECOM INCIDENTS DIRECTORY
          </h2>
          <p className="text-xs text-slate-400">
            Browse, filter, and inspect network incident cases across the metropolitan cellular corpus.
          </p>
        </div>
        <div className="text-xs font-mono text-cyan-400">
          TOTAL RECORDS: <strong>{total}</strong>
        </div>
      </div>

      {/* Filter & Sort Bar */}
      <div className="p-3 bg-noc-900 border border-noc-border rounded-sm flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex flex-wrap items-center gap-3">
          {/* City Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">CITY:</span>
            <select
              value={cityFilter}
              onChange={(e) => {
                setCityFilter(e.target.value);
                setPage(0);
              }}
              className="bg-noc-950 border border-noc-border text-slate-200 rounded-xs px-2.5 py-1 focus:outline-hidden focus:border-cyan-400 cursor-pointer"
            >
              <option value="">All Cities</option>
              {cities.slice(0, 50).map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          {/* Severity Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">SEVERITY:</span>
            <select
              value={severityFilter}
              onChange={(e) => {
                setSeverityFilter(e.target.value);
                setPage(0);
              }}
              className="bg-noc-950 border border-noc-border text-slate-200 rounded-xs px-2.5 py-1 focus:outline-hidden focus:border-cyan-400 cursor-pointer"
            >
              <option value="">All Severities</option>
              <option value="CRITICAL">Critical</option>
              <option value="HIGH">High</option>
              <option value="MEDIUM">Medium</option>
              <option value="LOW">Low</option>
            </select>
          </div>
        </div>

        {/* Sorting Dropdown */}
        <div className="flex items-center gap-2">
          <ArrowUpDown className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-slate-400">SORT BY:</span>
          <select
            value={sortBy}
            onChange={(e) => {
              setSortBy(e.target.value);
              setPage(0);
            }}
            className="bg-noc-950 border border-noc-border text-slate-200 rounded-xs px-2.5 py-1 focus:outline-hidden focus:border-cyan-400 cursor-pointer"
          >
            <option value="highest_risk">Highest Risk / Fault Rate</option>
            <option value="most_alarms">Most Critical Alarms</option>
            <option value="worst_latency">Worst Latency</option>
          </select>
        </div>
      </div>

      {/* Incidents Data Table */}
      <div className="bg-noc-900 border border-noc-border rounded-sm overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-noc-950 border-b border-noc-border text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-3">INCIDENT ID</th>
                <th className="py-2.5 px-3">LOCATION</th>
                <th className="py-2.5 px-3">ISSUE REPORTED</th>
                <th className="py-2.5 px-3">SEVERITY</th>
                <th className="py-2.5 px-3">LATENCY</th>
                <th className="py-2.5 px-3">THROUGHPUT</th>
                <th className="py-2.5 px-3">PACKET LOSS</th>
                <th className="py-2.5 px-3">ALARMS</th>
                <th className="py-2.5 px-3 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-noc-border/40 text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500 font-mono">
                    Loading telemetry records...
                  </td>
                </tr>
              ) : incidents.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500 font-mono">
                    No incidents matched criteria.
                  </td>
                </tr>
              ) : (
                incidents.map((inc) => (
                  <tr key={inc.incident_id} className="hover:bg-noc-850/60 transition-colors">
                    <td className="py-2.5 px-3 font-bold text-cyan-400">{inc.incident_id}</td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {inc.city}, {inc.state}
                    </td>
                    <td className="py-2.5 px-3 text-slate-200 truncate max-w-[200px]">
                      {inc.issue_reported}
                    </td>
                    <td className="py-2.5 px-3">
                      <SeverityBadge severity={inc.severity} size="sm" />
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-100">{inc.latency} ms</td>
                    <td className="py-2.5 px-3 font-bold text-slate-100">{inc.throughput} Mbps</td>
                    <td className="py-2.5 px-3 font-bold text-slate-100">{inc.packet_loss_rate}%</td>
                    <td className="py-2.5 px-3">
                      <span className={inc.critical_alarm_count > 0 ? 'text-red-400 font-bold' : 'text-slate-400'}>
                        {inc.critical_alarm_count} crit / {inc.alarm_count} tot
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => handleInspect(inc)}
                        className="px-2 py-1 bg-noc-850 hover:bg-noc-800 text-cyan-400 border border-noc-border rounded-xs text-[11px] font-mono flex items-center gap-1 ml-auto cursor-pointer"
                      >
                        <Eye className="w-3 h-3" /> Inspect
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="p-3 border-t border-noc-border bg-noc-950 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>
            Showing {incidents.length > 0 ? page * limit + 1 : 0} to {Math.min((page + 1) * limit, total)} of {total} incidents
          </span>
          <div className="flex gap-2">
            <button
              disabled={page === 0}
              onClick={() => setPage(p => p - 1)}
              className="px-2.5 py-1 bg-noc-900 border border-noc-border rounded-xs disabled:opacity-30 hover:bg-noc-850 text-slate-200 flex items-center gap-1 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <button
              disabled={(page + 1) * limit >= total}
              onClick={() => setPage(p => p + 1)}
              className="px-2.5 py-1 bg-noc-900 border border-noc-border rounded-xs disabled:opacity-30 hover:bg-noc-850 text-slate-200 flex items-center gap-1 cursor-pointer"
            >
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* MODAL */}
      <CaseDetailModal caseData={selectedCase} onClose={() => setSelectedCase(null)} />
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { TrendingUp, Cpu, Sliders, Activity } from 'lucide-react';
import { MetricCard } from '../components/MetricCard';
import { fetchPredict, fetchRisk } from '../services/api';

export const PredictionsPage: React.FC = () => {
  // Interactive Simulation Sliders
  const [activeUsers, setActiveUsers] = useState(1800);
  const [lossRate, setLossRate] = useState(2.5);
  const [critAlarms, setCritAlarms] = useState(1);
  const [latencyVal, setLatencyVal] = useState(75);

  const [loading, setLoading] = useState(false);
  const [predictions, setPredictions] = useState<any>(null);
  const [riskData, setRiskData] = useState<any>(null);

  useEffect(() => {
    let isCancelled = false;
    const fetchModelOutputs = async () => {
      setLoading(true);
      try {
        const telemetry = {
          user_count: activeUsers,
          packet_loss_rate: lossRate,
          critical_alarm_count: critAlarms,
          latency: latencyVal
        };
        const [predRes, riskRes] = await Promise.all([
          fetchPredict(telemetry),
          fetchRisk(telemetry)
        ]);
        if (!isCancelled) {
          setPredictions(predRes);
          setRiskData(riskRes);
        }
      } catch (err) {
        console.error("Failed to fetch predictions from ML service:", err);
      } finally {
        if (!isCancelled) setLoading(false);
      }
    };

    const timer = setTimeout(fetchModelOutputs, 250);
    return () => {
      isCancelled = true;
      clearTimeout(timer);
    };
  }, [activeUsers, lossRate, critAlarms, latencyVal]);

  const tpVal = predictions?.predicted_throughput_mbps ?? predictions?.predicted_throughput;
  const latVal = predictions?.predicted_latency_ms ?? predictions?.predicted_latency;
  const hoVal = predictions?.predicted_handover_success_rate;
  const riskScore = riskData?.risk_score ?? riskData?.score;
  const riskLevel = riskData?.risk_level ?? riskData?.level;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      <div className="flex items-center justify-between pb-3 border-b border-noc-border">
        <div>
          <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-sky-400" />
            ML NETWORK PERFORMANCE & FAULT RISK PREDICTIONS
          </h2>
          <p className="text-xs text-slate-400">
            Real Random Forest regression projections and blended operational risk evaluated via backend API.
          </p>
        </div>
        <span className="text-xs px-2.5 py-1 bg-sky-950 border border-sky-800 text-sky-300 font-mono rounded-xs">
          API: /api/v1/predict & /api/v1/risk
        </span>
      </div>

      {/* Notice Banner */}
      <div className="p-3 bg-noc-900 border border-sky-800/50 rounded-sm text-xs font-mono text-sky-300 flex items-center gap-2">
        <Cpu className="w-4 h-4 text-sky-400 shrink-0" />
        <span>
          <strong>Live ML Model Inference:</strong> Predictions are computed by trained scikit-learn Random Forest models trained on held-out 5G operational telemetry.
        </span>
      </div>

      {/* Scenario Simulation Controls */}
      <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-noc-border">
          <span className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            Interactive Telemetry Scenario Simulator
          </span>
          <span className="text-[11px] font-mono text-slate-400">
            {loading ? 'INFERRING ML PREDICTIONS...' : 'ADJUST CELL PARAMETERS'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-xs font-mono">
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>CONNECTED USERS:</span>
              <span className="text-cyan-400 font-bold">{activeUsers} users</span>
            </div>
            <input
              type="range"
              min="200"
              max="4500"
              step="50"
              value={activeUsers}
              onChange={(e) => setActiveUsers(Number(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>TRANSPORT LOSS:</span>
              <span className="text-amber-400 font-bold">{lossRate}%</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="15.0"
              step="0.1"
              value={lossRate}
              onChange={(e) => setLossRate(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>CRITICAL ALARMS:</span>
              <span className="text-red-400 font-bold">{critAlarms} alarms</span>
            </div>
            <input
              type="range"
              min="0"
              max="12"
              step="1"
              value={critAlarms}
              onChange={(e) => setCritAlarms(Number(e.target.value))}
              className="w-full accent-red-400 cursor-pointer"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>CLUSTER RTT LATENCY:</span>
              <span className="text-sky-400 font-bold">{latencyVal} ms</span>
            </div>
            <input
              type="range"
              min="20"
              max="200"
              step="5"
              value={latencyVal}
              onChange={(e) => setLatencyVal(Number(e.target.value))}
              className="w-full accent-sky-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Model Predictions Output Tiles */}
      <div>
        <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block mb-2">
          Projected 3GPP Network KPIs (Live Random Forest API Output)
        </span>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <MetricCard
            label="Predicted Throughput"
            value={tpVal !== undefined ? `${Math.round(tpVal)}` : '...'}
            unit="Mbps"
            threshold="p50 Baseline: 548.7 Mbps"
            status={tpVal !== undefined && tpVal < 390 ? 'critical' : tpVal !== undefined && tpVal < 500 ? 'warning' : 'nominal'}
            subtext="RF Regressor (R²=0.979)"
          />
          <MetricCard
            label="Predicted Latency"
            value={latVal !== undefined ? `${Math.round(latVal)}` : '...'}
            unit="ms"
            threshold="p75 Threshold: 105.5 ms"
            status={latVal !== undefined && latVal > 105 ? 'critical' : latVal !== undefined && latVal > 77 ? 'warning' : 'nominal'}
            subtext="RF Regressor"
          />
          <MetricCard
            label="Predicted Handover SR"
            value={hoVal !== undefined ? `${hoVal.toFixed(1)}%` : '...'}
            threshold="p25 Cutoff: 92.5%"
            status={hoVal !== undefined && hoVal < 92.5 ? 'critical' : hoVal !== undefined && hoVal < 95 ? 'warning' : 'nominal'}
            subtext="RF Regressor"
          />
          <MetricCard
            label="Blended Fault Risk"
            value={riskScore !== undefined ? `${riskScore}/100` : '...'}
            threshold="60% Det + 40% ML"
            status={riskScore !== undefined && riskScore >= 70 ? 'critical' : riskScore !== undefined && riskScore >= 50 ? 'warning' : 'nominal'}
            subtext={riskData ? `${riskLevel ?? 'NOMINAL'} RISK` : 'Predicting...'}
          />
        </div>
      </div>
    </div>
  );
};

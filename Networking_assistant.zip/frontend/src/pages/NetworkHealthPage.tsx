import React, { useEffect, useState } from 'react';
import { HeartPulse, Radio, Wifi, Server, CheckCircle2, AlertTriangle, ShieldCheck, CloudRain } from 'lucide-react';
import { SystemStats, SystemMetrics } from '../types';
import { fetchStatistics, fetchMetrics } from '../services/api';
import { MetricCard } from '../components/MetricCard';
import { HorizontalBarChart } from '../components/SimpleCharts';

export const NetworkHealthPage: React.FC = () => {
  const [stats, setStats] = useState<SystemStats | null>(null);
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);

  useEffect(() => {
    Promise.all([
      fetchStatistics().catch(() => null),
      fetchMetrics().catch(() => null)
    ]).then(([s, m]) => {
      setStats(s);
      setMetrics(m);
    });
  }, []);

  const avgAvail = stats?.metrics?.avg_cell_availability !== undefined
    ? `${stats.metrics.avg_cell_availability.toFixed(1)}%`
    : '...';

  const avgLat = metrics?.avg_latency ?? (stats?.metrics?.avg_latency !== undefined
    ? `${stats.metrics.avg_latency.toFixed(1)} ms`
    : '...');

  const avgHosr = metrics?.avg_handover_success ?? (stats?.metrics?.avg_handover_success_rate !== undefined
    ? `${stats.metrics.avg_handover_success_rate.toFixed(1)}%`
    : '...');

  const avgLoss = metrics?.avg_packet_loss ?? (stats?.metrics?.avg_packet_loss_rate !== undefined
    ? `${stats.metrics.avg_packet_loss_rate.toFixed(2)}%`
    : '...');

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      <div className="flex items-center justify-between pb-3 border-b border-noc-border">
        <div>
          <h2 className="text-xl font-bold font-mono text-white tracking-tight flex items-center gap-2">
            <HeartPulse className="w-5 h-5 text-emerald-400" />
            NETWORK SUBSYSTEM HEALTH & INTEGRITY
          </h2>
          <p className="text-xs text-slate-400">
            Physical air interface, S1-U backhaul transport, and cluster availability telemetry.
          </p>
        </div>
        <span className="text-xs px-2.5 py-1 bg-emerald-950 border border-emerald-700/50 text-emerald-400 font-mono rounded-xs">
          HEALTH INDEX: {metrics?.network_health_score !== undefined ? `${metrics.network_health_score}%` : '...'}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricCard
          label="Cell Availability"
          value={avgAvail}
          status="nominal"
          subtext="Target > 83.4%"
          icon={Radio}
        />
        <MetricCard
          label="Backhaul Latency"
          value={avgLat}
          status={metrics && parseFloat(metrics.avg_latency) > 105 ? 'critical' : 'nominal'}
          subtext="Round-trip transport delay"
          icon={Server}
        />
        <MetricCard
          label="Mobility Handover"
          value={avgHosr}
          status="warning"
          subtext="Target > 92.5%"
          icon={Wifi}
        />
        <MetricCard
          label="Transport Packet Loss"
          value={avgLoss}
          status={metrics && parseFloat(metrics.avg_packet_loss) > 9 ? 'critical' : 'nominal'}
          subtext="Target < 6.3%"
          icon={ShieldCheck}
        />
      </div>

      {/* Grid of Real Subsystem Distributions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
          <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <CloudRain className="w-4 h-4 text-cyan-400" />
            Environmental Weather Distribution
          </h3>
          <p className="text-xs text-slate-400">
            Empirical incident distribution across prevailing weather conditions in dataset.
          </p>
          {stats?.metrics?.weather_distribution ? (
            <HorizontalBarChart
              data={Object.entries(stats.metrics.weather_distribution).map(([w, cnt]) => ({
                label: w,
                value: cnt as number,
                color: w === 'Rain' ? 'bg-cyan-500' : w === 'Snow' ? 'bg-sky-400' : w === 'Clouds' ? 'bg-slate-400' : 'bg-amber-400',
                suffix: 'incidents'
              }))}
            />
          ) : stats?.season_distribution ? (
            <HorizontalBarChart
              data={Object.entries(stats.season_distribution).map(([s, cnt]) => ({
                label: s,
                value: cnt as number,
                color: 'bg-cyan-500',
                suffix: 'incidents'
              }))}
            />
          ) : (
            <div className="text-xs font-mono text-slate-500 py-6 text-center">Loading weather distribution...</div>
          )}
        </div>

        <div className="p-4 bg-noc-900 border border-noc-border rounded-sm space-y-3">
          <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <Server className="w-4 h-4 text-emerald-400" />
            Metropolitan Circle Cell Distribution
          </h3>
          <p className="text-xs text-slate-400">
            Active gNodeB incident records by metropolitan cluster.
          </p>
          {stats ? (
            <HorizontalBarChart
              data={Object.entries(stats.city_distribution).slice(0, 6).map(([city, count]) => ({
                label: city,
                value: count,
                color: 'bg-emerald-500',
                suffix: 'records'
              }))}
            />
          ) : (
            <div className="text-xs font-mono text-slate-500 py-6 text-center">Loading cluster health...</div>
          )}
        </div>
      </div>
    </div>
  );
};

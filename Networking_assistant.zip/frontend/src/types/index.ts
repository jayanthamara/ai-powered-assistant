export type SeverityLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface LocationInfo {
  city: string;
  state: string;
}

export interface MetricSummary {
  throughput?: number;
  latency?: number;
  packet_loss_rate?: number;
  call_drop_rate?: number;
  handover_success_rate?: number;
  alarm_count?: number;
  critical_alarm_count?: number;
  signal_strength?: number;
  fault_occurrence_rate?: number;
  cell_availability?: number;
  user_count?: number;
  data_usage?: number;
  mttr?: number;
}

export interface IncidentInfo {
  type: string;
  severity: SeverityLevel;
  confidence: number;
  triggering_factors: string[];
}

export interface RiskFactor {
  feature: string;
  impact: number;
}

export interface RiskInfo {
  score: number;
  level: SeverityLevel;
  risk_score?: number;
  risk_level?: SeverityLevel;
  factors: string[];
  top_risk_factors?: RiskFactor[];
}

export interface AffectedMetric {
  metric: string;
  value: string;
  threshold: string;
  severity: string;
}

export interface NetworkImpact {
  impact_score: number;
  impact_level: SeverityLevel;
  affected_metrics: AffectedMetric[];
  affected_cells: string[];
  affected_region: string;
  customer_impact: string;
  network_impact: string;
  evidence: string[];
}

export interface RootCause {
  root_cause: string;
  likelihood_score: number;
  likelihood: 'LOW' | 'MEDIUM' | 'HIGH';
  evidence: string[];
  domain: string;
}

export interface SimilarCase {
  incident_id: string;
  similarity_score: number;
  initial_similarity_score?: number;
  semantic_score: number;
  keyword_score: number;
  metric_score: number;
  metadata_score: number;
  rerank_score?: number;
  location: LocationInfo;
  season: string;
  weather: string;
  issue_reported: string;
  severity: SeverityLevel;
  metrics: MetricSummary;
  why_similar: string[];
  match_reasons?: string[];
  historical_outcome: string;
}

export interface Recommendation {
  action: string;
  priority: SeverityLevel;
  reason: string;
  evidence: string[];
  category?: string;
}

export interface KPIPrediction {
  predicted_throughput?: number;
  predicted_throughput_mbps?: number;
  predicted_latency?: number;
  predicted_latency_ms?: number;
  predicted_packet_loss_rate?: number;
  predicted_handover_success_rate?: number;
  predicted_fault_occurrence_rate?: number;
  confidence?: number;
  note?: string;
}

export interface JudgeEvaluation {
  grounding_score: number;
  relevance_score: number;
  recommendation_score: number;
  overall_score: number;
  faithfulness?: number;
  context_relevance?: number;
  answer_relevance?: number;
  completeness?: number;
  recommendation_quality?: number;
  hallucination_risk?: number;
  decision?: 'PASS' | 'WARN' | 'FAIL';
  issues: string[];
}

export interface InvestigationResult {
  success: boolean;
  query: string;
  incident: IncidentInfo;
  risk: RiskInfo;
  network_analysis: {
    summary: string;
    anomalies: string[];
    affected_metrics: string[];
    current_metrics: MetricSummary;
  };
  network_impact: NetworkImpact;
  root_causes: RootCause[];
  similar_cases: SimilarCase[];
  recommendations: Recommendation[];
  prediction: KPIPrediction;
  diagnosis: string;
  evaluation: JudgeEvaluation;
  metadata: {
    total_latency_seconds: number;
    retrieval_latency_seconds: number;
    llm_latency_seconds: number;
    cases_retrieved: number;
    demo_mode: boolean;
    rerank_latency_seconds?: number;
    embedding_latency_seconds?: number;
    llm_provider?: string;
  };
}

export interface IncidentRecord {
  incident_id: string;
  city: string;
  state: string;
  season: string;
  weather: string;
  issue_reported: string;
  severity: SeverityLevel;
  cell_availability: number;
  latency: number;
  throughput: number;
  packet_loss_rate: number;
  call_drop_rate: number;
  handover_success_rate: number;
  alarm_count: number;
  critical_alarm_count: number;
  fault_occurrence_rate: number;
  user_count: number;
  data_usage: number;
  signal_strength: number;
}

export interface SystemMetrics {
  network_health_score: number;
  network_health_status: string;
  active_incidents: number;
  critical_alerts: number;
  high_risk_cells: number;
  avg_latency: string;
  avg_packet_loss: string;
  avg_handover_success: string;
  avg_throughput: string;
}

export interface SystemStats {
  total_records: number;
  metrics: Record<string, any>;
  severity_distribution: Record<string, number>;
  city_distribution: Record<string, number>;
  season_distribution: Record<string, number>;
  top_issues: Record<string, number>;
  feedback_stats: {
    total_feedback_entries: number;
    positive_feedback_count: number;
    positive_rate: number;
    total_queries_logged: number;
  };
}

export interface EvaluationEvidenceSource {
  incident_id: string;
  dataset_record_idx?: number;
  source_dataset: string;
  similarity_score?: number;
  rerank_score?: number;
  location?: LocationInfo;
  season?: string;
  weather?: string;
  metrics?: MetricSummary;
  match_reasons?: string[];
}

export interface QueryEvaluationRetrieval {
  retrieved_count: number;
  precision_at_5?: number | string;
  precision_percentage?: number;
  recall_at_5: number | string;
  recall_at_10: number | string;
  mrr: number | string;
  ground_truth_status: string;
  ground_truth_count?: number;
  retrieval_relevance_score: number;
  evidence_sources: EvaluationEvidenceSource[];
}

export interface QueryEvaluationClassification {
  predicted_category: string;
  expected_category: string;
  is_match: boolean | string;
  accuracy?: number | string;
  accuracy_percentage?: number;
  status: string;
  severity: SeverityLevel;
  confidence: number;
  triggering_factors: string[];
}

export interface QueryEvaluationDiagnosis {
  evidence_support: number;
  consistency: number;
  hallucination_risk: number;
  overall_score: number;
  decision: 'PASS' | 'WARN' | 'FAIL';
  evaluator_type: string;
  issues: string[];
  explanation: string;
}

export interface QueryEvaluationRecommendation {
  recommendation_score: number;
  action_count: number;
  safety_status: string;
  decision: 'PASS' | 'WARN' | 'FAIL';
}

export interface QueryEvaluationData {
  mode: string;
  query: string;
  retrieval: QueryEvaluationRetrieval;
  classification: QueryEvaluationClassification;
  diagnosis: QueryEvaluationDiagnosis;
  recommendation: QueryEvaluationRecommendation;
  llm_judge: JudgeEvaluation;
  overall_score: number;
  decision: 'PASS' | 'WARN' | 'FAIL';
  summary: string;
}

export interface QueryEvaluationResponse {
  success: boolean;
  query: string;
  investigation: InvestigationResult;
  evaluation: QueryEvaluationData;
}

export interface BenchmarkRecord {
  id: string;
  query: string;
  predicted_type: string;
  expected_type?: string;
  classification_matched: boolean | string;
  precision_at_5?: number | string;
  recall_at_5?: number | string;
  retrieved_cases: string[];
  diagnosis_score: number;
  recommendation_score: number;
  decision: 'PASS' | 'WARN' | 'FAIL';
}

export interface BenchmarkSummary {
  benchmark_dataset: string;
  total_queries_evaluated: number;
  classification_accuracy: number;
  classification_precision: number;
  classification_recall: number;
  classification_f1: number;
  average_precision?: number;
  retrieval_metrics: {
    precision_at_5?: number | string;
    recall_at_5: number | string;
    recall_at_10: number | string;
    mrr: number | string;
    queries_evaluated_with_gt: number;
  };
  average_diagnosis_score: number;
  average_recommendation_score: number;
  pass_rate: number;
  records: BenchmarkRecord[];
}


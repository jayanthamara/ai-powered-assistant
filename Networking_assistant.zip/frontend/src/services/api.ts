import {
  InvestigationResult,
  SystemMetrics,
  SystemStats,
  IncidentRecord,
  SimilarCase,
  QueryEvaluationResponse,
  BenchmarkSummary
} from '../types';

const API_BASE = typeof window !== 'undefined' && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
  ? 'http://127.0.0.1:8000'
  : '';

export async function fetchHealth(): Promise<any> {
  const res = await fetch(`${API_BASE}/health`);
  if (!res.ok) throw new Error(`Health probe error: ${res.statusText}`);
  return res.json();
}

export async function runInvestigation(
  query: string,
  filters?: Record<string, any>,
  telemetry?: Record<string, any>,
  top_k: number = 5
): Promise<InvestigationResult> {
  const res = await fetch(`${API_BASE}/api/v1/query`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, filters, telemetry, top_k })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'API Error' }));
    throw new Error(err.detail || 'Failed to process investigation');
  }
  const data = await res.json();
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('netpulse_investigation_updated', { detail: data }));
  }
  return data;
}

export async function searchHistoricalCases(
  query: string,
  filters?: Record<string, any>,
  top_k: number = 10
): Promise<{ query: string; count: number; results: SimilarCase[] }> {
  const res = await fetch(`${API_BASE}/api/v1/search`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, filters, top_k })
  });
  if (!res.ok) throw new Error('Search failed');
  return res.json();
}

export async function fetchMetrics(): Promise<SystemMetrics> {
  const res = await fetch(`${API_BASE}/api/v1/metrics`);
  if (!res.ok) throw new Error('Failed to fetch metrics');
  return res.json();
}

export async function fetchStatistics(): Promise<SystemStats> {
  const res = await fetch(`${API_BASE}/api/v1/statistics`);
  if (!res.ok) throw new Error('Failed to fetch statistics');
  return res.json();
}

export async function fetchIncidents(params?: Record<string, any>): Promise<{ total: number; incidents: IncidentRecord[] }> {
  const queryStr = params ? '?' + new URLSearchParams(params).toString() : '';
  const res = await fetch(`${API_BASE}/api/v1/incidents${queryStr}`);
  if (!res.ok) throw new Error('Failed to fetch incidents');
  return res.json();
}

export async function fetchCaseDetail(caseId: string): Promise<IncidentRecord> {
  const res = await fetch(`${API_BASE}/api/v1/cases/${encodeURIComponent(caseId)}`);
  if (!res.ok) throw new Error('Failed to fetch case detail');
  return res.json();
}

export async function submitOperatorFeedback(data: {
  query: string;
  diagnosis_feedback: string;
  recommendation_feedback?: string;
  user_comment?: string;
  grounding_rating?: number;
  case_id?: string;
}): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/feedback`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Failed to submit feedback');
  return res.json();
}

export async function fetchConfig(): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/config`);
  if (!res.ok) throw new Error('Failed to fetch config');
  return res.json();
}

export async function triggerReindex(): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/reindex`, { method: 'POST' });
  if (!res.ok) throw new Error('Failed to trigger reindex');
  return res.json();
}

export async function uploadDatasetFile(file: File, merge: boolean = true): Promise<any> {
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch(`${API_BASE}/api/v1/upload?merge=${merge}`, {
    method: 'POST',
    body: formData
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Upload failed' }));
    throw new Error(err.detail || 'Failed to upload dataset');
  }
  return res.json();
}

export interface CopilotChatResponse {
  request_id: string;
  response_mode: string;
  message: string;
  routing: {
    intent: string;
    scope: string;
    confidence: number;
    requires_network_analysis: boolean;
    requires_retrieval: boolean;
    requires_current_investigation_context: boolean;
    clarification_prompt?: string;
  };
  investigation_context?: Record<string, any>;
  incident?: any;
  risk?: any;
  root_causes?: any[];
  network_impact?: any;
  predictions?: any;
  recommendations?: any[];
  similar_cases?: any[];
}

export async function sendCopilotMessage(
  query: string,
  investigation_context?: Record<string, any>,
  session_id?: string
): Promise<CopilotChatResponse> {
  const res = await fetch(`${API_BASE}/api/v1/copilot`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      query,
      investigation_context,
      session_id
    })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Copilot request failed' }));
    throw new Error(err.detail || 'Failed to process copilot query');
  }
  return res.json();
}

export async function runQueryEvaluation(
  query: string,
  options?: {
    expected_incident_type?: string;
    expected_incident_ids?: string[];
    top_k?: number;
    filters?: Record<string, any>;
  }
): Promise<QueryEvaluationResponse> {
  const res = await fetch(`${API_BASE}/api/v1/evaluation/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      query,
      expected_incident_type: options?.expected_incident_type,
      expected_incident_ids: options?.expected_incident_ids,
      top_k: options?.top_k || 5,
      filters: options?.filters
    })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Evaluation request failed' }));
    throw new Error(err.detail || 'Failed to execute query evaluation');
  }
  return res.json();
}

export async function runBenchmarkEvaluation(limit?: number): Promise<BenchmarkSummary> {
  const url = limit ? `${API_BASE}/api/v1/evaluation/benchmark?limit=${limit}` : `${API_BASE}/api/v1/evaluation/benchmark`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Benchmark execution failed' }));
    throw new Error(err.detail || 'Failed to execute benchmark evaluation');
  }
  return res.json();
}

export async function fetchBenchmarkDataset(): Promise<any[]> {
  const res = await fetch(`${API_BASE}/api/v1/evaluation/benchmark`);
  if (!res.ok) throw new Error('Failed to fetch benchmark dataset');
  return res.json();
}

export async function fetchPredict(telemetry: Record<string, any>): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/predict`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ telemetry })
  });
  if (!res.ok) throw new Error('Prediction API call failed');
  return res.json();
}

export async function fetchRisk(telemetry: Record<string, any>): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/risk`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ telemetry })
  });
  if (!res.ok) throw new Error('Risk API call failed');
  return res.json();
}

export async function fetchMLMetrics(): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/ml/metrics`);
  if (!res.ok) throw new Error('Failed to fetch ML metrics');
  return res.json();
}

export async function fetchFilters(): Promise<{
  cities: string[];
  states: string[];
  seasons: string[];
  weather: string[];
  severities: string[];
}> {
  const res = await fetch(`${API_BASE}/api/v1/filters`);
  if (!res.ok) throw new Error('Failed to fetch filters');
  return res.json();
}

export async function fetchFeedback(limit: number = 50): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/feedback?limit=${limit}`);
  if (!res.ok) throw new Error('Failed to fetch feedback entries');
  return res.json();
}

export async function fetchRagasEvaluation(): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/evaluation/ragas`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Failed to fetch RAGAS evaluation results' }));
    throw new Error(err.detail || 'RAGAS evaluation results not available');
  }
  return res.json();
}

export async function fetchDeepEvalEvaluation(): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/evaluation/deepeval`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Failed to fetch DeepEval evaluation results' }));
    throw new Error(err.detail || 'DeepEval evaluation results not available');
  }
  return res.json();
}

export async function triggerRagasEvaluation(limit: number = 5): Promise<any> {
  const res = await fetch(`${API_BASE}/api/v1/evaluation/ragas/run?limit=${limit}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Failed to run RAGAS evaluation' }));
    throw new Error(err.detail || 'RAGAS execution failed');
  }
  return res.json();
}

import React, { useState, useEffect } from 'react';
import { AppLayout } from './layouts/AppLayout';
import { OverviewPage } from './pages/OverviewPage';
import { InvestigatePage } from './pages/InvestigatePage';
import { IncidentsPage } from './pages/IncidentsPage';
import { NetworkHealthPage } from './pages/NetworkHealthPage';
import { RiskAnalysisPage } from './pages/RiskAnalysisPage';
import { HistoricalCasesPage } from './pages/HistoricalCasesPage';
import { PredictionsPage } from './pages/PredictionsPage';
import { EvaluationPage } from './pages/EvaluationPage';
import { FeedbackPage } from './pages/FeedbackPage';
import { SystemPage } from './pages/SystemPage';
import { fetchHealth } from './services/api';

export function App() {
  const [currentTab, setCurrentTab] = useState<string>('investigate');
  const [apiHealthy, setApiHealthy] = useState<boolean>(true);

  useEffect(() => {
    fetchHealth()
      .then(() => setApiHealthy(true))
      .catch(() => setApiHealthy(false));

    const interval = setInterval(() => {
      fetchHealth()
        .then(() => setApiHealthy(true))
        .catch(() => setApiHealthy(false));
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const renderContent = () => {
    switch (currentTab) {
      case 'overview':
        return <OverviewPage onNavigate={(tab) => setCurrentTab(tab)} />;
      case 'investigate':
        return <InvestigatePage />;
      case 'incidents':
        return <IncidentsPage />;
      case 'network_health':
        return <NetworkHealthPage />;
      case 'risk_analysis':
        return <RiskAnalysisPage />;
      case 'historical_cases':
        return <HistoricalCasesPage />;
      case 'predictions':
        return <PredictionsPage />;
      case 'evaluation':
        return <EvaluationPage />;
      case 'feedback':
        return <FeedbackPage />;
      case 'system':
        return <SystemPage />;
      default:
        return <InvestigatePage />;
    }
  };

  return (
    <AppLayout
      currentTab={currentTab}
      onSelectTab={(tab) => setCurrentTab(tab)}
      apiHealthy={apiHealthy}
    >
      {renderContent()}
    </AppLayout>
  );
}

export default App;

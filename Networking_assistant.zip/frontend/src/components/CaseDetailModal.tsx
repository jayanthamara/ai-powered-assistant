import React from 'react';
import { X, MapPin, Calendar, Activity, CheckCircle, Radio, AlertTriangle } from 'lucide-react';
import { SimilarCase } from '../types';
import { SeverityBadge } from './SeverityBadge';

interface Props {
  caseData: SimilarCase | null;
  onClose: () => void;
}

export const CaseDetailModal: React.FC<Props> = ({ caseData, onClose }) => {
  if (!caseData) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-noc-900 border border-noc-border rounded-sm shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-noc-border bg-noc-850">
          <div className="flex items-center gap-3">
            <span className="text-xl font-bold font-mono text-cyan-400 tracking-tight">
              {caseData.incident_id}
            </span>
            <SeverityBadge severity={caseData.severity} />
            <span className="text-xs px-2.5 py-0.5 rounded-sm font-mono font-semibold bg-cyan-950 text-cyan-300 border border-cyan-700/50">
              SIMILARITY: {Math.round(caseData.similarity_score * 100)}%
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-sm hover:bg-noc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-sm">
          {/* Metadata Bar */}
          <div className="grid grid-cols-3 gap-3 p-3 bg-noc-950/60 border border-noc-border/80 rounded-sm text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>{caseData.location.city}, {caseData.location.state}</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <Calendar className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>{caseData.season} ({caseData.weather})</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <Activity className="w-4 h-4 text-cyan-400 shrink-0" />
              <span className="truncate">{caseData.issue_reported}</span>
            </div>
          </div>

          {/* Similarity Rationale Breakdown */}
          <div>
            <h4 className="text-xs font-mono font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              Why this case was matched
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {caseData.why_similar && caseData.why_similar.map((reason, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 text-xs bg-noc-850 border border-cyan-900/60 text-cyan-300 rounded-sm font-mono"
                >
                  ✓ {reason}
                </span>
              ))}
            </div>
          </div>

          {/* Retrieval Fusion Weights Breakdown */}
          <div className="p-3 bg-noc-950/80 border border-noc-border/60 rounded-sm">
            <h4 className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-2">
              Advanced Hybrid Retrieval & Reranker Breakdown
            </h4>
            <div className={`grid ${caseData.rerank_score !== undefined ? 'grid-cols-5' : 'grid-cols-4'} gap-2 text-center font-mono text-xs`}>
              <div className="p-2 bg-noc-900 rounded-xs border border-noc-border/40">
                <span className="block text-slate-500 text-[10px]">SEMANTIC</span>
                <span className="text-cyan-400 font-bold">{Math.round((caseData.semantic_score || 0) * 100)}%</span>
              </div>
              <div className="p-2 bg-noc-900 rounded-xs border border-noc-border/40">
                <span className="block text-slate-500 text-[10px]">BM25 KEYWORD</span>
                <span className="text-sky-400 font-bold">{Math.round((caseData.keyword_score || 0) * 100)}%</span>
              </div>
              <div className="p-2 bg-noc-900 rounded-xs border border-noc-border/40">
                <span className="block text-slate-500 text-[10px]">METRIC MATCH</span>
                <span className="text-emerald-400 font-bold">{Math.round((caseData.metric_score || 0) * 100)}%</span>
              </div>
              <div className="p-2 bg-noc-900 rounded-xs border border-noc-border/40">
                <span className="block text-slate-500 text-[10px]">METADATA</span>
                <span className="text-amber-400 font-bold">{Math.round((caseData.metadata_score || 0) * 100)}%</span>
              </div>
              {caseData.rerank_score !== undefined && (
                <div className="p-2 bg-noc-900 rounded-xs border border-purple-500/40">
                  <span className="block text-purple-400 text-[10px]">RERANK</span>
                  <span className="text-purple-300 font-bold">{Math.round(caseData.rerank_score * 100)}%</span>
                </div>
              )}
            </div>
          </div>

          {/* Historical Telemetry Snapshot */}
          <div>
            <h4 className="text-xs font-mono font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              Recorded Network Telemetry During Incident
            </h4>
            <div className="grid grid-cols-3 gap-2 text-xs font-mono">
              <div className="p-2 bg-noc-900 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px]">THROUGHPUT</span>
                <span className="text-white font-bold">{caseData.metrics.throughput} Mbps</span>
              </div>
              <div className="p-2 bg-noc-900 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px]">LATENCY</span>
                <span className="text-white font-bold">{caseData.metrics.latency} ms</span>
              </div>
              <div className="p-2 bg-noc-900 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px]">PACKET LOSS</span>
                <span className="text-white font-bold">{caseData.metrics.packet_loss_rate}%</span>
              </div>
              <div className="p-2 bg-noc-900 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px]">HANDOVER SUCCESS</span>
                <span className="text-white font-bold">{caseData.metrics.handover_success_rate}%</span>
              </div>
              <div className="p-2 bg-noc-900 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px]">CALL DROP RATE</span>
                <span className="text-white font-bold">{caseData.metrics.call_drop_rate}%</span>
              </div>
              <div className="p-2 bg-noc-900 border border-noc-border/60 rounded-xs">
                <span className="text-slate-400 block text-[10px]">ALARMS (CRIT / TOT)</span>
                <span className="text-amber-400 font-bold">
                  {caseData.metrics.critical_alarm_count} / {caseData.metrics.alarm_count}
                </span>
              </div>
            </div>
          </div>

          {/* Recorded Incident Resolution & MTTR */}
          <div className="p-3.5 bg-emerald-950/20 border border-emerald-800/40 rounded-sm">
            <h4 className="text-xs font-mono font-semibold text-emerald-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
              Recorded Incident Resolution & Operational MTTR
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed font-mono">
              {caseData.historical_outcome || `Recorded MTTR: ${caseData.metrics?.mttr !== undefined ? `${caseData.metrics.mttr} hours` : 'Recorded in incident history'}. Critical alarms: ${caseData.metrics?.critical_alarm_count ?? 0}. Issue logged: ${caseData.issue_reported || 'yes'}.`}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-noc-border bg-noc-850 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-noc-800 hover:bg-noc-750 text-slate-200 border border-noc-border rounded-sm text-xs font-mono uppercase tracking-wider transition-colors"
          >
            Close Incident Drawer
          </button>
        </div>
      </div>
    </div>
  );
};

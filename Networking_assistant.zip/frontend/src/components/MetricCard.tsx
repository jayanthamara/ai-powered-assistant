import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  label: string;
  value: string | number;
  unit?: string;
  icon?: LucideIcon;
  subtext?: string;
  status?: 'nominal' | 'warning' | 'critical' | 'neutral';
  threshold?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  unit,
  icon: Icon,
  subtext,
  status = 'neutral',
  threshold
}) => {
  let statusBorder = 'border-noc-border';
  let statusGlow = '';
  let valueColor = 'text-white';

  if (status === 'critical') {
    statusBorder = 'border-red-600/60 bg-red-950/20';
    statusGlow = 'border-l-4 border-l-red-500';
    valueColor = 'text-red-400';
  } else if (status === 'warning') {
    statusBorder = 'border-amber-600/60 bg-amber-950/20';
    statusGlow = 'border-l-4 border-l-amber-500';
    valueColor = 'text-amber-400';
  } else if (status === 'nominal') {
    statusBorder = 'border-emerald-700/50 bg-emerald-950/10';
    statusGlow = 'border-l-4 border-l-emerald-500';
    valueColor = 'text-emerald-400';
  }

  return (
    <div className={`p-3.5 bg-noc-900 border ${statusBorder} ${statusGlow} rounded-sm transition-all hover:bg-noc-850 flex flex-col justify-between`}>
      <div className="flex items-center justify-between text-slate-400 mb-1.5">
        <span className="text-xs font-medium tracking-wider uppercase">{label}</span>
        {Icon && <Icon className="w-4 h-4 text-cyan-400" />}
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className={`text-2xl font-bold font-mono tracking-tight ${valueColor}`}>
          {value}
        </span>
        {unit && <span className="text-xs text-slate-400 font-mono">{unit}</span>}
      </div>
      {(subtext || threshold) && (
        <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-noc-border/60 text-[11px] text-slate-400">
          <span>{subtext}</span>
          {threshold && <span className="font-mono text-slate-400 font-medium">SLA: {threshold}</span>}
        </div>
      )}
    </div>
  );
};

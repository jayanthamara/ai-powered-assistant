import React from 'react';
import { SeverityLevel } from '../types';

interface Props {
  severity: SeverityLevel | string;
  size?: 'sm' | 'md' | 'lg';
}

export const SeverityBadge: React.FC<Props> = ({ severity, size = 'md' }) => {
  const sev = (severity || 'MEDIUM').toUpperCase();

  let colors = 'bg-slate-800 text-slate-300 border-slate-700';
  let dotColor = 'bg-slate-400';

  if (sev === 'CRITICAL') {
    colors = 'bg-red-950/80 text-red-400 border-red-700/60 shadow-[0_0_12px_rgba(239,68,68,0.2)]';
    dotColor = 'bg-red-500 animate-pulse';
  } else if (sev === 'HIGH') {
    colors = 'bg-amber-950/80 text-amber-400 border-amber-700/60 shadow-[0_0_10px_rgba(245,158,11,0.15)]';
    dotColor = 'bg-amber-400';
  } else if (sev === 'MEDIUM') {
    colors = 'bg-sky-950/80 text-sky-400 border-sky-700/60';
    dotColor = 'bg-sky-400';
  } else if (sev === 'LOW') {
    colors = 'bg-emerald-950/80 text-emerald-400 border-emerald-700/60';
    dotColor = 'bg-emerald-400';
  }

  const sizeCls = size === 'sm' ? 'px-2 py-0.5 text-xs' : size === 'lg' ? 'px-3.5 py-1 text-sm' : 'px-2.5 py-0.5 text-xs';

  return (
    <span className={`inline-flex items-center gap-1.5 font-mono font-medium rounded-sm border ${sizeCls} ${colors}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dotColor}`} />
      {sev}
    </span>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, Sparkles, Send, ChevronDown, RotateCcw, 
  Radio, ShieldAlert, Cpu, CheckCircle2, AlertTriangle, ArrowRight,
  Database, Layers
} from 'lucide-react';
import { sendCopilotMessage, CopilotChatResponse } from '../services/api';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  responseMode?: string;
  intent?: string;
  incidentType?: string;
  riskScore?: number;
  recommendations?: string[];
  cases?: Array<{ id: string; score: number; issue?: string }>;
}

// Section 26: Suggested prompts must be telecom-focused
const QUICK_PROMPTS = [
  "Investigate high latency",
  "Find similar incidents",
  "Explain the current root cause",
  "Why is the risk high?",
  "Explain packet loss",
  "Show recommended actions"
];

export const CopilotWidget: React.FC<{ onNavigateToInvestigate?: (query?: string) => void }> = ({ 
  onNavigateToInvestigate 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeContext, setActiveContext] = useState<Record<string, any> | null>(null);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'bot',
      text: 'Greetings, Operator. I am NETPULSE AI, your specialized Telecom Network Operations Copilot. Ask me about telecom concepts, network incidents, active investigation risk, or historical precedents.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      responseMode: 'CONVERSATIONAL'
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync active investigation context from global events (e.g. when operator runs an investigation on Investigate page)
  useEffect(() => {
    const handleInvestigationUpdate = (event: any) => {
      if (event.detail) {
        const data = event.detail;
        const ctx = {
          investigation_id: `INV-${Date.now().toString(16).toUpperCase()}`,
          user_query: data.query,
          incident_type: data.incident?.type,
          severity: data.incident?.severity,
          location: data.network_impact?.affected_region || 'Metropolitan RAN cluster',
          metrics: data.network_analysis?.current_metrics || {},
          risk_score: data.risk?.score,
          risk_level: data.risk?.level,
          risk_factors: data.risk?.factors || [],
          root_causes: data.root_causes || [],
          network_impact: data.network_impact || {},
          similar_cases: data.similar_cases || [],
          predictions: data.prediction || {},
          recommendations: data.recommendations || []
        };
        setActiveContext(ctx);
      }
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('netpulse_investigation_updated', handleInvestigationUpdate);
      return () => {
        window.removeEventListener('netpulse_investigation_updated', handleInvestigationUpdate);
      };
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
        scrollToBottom();
      }, 100);
    }
  }, [isOpen]);

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSend = async (queryText?: string) => {
    const textToSend = (queryText || input).trim();
    if (!textToSend || loading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res: CopilotChatResponse = await sendCopilotMessage(textToSend, activeContext || undefined);
      
      // Update active investigation context if returned
      if (res.investigation_context) {
        setActiveContext(res.investigation_context);
      }

      // Evidence Relevance Gate: only show cards/badges if provided in response
      const botMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: res.message || 'Operation complete.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        responseMode: res.response_mode,
        intent: res.routing?.intent,
        incidentType: res.incident?.type,
        riskScore: res.risk?.score,
        recommendations: res.recommendations?.slice(0, 3).map((r: any) => 
          typeof r === 'string' ? r : `${r.action} [${r.priority || 'NORMAL'}]`
        ),
        cases: res.similar_cases?.slice(0, 2).map((c: any) => ({
          id: c.incident_id,
          score: Math.round((c.similarity_score || 0.8) * 100),
          issue: c.issue_reported
        }))
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (err: any) {
      // Professional out-of-scope / connection style (Section 23)
      const errorMsg: Message = {
        id: `bot-err-${Date.now()}`,
        sender: 'bot',
        text: "That topic is outside my telecom network operations scope. I can help with telecom concepts, network incidents, RAN metrics, historical cases, network risk, root-cause analysis, network impact, performance prediction, and troubleshooting recommendations.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        responseMode: 'OUT_OF_SCOPE'
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setActiveContext(null);
    setMessages([
      {
        id: 'welcome-reset',
        sender: 'bot',
        text: 'Copilot session cleared. Ready for new telecom inquiries or incident investigations.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        responseMode: 'CONVERSATIONAL'
      }
    ]);
  };

  const getModeBadgeLabel = (mode?: string) => {
    switch (mode) {
      case 'TELECOM_CONCEPT': return 'TELECOM CONCEPT';
      case 'INVESTIGATION': return 'DIAGNOSTIC TRIAGE';
      case 'RETRIEVAL': return 'HISTORICAL PRECEDENT';
      case 'RISK': return 'RISK ANALYSIS';
      case 'ROOT_CAUSE': return 'ROOT CAUSE';
      case 'RECOMMENDATION': return 'ACTION PLAN';
      case 'PREDICTION': return 'KPI FORECAST';
      case 'FOLLOW_UP': return 'INVESTIGATION CONTEXT';
      case 'OUT_OF_SCOPE': return 'OUT OF SCOPE';
      case 'CLARIFICATION': return 'CLARIFICATION';
      case 'CAPABILITIES': return 'CAPABILITIES';
      default: return 'COPILOT';
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 font-mono select-none">
      {/* FLOATING TRIGGER BUTTON (When Collapsed) */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="group relative flex items-center gap-2.5 px-4 py-3 bg-noc-900/95 hover:bg-noc-850 border border-cyan-500/60 hover:border-cyan-400 text-white rounded-full shadow-[0_0_20px_rgba(0,240,255,0.3)] hover:shadow-[0_0_30px_rgba(0,240,255,0.5)] transition-all transform hover:scale-105 cursor-pointer backdrop-blur-md"
          title="Open NETPULSE Network Operations Copilot"
        >
          <div className="relative">
            <Bot className="w-5 h-5 text-cyan-400 animate-pulse" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-noc-950 animate-ping" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-noc-950" />
          </div>
          <div className="flex flex-col text-left">
            <span className="text-xs font-bold tracking-wider text-cyan-300">COPILOT AI</span>
            <span className="text-[9px] text-slate-400 tracking-widest font-sans uppercase">Telecom NOC Assistant</span>
          </div>
          <Sparkles className="w-3.5 h-3.5 text-amber-400 ml-1 opacity-75 group-hover:opacity-100 transition" />
        </button>
      )}

      {/* CHAT DRAWER PANEL (When Expanded) */}
      {isOpen && (
        <div className="w-[380px] sm:w-[440px] h-[560px] bg-noc-950/95 border border-cyan-500/50 rounded-lg shadow-[0_0_35px_rgba(0,240,255,0.25)] flex flex-col overflow-hidden backdrop-blur-xl animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* HEADER */}
          <div className="px-4 py-3 bg-noc-900 border-b border-noc-border flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-full bg-cyan-950 border border-cyan-400/80 flex items-center justify-center text-cyan-300 shadow-[0_0_10px_rgba(0,240,255,0.3)]">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white tracking-wide flex items-center gap-1.5">
                  NETPULSE COPILOT
                  <span className="px-1.5 py-0.2 text-[8px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-xs uppercase">ONLINE</span>
                </div>
                <div className="text-[9px] text-slate-400 font-sans tracking-wide">
                  Telecom Network Operations Center Assistant
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleClear}
                title="Reset conversation and clear active context"
                className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-noc-800 rounded transition cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                title="Minimize Copilot"
                className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-noc-800 rounded transition cursor-pointer"
              >
                <ChevronDown className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ACTIVE INVESTIGATION CONTEXT BADGE (If present) */}
          {activeContext && (
            <div className="px-3.5 py-1.5 bg-cyan-950/40 border-b border-cyan-500/30 flex items-center justify-between text-[10px] text-cyan-300 shrink-0">
              <div className="flex items-center gap-1.5 truncate">
                <Layers className="w-3 h-3 text-cyan-400 shrink-0" />
                <span className="font-semibold text-slate-300">Context:</span>
                <span className="text-cyan-200 truncate">{activeContext.incident_type || 'Active Incident'}</span>
                {activeContext.risk_score !== undefined && (
                  <span className="px-1 py-0.2 bg-rose-950/80 text-rose-300 border border-rose-500/40 rounded text-[8px]">
                    RISK {Math.round(activeContext.risk_score)}%
                  </span>
                )}
              </div>
              <button
                onClick={() => setActiveContext(null)}
                className="text-[9px] text-slate-400 hover:text-cyan-300 ml-2 underline cursor-pointer"
                title="Clear current context"
              >
                Clear
              </button>
            </div>
          )}

          {/* QUICK PROMPT CHIPS (Section 26: Telecom-focused) */}
          <div className="px-3 py-2 bg-noc-900/60 border-b border-noc-border/60 overflow-x-auto flex gap-1.5 no-scrollbar shrink-0">
            {QUICK_PROMPTS.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(p)}
                disabled={loading}
                className="px-2 py-1 bg-noc-850 hover:bg-cyan-950/60 border border-noc-border hover:border-cyan-500/50 text-[10px] text-slate-300 hover:text-cyan-300 rounded-xs whitespace-nowrap transition cursor-pointer disabled:opacity-50"
              >
                {p}
              </button>
            ))}
          </div>

          {/* CHAT MESSAGES BODY */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-3.5 text-xs">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[92%] p-3 rounded-md text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-cyan-600/30 border border-cyan-400/50 text-cyan-100 rounded-br-none'
                      : 'bg-noc-900/90 border border-noc-border text-slate-200 rounded-bl-none shadow-sm'
                  }`}
                >
                  {/* Sender title and Mode Badge */}
                  <div className="flex items-center justify-between gap-3 pb-1 mb-1.5 border-b border-white/10 text-[9px] text-slate-400 uppercase">
                    <span className="font-bold flex items-center gap-1">
                      {msg.sender === 'user' ? 'Operator' : 'NetPulse Copilot'}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {msg.responseMode && msg.sender === 'bot' && (
                        <span className={`px-1.5 py-0.2 rounded-xs text-[8px] font-mono border ${
                          msg.responseMode === 'OUT_OF_SCOPE' 
                            ? 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                            : msg.responseMode === 'TELECOM_CONCEPT'
                            ? 'bg-sky-950/60 text-sky-300 border-sky-500/40'
                            : msg.responseMode === 'INVESTIGATION'
                            ? 'bg-rose-950/60 text-rose-300 border-rose-500/40'
                            : 'bg-cyan-950/60 text-cyan-300 border-cyan-500/40'
                        }`}>
                          {getModeBadgeLabel(msg.responseMode)}
                        </span>
                      )}
                      <span>{msg.timestamp}</span>
                    </div>
                  </div>

                  <p className="whitespace-pre-wrap font-sans text-xs leading-relaxed">{msg.text}</p>

                  {/* Incident Tags & Risk Badge - ONLY if relevant to investigation / risk */}
                  {msg.incidentType && (
                    <div className="mt-2.5 pt-2 border-t border-noc-border/80 flex flex-wrap gap-1.5 items-center">
                      <span className="px-1.5 py-0.5 bg-cyan-950 text-cyan-300 border border-cyan-500/30 rounded text-[9px] font-bold">
                        {msg.incidentType}
                      </span>
                      {msg.riskScore !== undefined && (
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                          (msg.riskScore > 70 || (msg.riskScore <= 1 && msg.riskScore > 0.7)) ? 'bg-rose-950 text-rose-300 border border-rose-500/40' :
                          (msg.riskScore > 40 || (msg.riskScore <= 1 && msg.riskScore > 0.4)) ? 'bg-amber-950 text-amber-300 border border-amber-500/40' :
                          'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                        }`}>
                          RISK: {Math.round(msg.riskScore > 1 ? msg.riskScore : msg.riskScore * 100)}%
                        </span>
                      )}
                    </div>
                  )}

                  {/* Recommendations - ONLY if relevant */}
                  {msg.recommendations && msg.recommendations.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-noc-border/60 space-y-1">
                      <span className="text-[9px] text-cyan-400 font-bold uppercase tracking-wider block">Recommended Actions:</span>
                      {msg.recommendations.map((rec, i) => (
                        <div key={i} className="text-[10px] text-slate-300 flex items-start gap-1 font-sans">
                          <span className="text-cyan-400">›</span>
                          <span>{rec}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Retrieved Similar Cases - ONLY if relevant */}
                  {msg.cases && msg.cases.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-white/5 flex flex-wrap items-center gap-1.5 text-[9px] text-slate-400">
                      <span>Matched Cases:</span>
                      {msg.cases.map(c => (
                        <span key={c.id} className="text-sky-300 bg-sky-950/60 px-1.5 py-0.5 rounded border border-sky-500/30 font-mono">
                          {c.id} ({c.score}%)
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex items-start">
                <div className="bg-noc-900 border border-cyan-500/40 p-3 rounded-md text-xs text-cyan-300 space-y-1.5 animate-pulse">
                  <div className="flex items-center gap-2 font-bold text-[10px] uppercase">
                    <Cpu className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                    Copilot Intent Router & Analytics Pipeline...
                  </div>
                  <div className="text-[10px] text-slate-400 font-sans">
                    Evaluating telecom scope, routing intent, correlating network telemetry...
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* INPUT BAR (Section 26: Telecom-specialized placeholder) */}
          <div className="p-3 bg-noc-900 border-t border-noc-border shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about telecom networks, incidents, or this investigation..."
                disabled={loading}
                className="flex-1 bg-noc-950 border border-noc-border focus:border-cyan-400 rounded-sm px-3 py-2 text-xs text-white placeholder-slate-500 outline-none transition font-sans"
              />
              <button
                type="submit"
                disabled={!input.trim() || loading}
                className="p-2 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-black font-bold rounded-sm transition cursor-pointer"
                title="Send query to Copilot"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';

// 1. Radial Risk Gauge
export const RiskGauge: React.FC<{ score: number; level: string; label?: string }> = ({
  score,
  level,
  label = "OPERATIONAL RISK SCORE"
}) => {
  const clampedScore = Math.min(100, Math.max(0, score));
  const radius = 64;
  const strokeWidth = 10;
  const normalizedRadius = radius - strokeWidth / 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  // Arc covering 240 degrees
  const arcLength = circumference * (240 / 360);
  const strokeDashoffset = arcLength - (clampedScore / 100) * arcLength;

  let strokeColor = '#10B981'; // Green
  let textColor = 'text-emerald-400';
  let badgeColor = 'bg-emerald-950 text-emerald-400 border-emerald-600';

  if (clampedScore >= 75) {
    strokeColor = '#EF4444';
    textColor = 'text-red-400';
    badgeColor = 'bg-red-950 text-red-400 border-red-600 animate-pulse';
  } else if (clampedScore >= 50) {
    strokeColor = '#F59E0B';
    textColor = 'text-amber-400';
    badgeColor = 'bg-amber-950 text-amber-400 border-amber-600';
  } else if (clampedScore >= 25) {
    strokeColor = '#38BDF8';
    textColor = 'text-sky-400';
    badgeColor = 'bg-sky-950 text-sky-400 border-sky-600';
  }

  return (
    <div className="flex flex-col items-center justify-center p-4 bg-noc-900 border border-noc-border rounded-sm">
      <span className="text-xs uppercase font-mono tracking-wider text-slate-400 mb-2">{label}</span>
      <div className="relative flex items-center justify-center w-36 h-36">
        <svg height={radius * 2} width={radius * 2} className="transform -rotate-90">
          {/* Background circle track */}
          <circle
            stroke="#1E2F52"
            fill="transparent"
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
          {/* Active progress stroke */}
          <circle
            stroke={strokeColor}
            fill="transparent"
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            style={{ strokeDashoffset, transition: 'stroke-dashoffset 0.8s ease' }}
            strokeLinecap="round"
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
        </svg>
        <div className="absolute flex flex-col items-center justify-center text-center">
          <span className={`text-4xl font-extrabold font-mono tracking-tighter ${textColor}`}>
            {clampedScore}
          </span>
          <span className="text-[10px] text-slate-400 font-mono">/ 100</span>
        </div>
      </div>
      <div className={`mt-1 px-3 py-0.5 rounded-sm border text-xs font-mono font-bold tracking-wider uppercase ${badgeColor}`}>
        {level} RISK
      </div>
    </div>
  );
};

// 2. Horizontal Ranked Bar Chart
export const HorizontalBarChart: React.FC<{
  data: { label: string; value: number; total?: number; color?: string; suffix?: string }[];
  maxValue?: number;
}> = ({ data, maxValue }) => {
  const max = maxValue || Math.max(...data.map(d => d.value), 1);

  return (
    <div className="space-y-3 w-full">
      {data.map((item, idx) => {
        const pct = Math.min(100, (item.value / max) * 100);
        const barColor = item.color || (idx === 0 ? 'bg-cyan-500' : idx === 1 ? 'bg-sky-500' : 'bg-slate-500');

        return (
          <div key={idx} className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium truncate max-w-[240px]">{item.label}</span>
              <span className="font-mono text-cyan-400 font-semibold">
                {item.value} {item.suffix || ''}
              </span>
            </div>
            <div className="h-2 w-full bg-noc-850 rounded-xs overflow-hidden border border-noc-border/50">
              <div
                className={`h-full rounded-xs transition-all duration-500 ${barColor}`}
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};

// 3. Simple SVG Line Trend Chart
export const TrendLineChart: React.FC<{
  points: number[];
  labels?: string[];
  color?: string;
  height?: number;
  unit?: string;
}> = ({ points, labels, color = '#00F0FF', height = 120, unit = '' }) => {
  if (!points || points.length === 0) return <div className="text-slate-500 text-xs">No trend data</div>;

  const min = Math.min(...points);
  const max = Math.max(...points) || 1;
  const range = max - min || 1;
  const width = 450;
  const padX = 20;
  const padY = 20;

  const innerW = width - padX * 2;
  const innerH = height - padY * 2;

  const coords = points.map((p, idx) => {
    const x = padX + (idx / (points.length - 1)) * innerW;
    const y = height - padY - ((p - min) / range) * innerH;
    return { x, y, val: p };
  });

  const pathD = coords.reduce((acc, curr, idx) => {
    return idx === 0 ? `M ${curr.x} ${curr.y}` : `${acc} L ${curr.x} ${curr.y}`;
  }, '');

  const areaD = `${pathD} L ${coords[coords.length - 1].x} ${height - padY} L ${coords[0].x} ${height - padY} Z`;

  return (
    <div className="w-full flex flex-col">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible">
        <defs>
          <linearGradient id={`grad-${color}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.25" />
            <stop offset="100%" stopColor={color} stopOpacity="0.0" />
          </linearGradient>
        </defs>
        {/* Horizontal grid guide */}
        <line x1={padX} y1={padY} x2={width - padX} y2={padY} stroke="#1E2F52" strokeDasharray="3 3" />
        <line x1={padX} y1={height/2} x2={width - padX} y2={height/2} stroke="#1E2F52" strokeDasharray="3 3" />
        <line x1={padX} y1={height - padY} x2={width - padX} y2={height - padY} stroke="#1E2F52" />

        {/* Shaded Area */}
        <path d={areaD} fill={`url(#grad-${color})`} />

        {/* Main Line */}
        <path d={pathD} fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" />

        {/* Data points */}
        {coords.map((c, i) => (
          <circle key={i} cx={c.x} cy={c.y} r="3" fill="#0B1324" stroke={color} strokeWidth="2" />
        ))}
      </svg>
      {labels && (
        <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1 px-2">
          {labels.map((l, i) => (
            <span key={i}>{l}</span>
          ))}
        </div>
      )}
    </div>
  );
};

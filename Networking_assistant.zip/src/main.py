"""
Main FastAPI entry point for NETPULSE AI.
Configures CORS, logging, lifespan handlers, Prometheus metrics (/metrics), and REST API routing.
"""
import time
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from src.config import settings
from src.api.routes import router, initialize_services

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(name)s]: %(message)s"
)
logger = logging.getLogger("netpulse_ai")

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting up %s v%s...", settings.APP_NAME, settings.APP_VERSION)
    try:
        initialize_services()
        logger.info("%s ready to serve requests.", settings.APP_NAME)
    except Exception as e:
        logger.error("Initialization failure during startup: %s", e, exc_info=True)
    yield
    logger.info("Shutting down %s...", settings.APP_NAME)

app = FastAPI(
    title="NETPULSE AI API",
    description="AI-Powered Telecom Network Operations Assistant — Hybrid RAG, Multi-Agent Diagnostics, & Network Impact Analysis",
    version=settings.APP_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Strict CORS configuration restricted to local origins
ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://localhost:8000",
    "http://127.0.0.1:8000"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def add_process_time_and_logging(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = f"{process_time:.4f}"
    return response

# Prometheus instrumentation
try:
    from prometheus_fastapi_instrumentator import Instrumentator
    Instrumentator().instrument(app).expose(app, endpoint="/metrics", tags=["Observability"])
    logger.info("Prometheus metrics initialized at /metrics")
except Exception as e:
    logger.warning("Could not initialize Prometheus instrumentator: %s", e)

# Mount routes
app.include_router(router)

@app.get("/")
def root():
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "online",
        "docs": "/docs",
        "health": "/health",
        "metrics": "/metrics"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host="0.0.0.0", port=8000, reload=True)

# Reload trigger

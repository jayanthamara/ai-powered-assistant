"""
Pydantic API schemas for NETPULSE AI endpoints.
Provides strict validation, OpenAPI definitions, and type safety across all layers.
"""
from typing import Dict, Any, List, Optional, Union
from pydantic import BaseModel, Field, ConfigDict, model_validator

class TelemetryModel(BaseModel):
    """
    Validated operational telemetry model for 5G NetOps metrics.
    Enforces numeric types, plausible KPI ranges, and forbids unknown fields.
    """
    model_config = ConfigDict(extra="forbid")

    cell_availability: Optional[float] = Field(default=None, ge=0.0, le=100.0, description="Cell availability percentage [0, 100]")
    mttr: Optional[float] = Field(default=None, ge=0.0, le=500.0, description="Mean time to repair in hours")
    throughput: Optional[float] = Field(default=None, ge=0.0, le=10000.0, description="Throughput in Mbps")
    latency: Optional[float] = Field(default=None, ge=0.0, le=5000.0, description="Latency in ms")
    packet_loss_rate: Optional[float] = Field(default=None, ge=0.0, le=100.0, description="Packet loss rate percentage [0, 100]")
    call_drop_rate: Optional[float] = Field(default=None, ge=0.0, le=100.0, description="Call drop rate percentage [0, 100]")
    handover_success_rate: Optional[float] = Field(default=None, ge=0.0, le=100.0, description="Handover success rate percentage [0, 100]")
    alarm_count: Optional[float] = Field(default=None, ge=0.0, le=5000.0, description="Total active alarms")
    critical_alarm_count: Optional[float] = Field(default=None, ge=0.0, le=1000.0, description="Critical alarm count")
    parameter_changes: Optional[float] = Field(default=None, ge=0.0, le=1000.0, description="Configuration parameter modifications")
    successful_configuration_changes: Optional[float] = Field(default=None, ge=0.0, le=1000.0, description="Successful configuration changes")
    data_usage: Optional[float] = Field(default=None, ge=0.0, le=1000000.0, description="Data volume usage in GB")
    user_count: Optional[float] = Field(default=None, ge=0.0, le=10000000.0, description="Connected user count")
    signal_strength: Optional[float] = Field(default=None, ge=-200.0, le=50.0, description="RSRP/Signal strength in dBm")
    jitter: Optional[float] = Field(default=None, ge=0.0, le=5000.0, description="Packet jitter in ms")
    connection_setup_success_rate: Optional[float] = Field(default=None, ge=0.0, le=100.0, description="Connection setup success percentage [0, 100]")
    security_incidents: Optional[float] = Field(default=None, ge=0.0, le=1000.0, description="Security incident count")
    authentication_failures: Optional[float] = Field(default=None, ge=0.0, le=10000.0, description="Authentication failure count")
    temperature: Optional[float] = Field(default=None, ge=-100.0, le=150.0, description="Ambient tower temperature in Celsius")
    humidity: Optional[float] = Field(default=None, ge=0.0, le=100.0, description="Relative humidity percentage [0, 100]")
    fault_occurrence_rate: Optional[float] = Field(default=None, ge=0.0, le=100.0, description="Fault occurrence rate percentage [0, 100]")
    zip: Optional[float] = Field(default=None, ge=0.0, le=99999.0, description="Postal zip code")

    @model_validator(mode="before")
    @classmethod
    def normalize_aliases(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        alias_map = {
            "packet_loss": "packet_loss_rate",
            "packet_loss_pct": "packet_loss_rate",
            "call_drop": "call_drop_rate",
            "call_drop_pct": "call_drop_rate",
            "handover_success": "handover_success_rate",
            "handover_success_pct": "handover_success_rate",
            "alarms": "alarm_count",
            "critical_alarms": "critical_alarm_count",
            "signal_strength_dbm": "signal_strength",
            "latency_ms": "latency",
            "throughput_mbps": "throughput",
            "jitter_ms": "jitter",
            "data_usage_gb": "data_usage",
            "temperature_c": "temperature",
            "mttr_hours": "mttr",
            "connection_setup": "connection_setup_success_rate",
            "cell_availability_pct": "cell_availability",
        }
        normalized = {}
        for k, v in data.items():
            k_clean = str(k).strip().lower()
            mapped = alias_map.get(k_clean, k_clean)
            normalized[mapped] = v
        return normalized

class FilterParams(BaseModel):
    city: Optional[str] = Field(default=None, description="Target city name, e.g. Minneapolis")
    state: Optional[str] = Field(default=None, description="State, e.g. MN")
    season: Optional[str] = Field(default=None, description="Season: Winter, Spring, Summer, Fall")
    weather: Optional[str] = Field(default=None, description="Weather condition: Clouds, Rain, Clear, Snow")
    severity: Optional[str] = Field(default=None, description="Severity: LOW, MEDIUM, HIGH, CRITICAL")
    issue_reported: Optional[str] = Field(default=None, description="Issue reported: yes, no")
    min_latency: Optional[float] = None
    max_latency: Optional[float] = None
    min_throughput: Optional[float] = None
    max_throughput: Optional[float] = None
    min_packet_loss: Optional[float] = None
    max_packet_loss: Optional[float] = None
    min_availability: Optional[float] = None

class QueryRequest(BaseModel):
    query: str = Field(..., json_schema_extra={"example": "A cell is experiencing high latency, packet loss and reduced throughput. Find similar historical incidents."})
    filters: Optional[FilterParams] = None
    telemetry: Optional[TelemetryModel] = None
    top_k: Optional[int] = Field(default=5, ge=1, le=20)

class SearchRequest(BaseModel):
    query: str = Field(..., json_schema_extra={"example": "high latency packet loss low throughput"})
    filters: Optional[FilterParams] = None
    top_k: Optional[int] = Field(default=5, ge=1, le=50)

class ClassifyRequest(BaseModel):
    query: str = Field(..., json_schema_extra={"example": "Handover success declining and call drops increasing"})
    telemetry: Optional[TelemetryModel] = None

class RiskRequest(BaseModel):
    telemetry: TelemetryModel = Field(..., json_schema_extra={"example": {"latency": 120.0, "packet_loss_rate": 6.5, "critical_alarm_count": 3}})

class PredictRequest(BaseModel):
    telemetry: TelemetryModel = Field(..., json_schema_extra={"example": {"latency": 95.0, "packet_loss_rate": 4.2, "throughput": 55.0}})

class AnalyzeRequest(BaseModel):
    query: Optional[str] = None
    telemetry: Optional[TelemetryModel] = None

class RecommendRequest(BaseModel):
    incident_type: str = Field(default="Service Degradation")
    telemetry: Optional[TelemetryModel] = None
    root_causes: Optional[List[Dict[str, Any]]] = None

class FeedbackRequest(BaseModel):
    query: str
    incident_type: Optional[str] = Field(default=None, description="Associated incident type")
    diagnosis_feedback: str = Field(..., description="Helpful, Not Helpful, Correct Diagnosis, Incorrect Diagnosis", json_schema_extra={"example": "Helpful"})
    recommendation_feedback: Optional[str] = Field(default=None, description="Recommendation Worked, Recommendation Did Not Work")
    user_comment: Optional[str] = None
    grounding_rating: Optional[float] = Field(default=1.0, ge=0.0, le=1.0)
    case_id: Optional[str] = None

class ActiveInvestigationContext(BaseModel):
    investigation_id: Optional[str] = None
    user_query: Optional[str] = None
    incident_type: Optional[str] = None
    severity: Optional[str] = None
    location: Optional[str] = None
    metrics: Optional[Dict[str, Any]] = None
    risk_score: Optional[float] = None
    risk_level: Optional[str] = None
    risk_factors: Optional[List[str]] = None
    root_causes: Optional[List[Dict[str, Any]]] = None
    network_impact: Optional[Dict[str, Any]] = None
    similar_cases: Optional[List[Dict[str, Any]]] = None
    predictions: Optional[Dict[str, Any]] = None
    recommendations: Optional[List[Dict[str, Any]]] = None

class CopilotRequest(BaseModel):
    query: str = Field(..., json_schema_extra={"example": "what is packet loss?"})
    session_id: Optional[str] = None
    investigation_context: Optional[Dict[str, Any]] = None
    telemetry: Optional[TelemetryModel] = None
    filters: Optional[FilterParams] = None
    top_k: Optional[int] = Field(default=5, ge=1, le=20)

class CopilotRoutingSchema(BaseModel):
    intent: str
    scope: str
    confidence: float
    requires_network_analysis: bool = False
    requires_retrieval: bool = False
    requires_current_investigation_context: bool = False
    clarification_prompt: Optional[str] = None

class CopilotResponse(BaseModel):
    request_id: str
    response_mode: str
    message: str
    routing: CopilotRoutingSchema
    investigation_context: Optional[Dict[str, Any]] = None
    incident: Optional[Dict[str, Any]] = None
    risk: Optional[Dict[str, Any]] = None
    root_causes: Optional[List[Dict[str, Any]]] = None
    network_impact: Optional[Dict[str, Any]] = None
    predictions: Optional[Dict[str, Any]] = None
    recommendations: Optional[List[Dict[str, Any]]] = None
    similar_cases: Optional[List[Dict[str, Any]]] = None

class ReindexResponse(BaseModel):
    success: bool
    records_indexed: int
    vector_store: str
    collection_name: str
    message: str

class QueryEvaluationRequest(BaseModel):
    query: str = Field(..., json_schema_extra={"example": "Why is packet loss increasing in Hyderabad during monsoon?"})
    expected_incident_type: Optional[str] = None
    expected_incident_ids: Optional[List[str]] = None
    filters: Optional[FilterParams] = None
    top_k: Optional[int] = Field(default=5, ge=1, le=20)


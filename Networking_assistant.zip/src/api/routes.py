"""
FastAPI route handlers for NETPULSE AI.
Implements all required RESTful endpoints, error handling, metadata filtering, and telemetry aggregation.
"""
import os
import json
import time
import logging
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np
import joblib
from fastapi import APIRouter, HTTPException, Query, Depends, File, UploadFile
from fastapi.responses import FileResponse

from src.config import settings
from src.schemas.api_schemas import (
    QueryRequest, SearchRequest, ClassifyRequest, RiskRequest,
    PredictRequest, AnalyzeRequest, RecommendRequest, FeedbackRequest,
    CopilotRequest, CopilotResponse, QueryEvaluationRequest
)
from src.evaluation.query_evaluator import QueryLevelEvaluator, BenchmarkEvaluator
from src.rag.hybrid_search import HybridSearchEngine
from src.rag.embedder import DenseTelecomEmbedder
from src.rag.vector_store import DenseVectorStore
from src.rag.bm25_retriever import BM25Retriever
from src.ml.risk_model import MLRiskService
from src.ml.performance_model import MLPerformanceService
from src.agents.orchestrator import MultiAgentOrchestrator
from src.agents.retrieval_agent import RetrievalAgent
from src.agents.risk_analyst import RiskAnalystAgent
from src.agents.incident_classifier import IncidentClassifierAgent
from src.agents.network_analyst import NetworkAnalystAgent
from src.agents.recommendation_agent import RecommendationEngineAgent
from src.agents.root_cause_analyst import RootCauseAnalystAgent
from src.analytics.condition_extractor import extract_network_conditions
from src.services.copilot_service import CopilotService
from src.guardrails.input_validator import validate_free_text_guardrail
from src.database.db import (
    save_feedback, log_query_execution, get_recent_feedback, get_feedback_statistics
)

logger = logging.getLogger("routes")
router = APIRouter()

# Global App State
app_state: Dict[str, Any] = {
    "df": None,
    "search_engine": None,
    "orchestrator": None,
    "ml_risk_service": None,
    "ml_perf_service": None,
    "copilot_service": None
}


def get_app_state() -> Dict[str, Any]:
    if app_state["orchestrator"] is None:
        initialize_services()
    return app_state

def initialize_services():
    """Initializes and caches dataset, search engine, ML services, and multi-agent orchestrator."""
    logger.info("Initializing NETPULSE AI core engine...")
    
    # 1. Load dataset
    csv_path = settings.PROCESSED_DATA_PATH
    if not os.path.exists(csv_path):
        from scripts.preprocess_dataset import preprocess_dataset
        csv_path = preprocess_dataset()
    
    df = pd.read_csv(csv_path)
    app_state["df"] = df

    # 2. Load or build search indices
    index_path = settings.INDEX_STORAGE_PATH
    if not os.path.exists(index_path):
        from scripts.build_index import build_search_indices
        search_bundle = build_search_indices(df, index_path)
    else:
        search_bundle = joblib.load(index_path)

    embedder = search_bundle["embedder"]
    vector_store = search_bundle["vector_store"]
    bm25 = search_bundle["bm25"]

    search_engine = HybridSearchEngine(
        embedder=embedder,
        vector_store=vector_store,
        bm25=bm25,
        df=df
    )
    app_state["search_engine"] = search_engine

    # 3. Load ML models
    ml_path = settings.ML_MODELS_PATH
    if not os.path.exists(ml_path):
        from scripts.build_index import train_ml_models
        train_ml_models(df, ml_path)

    ml_risk_service = MLRiskService(ml_path)
    ml_perf_service = MLPerformanceService(ml_path)
    app_state["ml_risk_service"] = ml_risk_service
    app_state["ml_perf_service"] = ml_perf_service

    # 4. Construct Multi-Agent Orchestrator
    retrieval_agent = RetrievalAgent(search_engine)
    risk_analyst = RiskAnalystAgent(ml_risk_service)
    
    orchestrator = MultiAgentOrchestrator(
        retrieval_agent=retrieval_agent,
        risk_analyst=risk_analyst,
        performance_service=ml_perf_service
    )
    app_state["orchestrator"] = orchestrator

    # 5. Construct Telecom Copilot Service
    copilot_service = CopilotService(
        orchestrator=orchestrator,
        search_engine=search_engine,
        risk_analyst=risk_analyst,
        performance_service=ml_perf_service,
        df=df
    )
    app_state["copilot_service"] = copilot_service
    logger.info("NETPULSE AI services fully initialized.")

# ==========================================
# REST API ENDPOINTS
# ==========================================

@router.get("/health")
def health_check():
    """Health and liveness probe."""
    state = get_app_state()
    return {
        "status": "healthy",
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "demo_mode": settings.DEMO_MODE,
        "records_indexed": len(state["df"]) if state["df"] is not None else 0,
        "uptime_status": "operational"
    }

@router.post("/api/v1/copilot", response_model=CopilotResponse)
def copilot_chat(
    req: CopilotRequest,
    state: Dict[str, Any] = Depends(get_app_state),
    _guardrail: None = Depends(validate_free_text_guardrail)
):
    """
    Telecom Network Operations Copilot Endpoint.
    Applies strict telecom domain scope filtering, intent routing,
    evidence relevance gating, and active investigation context awareness.
    """
    copilot: CopilotService = state["copilot_service"]
    filters_dict = req.filters.dict(exclude_none=True) if req.filters else {}
    telemetry_dict = req.telemetry.model_dump(exclude_none=True) if req.telemetry else None
    return copilot.handle_message(
        query=req.query,
        session_id=req.session_id,
        investigation_context=req.investigation_context,
        telemetry=telemetry_dict,
        filters=filters_dict,
        top_k=req.top_k or settings.TOP_K
    )

@router.post("/api/v1/chat", response_model=CopilotResponse)
def copilot_chat_alias(
    req: CopilotRequest,
    state: Dict[str, Any] = Depends(get_app_state),
    _guardrail: None = Depends(validate_free_text_guardrail)
):
    """API alias for /api/v1/copilot."""
    return copilot_chat(req, state, _guardrail)

@router.post("/api/v1/query")
def process_query(
    req: QueryRequest,
    state: Dict[str, Any] = Depends(get_app_state),
    _guardrail: None = Depends(validate_free_text_guardrail)
):
    """
    Main investigation endpoint:
    Executes full multi-agent diagnostic workflow, hybrid search, risk scoring,
    network impact analysis, recommendation generation, and LLM-as-judge evaluation.
    """
    filters_dict = req.filters.dict(exclude_none=True) if req.filters else {}
    orchestrator: MultiAgentOrchestrator = state["orchestrator"]
    telemetry_dict = req.telemetry.model_dump(exclude_none=True) if req.telemetry else None

    result = orchestrator.process_investigation(
        query=req.query,
        filters=filters_dict,
        direct_metrics=telemetry_dict,
        top_k=req.top_k or settings.TOP_K
    )

    if not result.get("success", False):
        raise HTTPException(status_code=400, detail=result.get("error", "Query validation failed."))

    # Log to audit database
    log_query_execution(
        query=result["query"],
        incident_type=result["incident"]["type"],
        risk_score=result["risk"]["score"],
        risk_level=result["risk"]["level"],
        impact_score=result["network_impact"]["impact_score"],
        latency_seconds=result["metadata"]["total_latency_seconds"]
    )

    return result

@router.post("/api/v1/search")
def search_cases(
    req: SearchRequest,
    state: Dict[str, Any] = Depends(get_app_state),
    _guardrail: None = Depends(validate_free_text_guardrail)
):
    """Hybrid semantic vector and keyword retrieval endpoint."""
    search_engine: HybridSearchEngine = state["search_engine"]
    filters_dict = req.filters.dict(exclude_none=True) if req.filters else {}
    parsed_cond = extract_network_conditions(req.query)

    results = search_engine.search(
        query=req.query,
        filters=filters_dict,
        extracted_metrics=parsed_cond.get("metrics", {}),
        extracted_location={"city": parsed_cond.get("city"), "state": parsed_cond.get("state")},
        top_k=req.top_k or settings.TOP_K
    )
    return {
        "query": req.query,
        "count": len(results),
        "results": results
    }

@router.post("/api/v1/classify")
def classify_incident(
    req: ClassifyRequest,
    _guardrail: None = Depends(validate_free_text_guardrail)
):
    """Categorizes incident and computes severity."""
    parsed_cond = extract_network_conditions(req.query)
    telemetry_dict = req.telemetry.model_dump(exclude_none=True) if req.telemetry else {}
    classification = IncidentClassifierAgent.classify(
        query=req.query,
        parsed_conditions=parsed_cond,
        telemetry=telemetry_dict
    )
    return classification

@router.post("/api/v1/analyze")
def analyze_network(
    req: AnalyzeRequest,
    state: Dict[str, Any] = Depends(get_app_state),
    _guardrail: None = Depends(validate_free_text_guardrail)
):
    """Runs deterministic telemetry analysis and Network Impact Analysis."""
    query = req.query or "General telemetry analysis"
    parsed_cond = extract_network_conditions(query)
    telemetry_dict = req.telemetry.model_dump(exclude_none=True) if req.telemetry else {}
    analysis = NetworkAnalystAgent.analyze_network_condition(
        parsed_conditions=parsed_cond,
        retrieved_cases=[],
        direct_metrics=telemetry_dict
    )
    return analysis

@router.post("/api/v1/risk")
def calculate_risk(req: RiskRequest, state: Dict[str, Any] = Depends(get_app_state)):
    """Computes deterministic and ML operational risk scores."""
    ml_risk: MLRiskService = state["ml_risk_service"]
    risk_analyst = RiskAnalystAgent(ml_risk)
    telemetry_dict = req.telemetry.model_dump(exclude_none=True)
    return risk_analyst.analyze_risk(telemetry_dict)

@router.post("/api/v1/predict")
def predict_performance(req: PredictRequest, state: Dict[str, Any] = Depends(get_app_state)):
    """Predicts estimated network KPIs using Random Forest models."""
    ml_perf: MLPerformanceService = state["ml_perf_service"]
    telemetry_dict = req.telemetry.model_dump(exclude_none=True)
    return ml_perf.predict_performance(telemetry_dict)

@router.get("/api/v1/ml/metrics")
def get_ml_metrics():
    """
    Returns empirical train/test split evaluation metrics for the trained ML models:
    ROC-AUC, F1, precision, recall for Random Forest risk classifier,
    and MAE/R² for fault occurrence and performance regressors.
    """
    metrics_path = "data/processed/ml_metrics.json"
    if os.path.exists(metrics_path):
        with open(metrics_path, "r", encoding="utf-8") as f:
            return json.load(f)
    raise HTTPException(status_code=404, detail="ML metrics have not been generated yet.")

@router.post("/api/v1/recommend")
def get_recommendations(
    req: RecommendRequest,
    state: Dict[str, Any] = Depends(get_app_state),
    _guardrail: None = Depends(validate_free_text_guardrail)
):
    """Derives engineering recommendations based on root causes and incident type."""
    root_causes = req.root_causes or []
    telemetry_dict = req.telemetry.model_dump(exclude_none=True) if req.telemetry else {}
    recommendations = RecommendationEngineAgent.generate_recommendations(
        root_causes=root_causes,
        historical_cases=[],
        telemetry=telemetry_dict,
        incident_type=req.incident_type
    )
    return {"recommendations": recommendations}

@router.post("/api/v1/feedback")
def submit_feedback(req: FeedbackRequest):
    """Stores operator feedback and validation ratings in SQLite."""
    feedback_id = save_feedback(
        query=req.query,
        incident_type=req.incident_type,
        diagnosis_feedback=req.diagnosis_feedback,
        recommendation_feedback=req.recommendation_feedback,
        user_comment=req.user_comment,
        grounding_rating=req.grounding_rating,
        case_id=req.case_id
    )
    return {
        "status": "success",
        "feedback_id": feedback_id,
        "message": "Operator feedback recorded successfully. Applied to continuous candidate reranking."
    }

@router.get("/api/v1/feedback")
def fetch_feedback(limit: int = 50):
    """Retrieves recorded operator feedback submissions and aggregate stats."""
    entries = get_recent_feedback(limit=limit)
    stats = get_feedback_statistics()
    return {
        "status": "success",
        "statistics": stats,
        "feedback_entries": entries
    }

@router.get("/api/v1/filters")
def get_filter_vocabularies(state: Dict[str, Any] = Depends(get_app_state)):
    """Returns distinct categorical filter vocabularies derived directly from the active dataset."""
    df: pd.DataFrame = state["df"]
    return {
        "cities": sorted(df["city"].dropna().unique().tolist()) if "city" in df.columns else [],
        "states": sorted(df["state"].dropna().unique().tolist()) if "state" in df.columns else [],
        "seasons": sorted(df["season"].dropna().unique().tolist()) if "season" in df.columns else [],
        "weather": sorted(df["weather"].dropna().unique().tolist()) if "weather" in df.columns else [],
        "severities": ["LOW", "MEDIUM", "HIGH", "CRITICAL"],
        "issues": sorted(df["issue_reported"].dropna().unique().tolist()) if "issue_reported" in df.columns else []
    }

@router.get("/api/v1/incidents")
def list_incidents(
    city: Optional[str] = None,
    state_filter: Optional[str] = Query(default=None, alias="state"),
    season: Optional[str] = None,
    severity: Optional[str] = None,
    issue: Optional[str] = None,
    sort_by: Optional[str] = Query(default="highest_risk", description="highest_risk, most_alarms, worst_latency, most_recent"),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    state: Dict[str, Any] = Depends(get_app_state)
):
    """Searchable, filterable historical incidents table."""
    df: pd.DataFrame = state["df"]
    filtered_df = df.copy()

    if city:
        filtered_df = filtered_df[filtered_df["city"].str.lower() == city.lower()]
    if state_filter:
        filtered_df = filtered_df[filtered_df["state"].str.lower() == state_filter.lower()]
    if season:
        filtered_df = filtered_df[filtered_df["season"].str.lower() == season.lower()]
    if severity:
        filtered_df = filtered_df[filtered_df["severity"].str.upper() == severity.upper()]
    if issue:
        filtered_df = filtered_df[filtered_df["issue_reported"].str.lower().str.contains(issue.lower())]

    # Sorting
    if sort_by == "highest_risk":
        filtered_df = filtered_df.sort_values(by="fault_occurrence_rate", ascending=False)
    elif sort_by == "most_alarms":
        filtered_df = filtered_df.sort_values(by="critical_alarm_count", ascending=False)
    elif sort_by == "worst_latency":
        filtered_df = filtered_df.sort_values(by="latency", ascending=False)

    total_records = len(filtered_df)
    page_records = filtered_df.iloc[offset:offset + limit].to_dict(orient="records")

    return {
        "total": total_records,
        "offset": offset,
        "limit": limit,
        "incidents": page_records
    }

@router.get("/api/v1/statistics")
def get_statistics(state: Dict[str, Any] = Depends(get_app_state)):
    """Aggregates telemetry statistics and risk distribution across the network corpus."""
    df: pd.DataFrame = state["df"]
    
    city_counts = df["city"].value_counts().to_dict()
    season_counts = df["season"].value_counts().to_dict()
    severity_counts = df["severity"].value_counts().to_dict()
    issue_counts = df["issue_reported"].value_counts().head(8).to_dict()

    avg_metrics = {
        "avg_latency_ms": round(float(df["latency"].mean()), 1),
        "avg_throughput_mbps": round(float(df["throughput"].mean()), 1),
        "avg_packet_loss_rate": round(float(df["packet_loss_rate"].mean()), 2),
        "avg_handover_success_rate": round(float(df["handover_success_rate"].mean()), 1),
        "avg_call_drop_rate": round(float(df["call_drop_rate"].mean()), 2),
        "total_active_alarms": int(df["alarm_count"].sum()),
        "total_critical_alarms": int(df["critical_alarm_count"].sum()),
        "avg_cell_availability": round(float(df["cell_availability"].mean()), 2)
    }

    fb_stats = get_feedback_statistics()

    return {
        "total_records": len(df),
        "metrics": avg_metrics,
        "severity_distribution": severity_counts,
        "city_distribution": city_counts,
        "season_distribution": season_counts,
        "top_issues": issue_counts,
        "feedback_stats": fb_stats
    }

@router.get("/api/v1/metrics")
def get_metrics(state: Dict[str, Any] = Depends(get_app_state)):
    """KPI summary blocks for the Network Operations Command Center."""
    df: pd.DataFrame = state["df"]
    
    # Calculate calibrated operational health index (0-100)
    avail = float(df["cell_availability"].mean())
    hosr = float(df["handover_success_rate"].mean())
    loss = float(df["packet_loss_rate"].mean())
    health_index = round(min(100.0, max(0.0, (avail * 0.50) + (hosr * 0.45) - (loss * 1.2))), 1)

    # Data-driven alert and risk indicators (75th percentile thresholds)
    crit_alerts = int((df["critical_alarm_count"] >= 8.42).sum())
    high_risk_cells = int((df["high_fault_risk"] == 1).sum()) if "high_fault_risk" in df.columns else int((df["fault_occurrence_rate"] >= 48.28).sum())

    return {
        "network_health_score": health_index,
        "network_health_status": "OPTIMAL" if health_index >= 88 else ("DEGRADED" if health_index >= 75 else "CRITICAL"),
        "active_incidents": int((df["severity"].isin(["HIGH", "CRITICAL"])).sum()),
        "critical_alerts": crit_alerts,
        "high_risk_cells": high_risk_cells,
        "avg_latency": f"{df['latency'].mean():.1f} ms",
        "avg_packet_loss": f"{df['packet_loss_rate'].mean():.2f}%",
        "avg_handover_success": f"{df['handover_success_rate'].mean():.1f}%",
        "avg_throughput": f"{df['throughput'].mean():.1f} Mbps"
    }

@router.get("/api/v1/cases/{case_id}")
def get_case_detail(case_id: str, state: Dict[str, Any] = Depends(get_app_state)):
    """Fetches full historical record by ID."""
    df: pd.DataFrame = state["df"]
    matched = df[df["incident_id"].str.lower() == case_id.lower()]
    if matched.empty:
        raise HTTPException(status_code=404, detail=f"Historical case '{case_id}' not found.")
    return matched.iloc[0].to_dict()

@router.get("/api/v1/config")
def get_configuration():
    """Returns active runtime configuration, RAG weights, and operational parameters."""
    return {
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "demo_mode": settings.DEMO_MODE,
        "llm_provider": settings.LLM_PROVIDER,
        "llm_model": settings.LLM_MODEL,
        "embedding_model": settings.EMBEDDING_MODEL,
        "vector_store": settings.VECTOR_STORE,
        "rag_weights": {
            "semantic_weight": settings.SEMANTIC_WEIGHT,
            "keyword_weight": settings.KEYWORD_WEIGHT,
            "metric_weight": settings.METRIC_WEIGHT,
            "metadata_weight": settings.METADATA_WEIGHT
        },
        "top_k": settings.TOP_K,
        "data_path": settings.PROCESSED_DATA_PATH
    }

@router.post("/api/v1/upload")
async def upload_dataset(
    file: UploadFile = File(...),
    merge: bool = Query(default=True, description="Merge with existing dataset or replace"),
    state: Dict[str, Any] = Depends(get_app_state)
):
    """
    Directly uploads a raw telecom CSV file to the server.
    Sanitizes filename (basename only), enforces size limit (50MB), validates 26-field schema,
    normalizes columns, rebuilds search indices and retrains ML models.
    """
    # 1. Sanitize filename (prevent path traversal)
    safe_filename = os.path.basename(file.filename or "uploaded.csv")
    if not safe_filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files (.csv) are supported for dataset ingestion.")
    
    # 2. Enforce size limit (50 MB)
    MAX_UPLOAD_SIZE = 50 * 1024 * 1024
    content = await file.read()
    if len(content) > MAX_UPLOAD_SIZE:
        raise HTTPException(status_code=400, detail="Uploaded file exceeds 50MB size limit.")
    if len(content) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    raw_dir = "data/raw"
    os.makedirs(raw_dir, exist_ok=True)
    target_path = os.path.join(raw_dir, safe_filename)
    with open(target_path, "wb") as f:
        f.write(content)

    # 3. Schema validation against canonical columns
    try:
        import io
        from src.database.dataset_loader import normalize_dataframe
        test_df = pd.read_csv(io.BytesIO(content), nrows=5)
        test_norm = normalize_dataframe(test_df)
        essential_keys = {"cell_availability", "throughput", "latency", "packet_loss_rate", "call_drop_rate", "handover_success_rate"}
        missing_keys = essential_keys - set(test_norm.columns)
        if len(missing_keys) > 2:
            raise HTTPException(
                status_code=422,
                detail=f"Uploaded CSV does not match 5G NetOps schema. Missing required operational fields: {list(missing_keys)}"
            )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse uploaded CSV: {str(e)}")

    base_raw = settings.RAW_DATA_PATH
    if merge and os.path.exists(base_raw) and os.path.abspath(target_path) != os.path.abspath(base_raw):
        try:
            df_old = pd.read_csv(base_raw)
            df_new = pd.read_csv(target_path)
            id_col = "Incident_ID" if "Incident_ID" in df_old.columns else ("incident_id" if "incident_id" in df_old.columns else None)
            df_combined = pd.concat([df_old, df_new], ignore_index=True)
            if id_col:
                df_combined = df_combined.drop_duplicates(subset=[id_col], keep="last")
            df_combined.to_csv(base_raw, index=False)
            logger.info("Merged %d uploaded records into %s. Total records: %d", len(df_new), base_raw, len(df_combined))
        except Exception as e:
            logger.warning("Could not merge datasets (%s). Using newly uploaded CSV directly.", e)
            import shutil
            shutil.copyfile(target_path, base_raw)
    else:
        import shutil
        shutil.copyfile(target_path, base_raw)

    # Preprocess, reindex and retrain
    from scripts.preprocess_dataset import preprocess_dataset
    from scripts.build_index import build_search_indices, train_ml_models

    csv_path = preprocess_dataset(base_raw)
    df = pd.read_csv(csv_path)
    build_search_indices(df, settings.INDEX_STORAGE_PATH)
    train_ml_models(df, settings.ML_MODELS_PATH)

    initialize_services()

    return {
        "status": "success",
        "filename": safe_filename,
        "total_records": len(df),
        "message": f"Dataset '{safe_filename}' successfully validated, ingested, and indexed! Total records now: {len(df)}."
    }

@router.post("/api/v1/reindex")
def trigger_reindex(state: Dict[str, Any] = Depends(get_app_state)):
    """Reindexes historical incident corpus into persistent ChromaDB and retrains ML models."""
    try:
        from scripts.preprocess_dataset import preprocess_dataset
        from scripts.build_index import build_search_indices, train_ml_models

        csv_path = preprocess_dataset()
        df = pd.read_csv(csv_path)
        build_search_indices(df, settings.INDEX_STORAGE_PATH)
        train_ml_models(df, settings.ML_MODELS_PATH)
        initialize_services()

        return {
            "success": True,
            "status": "success",
            "records_indexed": len(df),
            "vector_store": settings.VECTOR_STORE,
            "collection_name": settings.CHROMA_COLLECTION_NAME,
            "message": f"Successfully re-indexed {len(df)} records into persistent ChromaDB collection '{settings.CHROMA_COLLECTION_NAME}' and retrained ML models."
        }
    except Exception as e:
        logger.error("Re-indexing failed: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Re-indexing failed: {str(e)}")

@router.get("/api/v1/evaluation/embedding")
def get_embedding_evaluation():
    """Returns empirical benchmark metrics (Recall@K, MRR, nDCG, latency) comparing embedding models."""
    eval_file = "evaluation/results/embedding_eval_results.json"
    if not os.path.exists(eval_file):
        from evaluation.embedding_evaluation import run_embedding_benchmark
        return run_embedding_benchmark()
    with open(eval_file, "r", encoding="utf-8") as f:
        return json.load(f)

@router.post("/api/v1/evaluation/run")
def run_query_evaluation(
    req: QueryEvaluationRequest,
    state: Dict[str, Any] = Depends(get_app_state),
    _guardrail: None = Depends(validate_free_text_guardrail)
):
    """
    Primary interactive evaluation endpoint:
    Executes diagnostic pipeline for THIS specific user query and performs
    comprehensive grounding, classification, and retrieval evaluation without dataset-wide scans.
    """
    filters_dict = req.filters.dict(exclude_none=True) if req.filters else {}
    orchestrator: MultiAgentOrchestrator = state["orchestrator"]

    # 1. Execute full query investigation pipeline with top_k >= 10 for valid Top-10 evaluation
    eval_top_k = max(10, req.top_k or 10)
    investigation = orchestrator.process_investigation(
        query=req.query,
        filters=filters_dict,
        top_k=eval_top_k
    )

    if not investigation.get("success", False):
        raise HTTPException(status_code=400, detail=investigation.get("error", "Query investigation failed."))

    # 2. Evaluate THIS specific execution against evidence from fenar/5g_netops
    evaluation = QueryLevelEvaluator.evaluate_query(
        query=req.query,
        investigation=investigation,
        ground_truth={
            "expected_incident_type": req.expected_incident_type,
            "expected_incident_ids": req.expected_incident_ids
        },
        df=state.get("df")
    )

    return {
        "success": True,
        "query": req.query,
        "investigation": investigation,
        "evaluation": evaluation
    }

@router.post("/api/v1/evaluation/benchmark")
def run_benchmark_evaluation(limit: Optional[int] = Query(default=None, ge=1), state: Dict[str, Any] = Depends(get_app_state)):
    """
    Runs aggregate benchmark evaluation against predefined golden evaluation queries.
    Strictly on-demand; never triggered automatically on page load.
    """
    orchestrator: MultiAgentOrchestrator = state["orchestrator"]
    results = BenchmarkEvaluator.run_benchmark(orchestrator=orchestrator, df=state.get("df"), limit=limit)
    return results

@router.get("/api/v1/evaluation/benchmark")
def get_benchmark_samples():
    """Returns the predefined golden benchmark queries derived from fenar/5g_netops."""
    return BenchmarkEvaluator.load_benchmark_dataset()


@router.get("/api/v1/evaluation/ragas")
def get_ragas_evaluation_results():
    """Returns the latest empirical RAGAS RAG pipeline evaluation results."""
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    results_path = os.path.join(project_root, "evaluation", "results", "ragas_results.json")
    if not os.path.exists(results_path):
        results_path = os.path.join(".", "evaluation", "results", "ragas_results.json")
    if not os.path.exists(results_path):
        raise HTTPException(status_code=404, detail="RAGAS evaluation results not found. Run evaluation first.")
    with open(results_path, "r", encoding="utf-8") as f:
        return json.load(f)


@router.get("/api/v1/evaluation/deepeval")
def get_deepeval_evaluation_results():
    """Returns the latest empirical DeepEval AI/Agent application evaluation results."""
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    results_path = os.path.join(project_root, "evaluation", "results", "deepeval_results.json")
    if not os.path.exists(results_path):
        results_path = os.path.join(".", "evaluation", "results", "deepeval_results.json")
    if not os.path.exists(results_path):
        raise HTTPException(status_code=404, detail="DeepEval evaluation results not found. Run test suite first.")
    with open(results_path, "r", encoding="utf-8") as f:
        return json.load(f)


@router.post("/api/v1/evaluation/ragas/run")
def trigger_ragas_evaluation(limit: Optional[int] = Query(default=5, ge=1, le=20)):
    """Triggers an on-demand RAGAS RAG pipeline evaluation run."""
    try:
        from evaluation.ragas_evaluation import run_ragas_evaluation
        summary = run_ragas_evaluation(limit=limit)
        return summary
    except Exception as e:
        logger.error("RAGAS evaluation execution failed: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"RAGAS evaluation execution failed: {str(e)}")




"""
Monitoring, Observability, and Telemetry Engine for NETPULSE AI.
Configures OpenTelemetry tracing, Prometheus metrics export (/metrics),
and structured JSON logging tracking granular stage latencies and model telemetry.
"""
import time
import json
import uuid
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger("telemetry")

# -------------------------------------------------------------
# 1. Prometheus Metrics Setup
# -------------------------------------------------------------
try:
    from prometheus_client import Counter, Histogram, Gauge

    METRIC_REQUESTS_TOTAL = Counter(
        "netpulse_requests_total",
        "Total requests received by NETPULSE AI",
        ["endpoint", "status"]
    )
    METRIC_REQUEST_LATENCY = Histogram(
        "netpulse_request_duration_seconds",
        "Total request duration in seconds",
        ["endpoint"],
        buckets=[0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0]
    )
    METRIC_RETRIEVAL_LATENCY = Histogram(
        "netpulse_retrieval_duration_seconds",
        "Hybrid RAG retrieval duration in seconds",
        buckets=[0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0]
    )
    METRIC_RERANK_LATENCY = Histogram(
        "netpulse_rerank_duration_seconds",
        "Cross-feature reranker duration in seconds",
        buckets=[0.005, 0.01, 0.025, 0.05, 0.1, 0.25]
    )
    METRIC_LLM_LATENCY = Histogram(
        "netpulse_llm_duration_seconds",
        "LLM synthesis duration in seconds",
        buckets=[0.1, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0]
    )
    METRIC_GUARDRAIL_BLOCKS = Counter(
        "netpulse_guardrail_blocks_total",
        "Total queries blocked by guardrails",
        ["reason"]
    )
    METRIC_OUT_OF_SCOPE = Counter(
        "netpulse_out_of_scope_total",
        "Total queries identified as out of scope"
    )
    METRIC_EVAL_OVERALL_SCORE = Histogram(
        "netpulse_eval_overall_score",
        "Judge evaluation overall quality scores",
        buckets=[0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.95, 1.0]
    )
    PROMETHEUS_AVAILABLE = True
except Exception as e:
    logger.warning("Prometheus client not active (%s). Metrics disabled.", e)
    PROMETHEUS_AVAILABLE = False


# -------------------------------------------------------------
# 2. OpenTelemetry Tracing Setup
# -------------------------------------------------------------
try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor, ConsoleSpanExporter

    provider = TracerProvider()
    trace.set_tracer_provider(provider)
    tracer = trace.get_tracer("netpulse-ai", "1.1.0")
    OTEL_AVAILABLE = True
except Exception as e:
    tracer = None
    OTEL_AVAILABLE = False


# -------------------------------------------------------------
# 3. Structured JSON Logging Logger
# -------------------------------------------------------------
def log_structured_event(
    event_type: str,
    request_id: str,
    endpoint: str,
    latency_breakdown: Optional[Dict[str, float]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    error: Optional[str] = None
):
    """Logs structured JSON audit record for NOC observability."""
    payload = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "event_type": event_type,
        "request_id": request_id,
        "endpoint": endpoint,
        "latencies": latency_breakdown or {},
        "meta": metadata or {},
        "error": error
    }
    logger.info("NETPULSE_AUDIT: %s", json.dumps(payload))


def record_request_metrics(
    endpoint: str,
    status: str,
    total_latency: float,
    retrieval_latency: Optional[float] = None,
    rerank_latency: Optional[float] = None,
    llm_latency: Optional[float] = None,
    eval_score: Optional[float] = None
):
    """Records real-time observability telemetry into Prometheus collectors."""
    if not PROMETHEUS_AVAILABLE:
        return
    try:
        METRIC_REQUESTS_TOTAL.labels(endpoint=endpoint, status=status).inc()
        METRIC_REQUEST_LATENCY.labels(endpoint=endpoint).observe(total_latency)
        if retrieval_latency is not None:
            METRIC_RETRIEVAL_LATENCY.observe(retrieval_latency)
        if rerank_latency is not None:
            METRIC_RERANK_LATENCY.observe(rerank_latency)
        if llm_latency is not None:
            METRIC_LLM_LATENCY.observe(llm_latency)
        if eval_score is not None:
            METRIC_EVAL_OVERALL_SCORE.observe(eval_score)
    except Exception as e:
        logger.debug("Failed recording prometheus metrics: %s", e)

"""
Advanced RAG Reranking Engine for NETPULSE AI.
Performs cross-signal reranking over candidate historical incident records,
and generates empirical, explainable match evidence reasons without hallucination.
"""
import logging
from typing import List, Dict, Any, Optional
import numpy as np

logger = logging.getLogger("reranker")

class TelecomReranker:
    """
    Domain-specialized Cross-Feature Telecom Reranker.
    Refines candidate retrieval rankings from hybrid fusion and produces
    verifiable, empirical match evidence reasons for each historical case.
    """
    def __init__(self):
        pass

    def rerank(
        self,
        query: str,
        candidates: List[Dict[str, Any]],
        extracted_metrics: Optional[Dict[str, Any]] = None,
        extracted_location: Optional[Dict[str, str]] = None,
        query_metrics: Optional[Dict[str, Any]] = None,
        query_location: Optional[Dict[str, str]] = None,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        if not candidates:
            return []

        extracted_metrics = extracted_metrics or query_metrics or {}
        extracted_location = extracted_location or query_location or {}
        q_lower = query.lower()

        reranked = []
        for cand in candidates:
            cand_copy = dict(cand)
            metrics = cand_copy.get("metrics", {})
            location = cand_copy.get("location", {})
            initial_sim = float(cand_copy.get("similarity_score", 0.70))

            # Preserve initial first-stage hybrid retrieval score
            cand_copy["initial_similarity_score"] = initial_sim
            cand_copy["similarity_score"] = initial_sim  # Keep first-stage match score untouched

            match_reasons: List[str] = []
            bonus_score = 0.0

            # 1. Geographic Alignment (Candidate specific)
            target_city = extracted_location.get("city") or ""
            target_state = extracted_location.get("state") or ""
            cand_city = location.get("city", "")
            cand_state = location.get("state", "")

            if target_city and cand_city and target_city.lower() == cand_city.lower():
                bonus_score += 0.16
                match_reasons.append(f"Geographic Match: Same operational cluster ({cand_city}, {cand_state})")
            elif target_state and cand_state and target_state.lower() == cand_state.lower():
                bonus_score += 0.08
                match_reasons.append(f"Regional Alignment: Same telecom circle ({cand_state})")

            # 2. Metric Proximity: Latency (Continuous candidate-specific deviation)
            lat = metrics.get("latency")
            if lat is not None:
                if "latency" in extracted_metrics:
                    target_lat = extracted_metrics["latency"].get("min", extracted_metrics["latency"].get("val", 75.0))
                    if target_lat is not None:
                        delta_lat = abs(lat - target_lat)
                        proximity = max(0.0, 1.0 - (delta_lat / 100.0))
                        lat_bonus = round(0.12 * proximity, 4)
                        bonus_score += lat_bonus
                        if delta_lat <= 30.0:
                            match_reasons.append(f"Similar Latency: Target ~{target_lat:.0f} ms vs Historical {lat:.1f} ms (Δ {delta_lat:.1f} ms)")
                        else:
                            match_reasons.append(f"Latency Pattern Alignment: {lat:.1f} ms")
                elif lat > 85.0 and any(k in q_lower for k in ["latency", "delay", "lag", "ping"]):
                    lat_score = min(0.12, 0.04 + (lat - 85.0) / 400.0)
                    bonus_score += lat_score
                    match_reasons.append(f"Elevated SLA Latency Breach: {lat:.1f} ms")

            # 3. Metric Proximity: Packet Loss Rate (Continuous candidate-specific deviation)
            loss = metrics.get("packet_loss_rate")
            if loss is not None:
                if "packet_loss_rate" in extracted_metrics:
                    target_loss = extracted_metrics["packet_loss_rate"].get("min", extracted_metrics["packet_loss_rate"].get("val", 5.0))
                    if target_loss is not None:
                        delta_loss = abs(loss - target_loss)
                        proximity = max(0.0, 1.0 - (delta_loss / 10.0))
                        loss_bonus = round(0.12 * proximity, 4)
                        bonus_score += loss_bonus
                        match_reasons.append(f"Packet Loss Correlation: Target ~{target_loss:.1f}% vs Historical {loss:.2f}% (Δ {delta_loss:.2f}%)")
                elif loss > 3.0 and any(k in q_lower for k in ["packet loss", "loss", "drop"]):
                    loss_score = min(0.12, 0.04 + (loss - 3.0) / 70.0)
                    bonus_score += loss_score
                    match_reasons.append(f"Matching Packet Drop Rate: {loss:.2f}%")

            # 4. Metric Proximity: Throughput Degradation
            tp = metrics.get("throughput")
            if tp is not None:
                if "throughput" in extracted_metrics:
                    target_tp = extracted_metrics["throughput"].get("max", extracted_metrics["throughput"].get("val", 400.0))
                    if target_tp is not None:
                        delta_tp = abs(tp - target_tp)
                        proximity = max(0.0, 1.0 - (delta_tp / 400.0))
                        tp_bonus = round(0.10 * proximity, 4)
                        bonus_score += tp_bonus
                        match_reasons.append(f"Downlink Throughput Match: Historical {tp:.1f} Mbps (Target ~{target_tp:.0f} Mbps)")
                elif tp < 450.0 and any(k in q_lower for k in ["throughput", "speed", "bandwidth"]):
                    tp_score = min(0.10, 0.03 + (450.0 - tp) / 3000.0)
                    bonus_score += tp_score
                    match_reasons.append(f"Severe Downlink Throughput Throttling: {tp:.1f} Mbps")

            # 5. Handover / Mobility Impairment
            hosr = metrics.get("handover_success_rate")
            if hosr is not None and hosr < 94.0 and any(k in q_lower for k in ["handover", "mobility"]):
                hosr_score = min(0.10, 0.04 + (94.0 - hosr) / 70.0)
                bonus_score += hosr_score
                match_reasons.append(f"Mobility Handover Degradation: {hosr:.1f}% success rate")

            # 6. Alarms & Fault Indicators (Candidate-specific ratio)
            alarms = metrics.get("alarm_count", 0)
            crit_alarms = metrics.get("critical_alarm_count", 0)
            if crit_alarms >= 1 and any(k in q_lower for k in ["alarm", "fault", "outage"]):
                alarm_score = min(0.10, 0.03 + (crit_alarms / 15.0) * 0.07)
                bonus_score += alarm_score
                match_reasons.append(f"Critical Alarm Pattern: {int(crit_alarms)} active alarms ({int(alarms)} total)")

            # 7. Environmental & Weather Concurrence
            weather = cand_copy.get("weather", "")
            season = cand_copy.get("season", "")
            if weather and weather.lower() in q_lower:
                bonus_score += 0.07
                match_reasons.append(f"Weather Condition Match: {weather} during {season}")

            # 8. Baseline Semantic Token Alignment
            issue = cand_copy.get("issue_reported", "")
            if not match_reasons:
                match_reasons.append(f"Semantic Keyword Match: Correlates with historical '{issue}'")

            # 9. Real Operator Feedback Loop Adjustment (Bounded +/- 0.06 from SQLite)
            case_id = cand_copy.get("incident_id")
            feedback_adj = 0.0
            if case_id:
                try:
                    import sqlite3
                    db_path = "data/netpulse.db"
                    if os.path.exists(db_path):
                        conn = sqlite3.connect(db_path)
                        cur = conn.cursor()
                        cur.execute("""
                            SELECT 
                                SUM(CASE WHEN diagnosis_feedback IN ('Helpful', 'Correct Diagnosis') OR recommendation_feedback = 'Recommendation Worked' THEN 1 ELSE 0 END),
                                SUM(CASE WHEN diagnosis_feedback IN ('Not Helpful', 'Incorrect Diagnosis') OR recommendation_feedback = 'Recommendation Did Not Work' THEN 1 ELSE 0 END)
                            FROM operator_feedback
                            WHERE case_id = ?
                        """, (case_id,))
                        row = cur.fetchone()
                        conn.close()
                        if row and (row[0] is not None or row[1] is not None):
                            pos_c = row[0] or 0
                            neg_c = row[1] or 0
                            feedback_adj = min(0.06, max(-0.06, (pos_c - neg_c) * 0.02))
                            if feedback_adj > 0:
                                match_reasons.append(f"Operator Endorsement: Verified in {pos_c} NOC review(s) (+{feedback_adj:+.2f})")
                            elif feedback_adj < 0:
                                match_reasons.append(f"Operator Caution: Flagged in {neg_c} NOC review(s) ({feedback_adj:+.2f})")
                except Exception:
                    pass

            # Calculate candidate-specific rerank score
            # Fuses initial retrieval score (55%) with cross-feature alignment bonus (45%) plus feedback adjustment
            cross_feature_score = min(0.99, max(0.30, 0.40 + bonus_score))
            base_rerank = 0.55 * initial_sim + 0.45 * cross_feature_score
            rerank_score = round(min(0.99, max(0.25, base_rerank + feedback_adj)), 4)

            cand_copy["rerank_score"] = rerank_score
            cand_copy["feedback_adjustment"] = round(feedback_adj, 4)
            cand_copy["match_reasons"] = match_reasons
            reranked.append(cand_copy)

        # Sort descending by candidate-specific rerank score
        reranked.sort(key=lambda x: x["rerank_score"], reverse=True)
        return reranked[:top_k]

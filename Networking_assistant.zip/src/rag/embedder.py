"""
Embedder abstraction for NETPULSE AI.
Supports SentenceTransformers, dense semantic LSA (TFIDF+SVD) fallback, and OpenAI.
Guarantees fast, offline, deterministic vector representations.
"""
import os
import logging
from typing import List, Union
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import normalize

logger = logging.getLogger("embedder")

class DenseTelecomEmbedder:
    """
    High-performance semantic dense vector embedder.
    Combines subword n-gram TF-IDF with TruncatedSVD semantic dimensionality reduction
    and L2 normalization to produce 128-dimensional dense semantic vectors.
    Also dynamically wraps sentence-transformers if installed.
    """
    def __init__(self, n_components: int = 128, use_sentence_transformers: bool = False):
        self.n_components = n_components
        self.use_st = use_sentence_transformers
        self.st_model = None
        self.vectorizer: TfidfVectorizer = TfidfVectorizer(
            ngram_range=(1, 2),
            max_features=5000,
            sublinear_tf=True
        )
        self.svd: TruncatedSVD = TruncatedSVD(n_components=n_components, random_state=42)
        self.is_fitted = False

        if self.use_st:
            try:
                from sentence_transformers import SentenceTransformer
                self.st_model = SentenceTransformer("all-MiniLM-L6-v2")
                logger.info("Loaded sentence-transformers model 'all-MiniLM-L6-v2'.")
            except Exception as e:
                logger.info("SentenceTransformers not active (%s). Using high-speed Dense SVD Embedder.", e)
                self.st_model = None

    def fit(self, texts: List[str]):
        if self.st_model is not None:
            self.is_fitted = True
            return self
        
        tfidf_mat = self.vectorizer.fit_transform(texts)
        # Ensure n_components doesn't exceed min(n_samples, n_features)
        n_features = tfidf_mat.shape[1]
        n_samples = tfidf_mat.shape[0]
        actual_comp = min(self.n_components, n_samples - 1, n_features - 1)
        if actual_comp < 2:
            actual_comp = 2
        self.svd = TruncatedSVD(n_components=actual_comp, random_state=42)
        self.svd.fit(tfidf_mat)
        self.is_fitted = True
        logger.info("Fitted DenseTelecomEmbedder with %d dimensions over %d documents.", actual_comp, len(texts))
        return self

    def embed_documents(self, texts: List[str]) -> np.ndarray:
        if self.st_model is not None:
            return np.array(self.st_model.encode(texts, normalize_embeddings=True))
        
        if not self.is_fitted:
            self.fit(texts)
        
        tfidf_mat = self.vectorizer.transform(texts)
        dense_vecs = self.svd.transform(tfidf_mat)
        return normalize(dense_vecs, norm='l2')

    def embed_query(self, query: str) -> np.ndarray:
        if self.st_model is not None:
            emb = self.st_model.encode([query], normalize_embeddings=True)
            return np.array(emb[0])
            
        if not self.is_fitted:
            raise ValueError("Embedder has not been fitted on document corpus yet.")
            
        tfidf_mat = self.vectorizer.transform([query])
        dense_vec = self.svd.transform(tfidf_mat)
        normalized = normalize(dense_vec, norm='l2')
        return normalized[0]

"""
BM25 Keyword Retriever for NETPULSE AI.
Implements exact term and keyword relevance scoring using rank_bm25 with tokenization.
"""
import re
import logging
from typing import List, Tuple
import numpy as np
from rank_bm25 import BM25Okapi

logger = logging.getLogger("bm25_retriever")

STOPWORDS = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are",
    "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but",
    "by", "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for", "from",
    "further", "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him",
    "himself", "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself", "just", "me",
    "more", "most", "my", "myself", "no", "nor", "not", "of", "off", "on", "once", "only", "or",
    "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same", "she", "should",
    "so", "some", "such", "than", "that", "the", "their", "theirs", "them", "themselves", "then",
    "there", "these", "they", "this", "those", "through", "to", "too", "under", "until", "up",
    "very", "was", "we", "were", "what", "when", "where", "which", "while", "who", "whom", "why",
    "with", "would", "you", "your", "yours", "yourself", "yourselves"
}

def tokenize(text: str) -> List[str]:
    tokens = re.findall(r"\b[a-zA-Z0-9_\-]+\b", str(text).lower())
    return [t for t in tokens if t not in STOPWORDS and len(t) > 1]

class BM25Retriever:
    """Keyword retriever using BM25Okapi."""
    def __init__(self, corpus: List[str]):
        self.corpus = corpus
        self.tokenized_corpus = [tokenize(doc) for doc in corpus]
        self.bm25 = BM25Okapi(self.tokenized_corpus)
        logger.info("Initialized BM25 index with %d documents.", len(corpus))

    def get_scores(self, query: str) -> np.ndarray:
        tokens = tokenize(query)
        if not tokens:
            return np.zeros(len(self.corpus), dtype=float)
        raw_scores = self.bm25.get_scores(tokens)
        max_score = np.max(raw_scores)
        if max_score > 0:
            return raw_scores / max_score
        return np.zeros(len(self.corpus), dtype=float)

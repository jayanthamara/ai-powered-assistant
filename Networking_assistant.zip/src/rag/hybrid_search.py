"""
Hybrid Search Engine for NETPULSE AI.
Combines Dense Semantic Vector Search + BM25 Keyword Search + Metric Similarity + Metadata Matching.
Implements configurable weighted fusion and comprehensive, strict metadata filtering.
Never silently relaxes hard filters: returns empty results and filter_status='no_match' on zero match.
"""
import logging
from typing import List, Dict, Any, Optional
import numpy as np
import pandas as pd
from src.config import settings
from src.rag.embedder import DenseTelecomEmbedder
from src.rag.vector_store import DenseVectorStore, ChromaVectorStore
from src.rag.bm25_retriever import BM25Retriever
from src.rag.reranker import TelecomReranker

logger = logging.getLogger("hybrid_search")

class HybridSearchEngine:
    def __init__(
        self,
        embedder: DenseTelecomEmbedder,
        vector_store: Any,
        bm25: BM25Retriever,
        df: pd.DataFrame,
        reranker: Optional[TelecomReranker] = None
    ):
        self.embedder = embedder
        self.vector_store = vector_store
        self.bm25 = bm25
        self.df = df
        self.records = df.to_dict(orient="records")
        self.reranker = reranker or TelecomReranker()
        self.last_filter_status = "none"

    def _calculate_metric_similarity(self, extracted_metrics: Dict[str, Any]) -> np.ndarray:
        """
        Calculates similarity between query numeric constraints/ranges and historical record metrics.
        Returns array of scores in [0, 1] for all records.
        """
        n = len(self.df)
        if not extracted_metrics:
            return np.ones(n, dtype=float) * 0.7

        scores = np.zeros(n, dtype=float)
        matched_keys = 0

        # Latency
        if "latency" in extracted_metrics:
            matched_keys += 1
            target_lat = extracted_metrics["latency"].get("min", extracted_metrics["latency"].get("val", 77.0))
            lat_arr = self.df["latency"].values
            diff = np.abs(lat_arr - target_lat)
            scores += np.exp(-diff / 80.0)

        # Packet loss
        if "packet_loss_rate" in extracted_metrics:
            matched_keys += 1
            target_loss = extracted_metrics["packet_loss_rate"].get("min", extracted_metrics["packet_loss_rate"].get("val", 6.0))
            loss_arr = self.df["packet_loss_rate"].values
            diff = np.abs(loss_arr - target_loss)
            scores += np.exp(-diff / 6.0)

        # Throughput
        if "throughput" in extracted_metrics:
            matched_keys += 1
            target_tp = extracted_metrics["throughput"].get("max", extracted_metrics["throughput"].get("val", 500.0))
            tp_arr = self.df["throughput"].values
            diff = np.abs(tp_arr - target_tp)
            scores += np.exp(-diff / 200.0)

        # Alarms
        if "alarm_count" in extracted_metrics:
            matched_keys += 1
            target_alarms = extracted_metrics["alarm_count"].get("min", 10.0)
            alarm_arr = self.df["alarm_count"].values
            diff = np.abs(alarm_arr - target_alarms)
            scores += np.exp(-diff / 10.0)

        # Handover success
        if "handover_success_rate" in extracted_metrics:
            matched_keys += 1
            target_hosr = extracted_metrics["handover_success_rate"].get("val", 95.0)
            hosr_arr = self.df["handover_success_rate"].values
            diff = np.abs(hosr_arr - target_hosr)
            scores += np.exp(-diff / 10.0)

        if matched_keys > 0:
            return np.clip(scores / matched_keys, 0.0, 1.0)
        return np.ones(n, dtype=float) * 0.7

    def _calculate_metadata_match(
        self,
        filters: Dict[str, Any],
        extracted_location: Optional[Dict[str, str]] = None
    ) -> np.ndarray:
        """
        Calculates location and categorical metadata match score for each record.
        """
        n = len(self.df)
        scores = np.ones(n, dtype=float)

        city_target = filters.get("city") or (extracted_location.get("city") if extracted_location else None)
        state_target = filters.get("state") or (extracted_location.get("state") if extracted_location else None)
        season_target = filters.get("season")
        issue_target = filters.get("issue_reported") or filters.get("issue")
        severity_target = filters.get("severity")

        if city_target:
            city_match = (self.df["city"].str.lower() == city_target.lower()).astype(float).values
            scores = np.where(city_match == 1.0, 1.0, scores * 0.3)

        if state_target:
            state_match = (self.df["state"].str.lower() == state_target.lower()).astype(float).values
            scores = np.where(state_match == 1.0, scores, scores * 0.6)

        if season_target:
            season_match = (self.df["season"].str.lower() == season_target.lower()).astype(float).values
            scores = scores * 0.7 + season_match * 0.3

        if issue_target:
            issue_match = self.df["issue_reported"].str.lower().str.contains(issue_target.lower(), na=False).astype(float).values
            scores = scores * 0.7 + issue_match * 0.3

        if severity_target:
            sev_match = (self.df["severity"].str.upper() == severity_target.upper()).astype(float).values
            scores = scores * 0.7 + sev_match * 0.3

        return np.clip(scores, 0.0, 1.0)

    def _apply_hard_filters(self, filters: Dict[str, Any]) -> np.ndarray:
        """
        Applies strict boolean filtering mask across categorical and numeric criteria.
        Supports state, city, season, weather, severity, issue_reported, and numeric ranges.
        """
        mask = np.ones(len(self.df), dtype=bool)

        # Categorical exact match filters
        if "city" in filters and filters["city"]:
            mask &= (self.df["city"].str.lower() == str(filters["city"]).lower())
        if "state" in filters and filters["state"]:
            mask &= (self.df["state"].str.lower() == str(filters["state"]).lower())
        if "season" in filters and filters["season"]:
            mask &= (self.df["season"].str.lower() == str(filters["season"]).lower())
        if "weather" in filters and filters["weather"]:
            mask &= (self.df["weather"].str.lower() == str(filters["weather"]).lower())
        if "severity" in filters and filters["severity"]:
            mask &= (self.df["severity"].str.upper() == str(filters["severity"]).upper())
        if "issue_reported" in filters and filters["issue_reported"]:
            mask &= (self.df["issue_reported"].str.lower() == str(filters["issue_reported"]).lower())
        elif "issue" in filters and filters["issue"]:
            mask &= self.df["issue_reported"].str.lower().str.contains(str(filters["issue"]).lower(), na=False)

        # Numeric range filters
        if "min_latency" in filters and filters["min_latency"] is not None:
            mask &= (self.df["latency"] >= float(filters["min_latency"]))
        if "max_latency" in filters and filters["max_latency"] is not None:
            mask &= (self.df["latency"] <= float(filters["max_latency"]))

        if "min_throughput" in filters and filters["min_throughput"] is not None:
            mask &= (self.df["throughput"] >= float(filters["min_throughput"]))
        if "max_throughput" in filters and filters["max_throughput"] is not None:
            mask &= (self.df["throughput"] <= float(filters["max_throughput"]))

        if "min_packet_loss" in filters and filters["min_packet_loss"] is not None:
            mask &= (self.df["packet_loss_rate"] >= float(filters["min_packet_loss"]))
        if "max_packet_loss" in filters and filters["max_packet_loss"] is not None:
            mask &= (self.df["packet_loss_rate"] <= float(filters["max_packet_loss"]))

        if "min_call_drop" in filters and filters["min_call_drop"] is not None:
            mask &= (self.df["call_drop_rate"] >= float(filters["min_call_drop"]))
        if "max_call_drop" in filters and filters["max_call_drop"] is not None:
            mask &= (self.df["call_drop_rate"] <= float(filters["max_call_drop"]))

        if "min_handover" in filters and filters["min_handover"] is not None:
            mask &= (self.df["handover_success_rate"] >= float(filters["min_handover"]))
        if "max_handover" in filters and filters["max_handover"] is not None:
            mask &= (self.df["handover_success_rate"] <= float(filters["max_handover"]))

        if "min_alarm_count" in filters and filters["min_alarm_count"] is not None:
            mask &= (self.df["alarm_count"] >= float(filters["min_alarm_count"]))
        if "max_alarm_count" in filters and filters["max_alarm_count"] is not None:
            mask &= (self.df["alarm_count"] <= float(filters["max_alarm_count"]))

        if "min_availability" in filters and filters["min_availability"] is not None:
            mask &= (self.df["cell_availability"] >= float(filters["min_availability"]))
        if "max_availability" in filters and filters["max_availability"] is not None:
            mask &= (self.df["cell_availability"] <= float(filters["max_availability"]))

        if "min_signal_strength" in filters and filters["min_signal_strength"] is not None:
            mask &= (self.df["signal_strength"] >= float(filters["min_signal_strength"]))
        if "max_signal_strength" in filters and filters["max_signal_strength"] is not None:
            mask &= (self.df["signal_strength"] <= float(filters["max_signal_strength"]))

        return mask

    def search(
        self,
        query: str,
        filters: Optional[Dict[str, Any]] = None,
        extracted_metrics: Optional[Dict[str, Any]] = None,
        extracted_location: Optional[Dict[str, str]] = None,
        top_k: Optional[int] = None,
        semantic_weight: Optional[float] = None,
        keyword_weight: Optional[float] = None,
        metric_weight: Optional[float] = None,
        metadata_weight: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """
        Performs hybrid retrieval with score fusion and metadata ranking.
        Never silently relaxes hard filters: returns empty list if filters match nothing.
        """
        filters = filters or {}
        extracted_metrics = extracted_metrics or {}
        top_k = top_k or settings.TOP_K
        w_sem = semantic_weight if semantic_weight is not None else settings.SEMANTIC_WEIGHT
        w_kw = keyword_weight if keyword_weight is not None else settings.KEYWORD_WEIGHT
        w_met = metric_weight if metric_weight is not None else settings.METRIC_WEIGHT
        w_meta = metadata_weight if metadata_weight is not None else settings.METADATA_WEIGHT

        # Normalize weights so sum is 1.0
        total_w = w_sem + w_kw + w_met + w_meta
        if total_w > 0:
            w_sem /= total_w
            w_kw /= total_w
            w_met /= total_w
            w_meta /= total_w

        # Check hard filters first
        has_active_filters = bool(filters) and any(v is not None and v != "" for v in filters.values())
        if has_active_filters:
            mask = self._apply_hard_filters(filters)
            if not np.any(mask):
                self.last_filter_status = "no_match"
                logger.info("Hard filters matched 0 records. Returning empty result (filter_status='no_match').")
                return []
            self.last_filter_status = "applied"
        else:
            mask = np.ones(len(self.df), dtype=bool)
            self.last_filter_status = "none"

        # 1. Semantic Vector Score (TF-IDF + SVD LSA Embedder)
        q_vec = self.embedder.embed_query(query)
        semantic_scores = self.vector_store.similarity_search_scores(q_vec)

        # 2. BM25 Keyword Score
        keyword_scores = self.bm25.get_scores(query)

        # 3. Metric Similarity Score
        metric_scores = self._calculate_metric_similarity(extracted_metrics)

        # 4. Metadata Match Score
        meta_scores = self._calculate_metadata_match(filters, extracted_location)

        # 5. Hybrid Score Fusion
        hybrid_scores = (
            w_sem * semantic_scores +
            w_kw * keyword_scores +
            w_met * metric_scores +
            w_meta * meta_scores
        )

        # Boost location matches when extracted location is provided
        if extracted_location and extracted_location.get("city"):
            city_target = str(extracted_location["city"]).lower()
            city_boost = (self.df["city"].str.lower() == city_target).astype(float).values * 0.35
            hybrid_scores += city_boost
        if extracted_location and extracted_location.get("state"):
            state_target = str(extracted_location["state"]).lower()
            state_boost = (self.df["state"].str.lower() == state_target).astype(float).values * 0.15
            hybrid_scores += state_boost

        # Apply mask
        candidate_indices = np.where(mask)[0]
        candidate_scores = hybrid_scores[candidate_indices]

        # Extract top candidate pool for reranking
        pool_size = min(len(candidate_indices), max(top_k * 2, getattr(settings, "RERANK_CANDIDATE_POOL", 15)))
        top_idx_rel = np.argsort(candidate_scores)[::-1][:pool_size]
        top_indices = candidate_indices[top_idx_rel]

        candidates = []
        for idx in top_indices:
            row = self.records[idx]
            sim_score = float(round(hybrid_scores[idx], 4))

            # Formulate real data-derived outcome summary (no fabricated text)
            mttr_hrs = float(row.get("mttr", 0.0))
            crit_al = float(row.get("critical_alarm_count", 0.0))
            tot_al = int(float(row.get("alarm_count", 0.0)))
            tp = float(row.get("throughput", 0.0))
            lat = float(row.get("latency", 0.0))
            loss = float(row.get("packet_loss_rate", 0.0))
            issue = str(row.get("issue_reported", "no"))

            historical_outcome = (
                f"Recorded incident MTTR: {mttr_hrs:.1f} hours. "
                f"Telemetry recorded: {crit_al:.1f} critical alarms ({tot_al} total), "
                f"{tp:.1f} Mbps throughput, {lat:.1f} ms latency, {loss:.2f}% packet loss. "
                f"Issue reported flag: {issue}."
            )

            why_similar = []
            if semantic_scores[idx] > 0.65:
                why_similar.append(f"Semantic narrative similarity ({int(semantic_scores[idx]*100)}%)")
            if keyword_scores[idx] > 0.35:
                why_similar.append(f"BM25 term correlation ({int(keyword_scores[idx]*100)}%)")
            target_city = (extracted_location.get("city") or "").lower() if extracted_location else ""
            if target_city and (str(row.get("city") or "").lower() == target_city):
                why_similar.append(f"Geographic match ({row.get('city')}, {row.get('state')})")
            if "latency" in query.lower() and row.get("latency", 0) > 100:
                why_similar.append(f"Comparable elevated latency pattern ({row.get('latency'):.1f} ms)")
            if "packet loss" in query.lower() and row.get("packet_loss_rate", 0) > 6:
                why_similar.append(f"Elevated packet loss pattern ({row.get('packet_loss_rate'):.2f}%)")
            if not why_similar:
                why_similar.append("General operational anomaly profile alignment")

            cand_item = {
                "incident_id": row.get("incident_id", f"5G-NETOPS-{idx}"),
                "similarity_score": sim_score,
                "vector_score": float(round(semantic_scores[idx], 4)),
                "bm25_score": float(round(keyword_scores[idx], 4)),
                "metric_score": float(round(metric_scores[idx], 4)),
                "metadata_score": float(round(meta_scores[idx], 4)),
                "why_similar": why_similar,
                "historical_outcome": historical_outcome,
                "filter_status": self.last_filter_status,
                "location": {
                    "city": row.get("city", "Unknown"),
                    "state": row.get("state", "Unknown"),
                    "zip": row.get("zip", "")
                },
                "environmental": {
                    "season": row.get("season", "Unknown"),
                    "weather": row.get("weather", "Unknown"),
                    "temperature": row.get("temperature", 0.0),
                    "humidity": row.get("humidity", 0.0)
                },
                "metrics": {
                    "cell_availability": float(row.get("cell_availability", 0.0)),
                    "throughput": float(row.get("throughput", 0.0)),
                    "latency": float(row.get("latency", 0.0)),
                    "packet_loss_rate": float(row.get("packet_loss_rate", 0.0)),
                    "call_drop_rate": float(row.get("call_drop_rate", 0.0)),
                    "handover_success_rate": float(row.get("handover_success_rate", 0.0)),
                    "alarm_count": int(float(row.get("alarm_count", 0))),
                    "critical_alarm_count": float(row.get("critical_alarm_count", 0)),
                    "signal_strength": float(row.get("signal_strength", 0.0)),
                    "user_count": int(float(row.get("user_count", 0))),
                    "data_usage": float(row.get("data_usage", 0.0)),
                    "mttr": float(row.get("mttr", 0.0)),
                    "fault_occurrence_rate": float(row.get("fault_occurrence_rate", 0.0))
                },
                "severity": row.get("severity", "MEDIUM"),
                "issue_reported": row.get("issue_reported", "no"),
                "incident_document": row.get("incident_document", ""),
                "document": row.get("incident_document", "")
            }
            candidates.append(cand_item)

        # Apply Cross-Feature Telecom Reranker
        reranked = self.reranker.rerank(
            query=query,
            candidates=candidates,
            query_metrics=extracted_metrics,
            query_location=extracted_location,
            top_k=top_k
        )
        return reranked

"""
Persistent and in-memory vector stores for NETPULSE AI.
Supports persistent ChromaDB vector store with HNSW indexing, document IDs,
metadata filtering, batch indexing, and seamless restart recovery.
"""
import os
import logging
from typing import List, Dict, Any, Optional
import numpy as np

logger = logging.getLogger("vector_store")

def _sanitize_metadata_for_chroma(meta: Dict[str, Any]) -> Dict[str, Any]:
    """Ensures metadata values are valid ChromaDB primitives (str, int, float, bool)."""
    clean = {}
    for k, v in meta.items():
        if v is None:
            clean[k] = ""
        elif isinstance(v, (str, int, float, bool)):
            clean[k] = v
        else:
            clean[k] = str(v)
    return clean

class ChromaVectorStore:
    """
    Real persistent vector store powered by ChromaDB.
    Persists HNSW vector indices, document text, and metadata to disk.
    Prevents recomputing embeddings on every API restart.
    """
    def __init__(
        self,
        persist_dir: str = "data/chroma",
        collection_name: str = "netpulse_telecom_incidents"
    ):
        self.persist_dir = persist_dir
        self.collection_name = collection_name
        self.client = None
        self.collection = None
        self._cached_embeddings = None
        self._doc_ids = []
        self._init_chroma()

    def _init_chroma(self):
        try:
            import chromadb
            os.makedirs(self.persist_dir, exist_ok=True)
            self.client = chromadb.PersistentClient(path=self.persist_dir)
            self.collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"}
            )
            count = self.collection.count()
            logger.info("ChromaDB connected at '%s'. Collection '%s' contains %d items.",
                        self.persist_dir, self.collection_name, count)
        except Exception as e:
            logger.warning("Could not initialize ChromaDB (%s). Using in-memory fallback.", e)
            self.client = None
            self.collection = None

    def __getstate__(self):
        return {
            "persist_dir": self.persist_dir,
            "collection_name": self.collection_name,
            "_cached_embeddings": self._cached_embeddings,
            "_doc_ids": self._doc_ids
        }

    def __setstate__(self, state):
        self.persist_dir = state.get("persist_dir", "data/chroma")
        self.collection_name = state.get("collection_name", "netpulse_telecom_incidents")
        self._cached_embeddings = state.get("_cached_embeddings")
        self._doc_ids = state.get("_doc_ids", [])
        self.client = None
        self.collection = None
        self._init_chroma()

    def is_indexed(self) -> bool:
        if self.collection is not None:
            try:
                return self.collection.count() > 0
            except Exception:
                return False
        return False

    def count(self) -> int:
        if self.collection is not None:
            try:
                return self.collection.count()
            except Exception:
                return 0
        return 0

    def index_documents(
        self,
        ids: List[str],
        documents: List[str],
        embeddings: np.ndarray,
        metadatas: List[Dict[str, Any]],
        batch_size: int = 100,
        reset: bool = True
    ):
        """Batch indexes documents, dense embeddings, and metadata into persistent ChromaDB."""
        self._cached_embeddings = embeddings
        self._doc_ids = ids

        if self.collection is None:
            logger.warning("ChromaDB not active. Cached in memory only.")
            return

        clean_metas = [_sanitize_metadata_for_chroma(m) for m in metadatas]
        emb_list = embeddings.tolist() if isinstance(embeddings, np.ndarray) else embeddings

        n = len(ids)
        logger.info("Persisting %d documents into ChromaDB collection '%s'...", n, self.collection_name)

        if self.client is not None and reset:
            try:
                try:
                    self.client.delete_collection(self.collection_name)
                except Exception:
                    pass
                self.collection = self.client.get_or_create_collection(
                    name=self.collection_name,
                    metadata={"hnsw:space": "cosine"}
                )
            except Exception as e:
                logger.warning("Could not recreate collection in ChromaDB (%s).", e)

        for i in range(0, n, batch_size):
            b_ids = ids[i:i + batch_size]
            b_docs = documents[i:i + batch_size]
            b_embs = emb_list[i:i + batch_size]
            b_metas = clean_metas[i:i + batch_size]
            try:
                self.collection.upsert(
                    ids=b_ids,
                    documents=b_docs,
                    embeddings=b_embs,
                    metadatas=b_metas
                )
            except Exception as e:
                if "dimension" in str(e).lower() and self.client is not None:
                    logger.warning("Dimension mismatch (%s). Recreating collection '%s'...", e, self.collection_name)
                    try:
                        self.client.delete_collection(self.collection_name)
                    except Exception:
                        pass
                    self.collection = self.client.get_or_create_collection(
                        name=self.collection_name,
                        metadata={"hnsw:space": "cosine"}
                    )
                    self.collection.upsert(
                        ids=b_ids,
                        documents=b_docs,
                        embeddings=b_embs,
                        metadatas=b_metas
                    )
                else:
                    raise e
        logger.info("Successfully persisted %d documents into ChromaDB.", n)

    def similarity_search_scores(self, query_vec: np.ndarray) -> np.ndarray:
        """
        Computes cosine similarity scores for all indexed vectors.
        Aligned with hybrid search fusion pipeline.
        """
        # If in-memory matrix is available, compute direct cosine similarity
        if self._cached_embeddings is not None and len(self._cached_embeddings) > 0:
            norm = np.linalg.norm(query_vec)
            q = query_vec / norm if norm > 0 else query_vec
            sims = np.dot(self._cached_embeddings, q)
            return np.clip((sims + 1.0) / 2.0, 0.0, 1.0)

        # Fallback: retrieve from Chroma collection
        if self.collection is not None and self.collection.count() > 0:
            data = self.collection.get(include=["embeddings"])
            embs = data.get("embeddings") if data else None
            if embs is not None and len(embs) > 0:
                self._cached_embeddings = np.array(embs)
                self._doc_ids = data["ids"]
                norm = np.linalg.norm(query_vec)
                q = query_vec / norm if norm > 0 else query_vec
                sims = np.dot(self._cached_embeddings, q)
                return np.clip((sims + 1.0) / 2.0, 0.0, 1.0)

        return np.array([])

    def query_nearest(
        self,
        query_vec: np.ndarray,
        top_k: int = 5,
        where: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """Direct vector search with optional metadata filtering."""
        if self.collection is None or self.collection.count() == 0:
            return []

        q_emb = query_vec.tolist() if isinstance(query_vec, np.ndarray) else query_vec
        results = self.collection.query(
            query_embeddings=[q_emb],
            n_results=min(top_k, self.collection.count()),
            where=where if where else None
        )

        matches = []
        if results and "ids" in results and results["ids"]:
            ids = results["ids"][0]
            docs = results["documents"][0] if "documents" in results else [""] * len(ids)
            metas = results["metadatas"][0] if "metadatas" in results else [{}] * len(ids)
            dists = results["distances"][0] if "distances" in results else [0.0] * len(ids)

            for i in range(len(ids)):
                # Cosine distance to similarity: sim = 1.0 - (dist / 2.0)
                sim = max(0.0, min(1.0, 1.0 - dists[i] / 2.0))
                matches.append({
                    "incident_id": ids[i],
                    "document": docs[i],
                    "metadata": metas[i],
                    "similarity": round(sim, 4),
                    "distance": round(dists[i], 4)
                })
        return matches

    def __len__(self):
        return self.count()


class DenseVectorStore:
    """In-memory dense vector store with cosine similarity retrieval (backwards-compatible adapter)."""
    def __init__(self, embeddings: np.ndarray, documents: List[str], metadata: List[Dict[str, Any]]):
        self.embeddings = embeddings  # Shape: (N, D), assumed L2-normalized
        self.documents = documents
        self.metadata = metadata

    def similarity_search_scores(self, query_vec: np.ndarray) -> np.ndarray:
        norm = np.linalg.norm(query_vec)
        q = query_vec / norm if norm > 0 else query_vec
        sims = np.dot(self.embeddings, q)
        return np.clip((sims + 1.0) / 2.0, 0.0, 1.0)

    def __len__(self):
        return len(self.documents)

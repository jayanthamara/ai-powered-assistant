"""
Troubleshooting Recommendation Engine for NETPULSE AI.
Generates concrete, safe, prioritized engineering actions traceable to historical cases,
telemetry rules, and root cause findings.
"""
from typing import Dict, Any, List
from src.analytics.thresholds import load_thresholds

class RecommendationEngineAgent:
    @staticmethod
    def generate_recommendations(
        root_causes: List[Dict[str, Any]],
        historical_cases: List[Dict[str, Any]],
        telemetry: Dict[str, Any],
        incident_type: str
    ) -> List[Dict[str, Any]]:
        """
        Derives actionable, safe engineering recommendations tied to retrieved evidence cases.
        Matches exact root cause keys and uses data-driven thresholds for dispatch levels.
        """
        thresh = load_thresholds().get("kpis", {})
        crit_p75 = thresh.get("critical_alarm_count", {}).get("p75", 8.4)
        crit_p90 = thresh.get("critical_alarm_count", {}).get("p90", 9.6)

        # Collect top historical case IDs (no fabricated placeholder IDs)
        evidence_case_ids = [c["incident_id"] for c in historical_cases[:3] if "incident_id" in c]

        recommendations = []
        top_rc_names = [rc["root_cause"] for rc in root_causes[:2]] if root_causes else []

        # 1. Radio Access Network (RAN) Congestion Recommendations
        # Must match exact RAN congestion key and NOT transport congestion
        has_ran_congestion = any(
            rc in ["Radio Access Network (RAN) Congestion", "Cellular PRB/capacity saturation"]
            for rc in top_rc_names
        ) or incident_type == "Congestion"

        if has_ran_congestion:
            recommendations.append({
                "action": "Activate Dual-Connectivity Offloading & Adjust Remote Electrical Tilt (RET)",
                "priority": "HIGH",
                "reason": "Subscriber density causing Physical Resource Block (PRB) saturation on dominant carrier.",
                "evidence": evidence_case_ids,
                "category": "Traffic Engineering"
            })
            recommendations.append({
                "action": "Audit Neighboring Cell Load Sharing & Trigger Carrier Aggregation (CA) Steering",
                "priority": "MEDIUM",
                "reason": "Adjacent sectors have spare capacity to absorb low-mobility user sessions.",
                "evidence": evidence_case_ids[:2],
                "category": "Traffic Engineering"
            })
            recommendations.append({
                "action": "Dynamically Expand Scheduling Bandwidth via Secondary Cell Activation",
                "priority": "MEDIUM",
                "reason": "Relieve downlink PRB utilization bottleneck across peak usage intervals.",
                "evidence": evidence_case_ids[:2],
                "category": "Radio Optimization"
            })

        # 2. IP Transport / Backhaul Link Congestion & Jitter Recommendations
        has_transport_issue = any(
            "Transport" in rc or "Backhaul" in rc
            for rc in top_rc_names
        ) or incident_type in ["High Latency", "Packet Loss"]

        if has_transport_issue:
            recommendations.append({
                "action": "Verify S1-U / N3 Backhaul Router Queue Depths & Inspect Optical Port Error Rates",
                "priority": "HIGH",
                "reason": "Elevated packet loss and buffer delays indicate transport switch bottleneck or link degradation.",
                "evidence": evidence_case_ids,
                "category": "Transport Network"
            })
            recommendations.append({
                "action": "Audit Quality of Service (QoS) Class Identifier (QCI / 5QI) Weighting",
                "priority": "MEDIUM",
                "reason": "Ensure mission-critical VoNR and conversational traffic receive strict priority scheduling.",
                "evidence": evidence_case_ids[:2],
                "category": "Core / QoS"
            })

        # 3. Handover & Mobility Recommendations
        has_handover_issue = any(
            "Handover" in rc or "Mobility" in rc
            for rc in top_rc_names
        ) or incident_type == "Handover Failure"

        if has_handover_issue:
            recommendations.append({
                "action": "Rebalance A3 Time-To-Trigger (TTT) and Handover Margin (HOM) Parameters",
                "priority": "HIGH",
                "reason": "Signal fluctuation between sector boundaries causing ping-pong handovers and radio link drops.",
                "evidence": evidence_case_ids,
                "category": "Radio Optimization"
            })
            recommendations.append({
                "action": "Verify Automatic Neighbor Relation (ANR) Blacklist & Inter-Frequency Neighbors",
                "priority": "HIGH",
                "reason": "Audit missing target neighbor frequency relation in the active gNodeB cell table.",
                "evidence": evidence_case_ids,
                "category": "Configuration"
            })

        # 4. Critical Alarms & Hardware (use data-driven threshold, not > 0)
        crit_val = float(telemetry.get("critical_alarm_count", 0.0))
        has_hw_issue = any("Hardware" in rc for rc in top_rc_names) or (crit_val >= crit_p75)

        if has_hw_issue:
            is_urgent = crit_val >= crit_p90
            recommendations.append({
                "action": "Dispatch Field Maintenance to Inspect Tower Top Low-Noise Amplifier (LNA) & Transceivers",
                "priority": "CRITICAL" if is_urgent else "HIGH",
                "reason": f"Active critical hardware/interface alarms ({crit_val:.1f}) exceed the {('p90' if is_urgent else 'p75')} threshold.",
                "evidence": evidence_case_ids[:2],
                "category": "Field Engineering"
            })

        # 5. Signal Quality / Coverage
        has_rf_issue = any("RF" in rc or "Radio Frequency" in rc for rc in top_rc_names) or incident_type == "Poor Signal Quality"
        if has_rf_issue:
            recommendations.append({
                "action": "Execute Spectrum Sweep for External Passive Intermodulation (PIM) / Uplink Interference",
                "priority": "MEDIUM",
                "reason": "Degraded SINR in the presence of adequate RSRP indicates uplink interference in the licensed spectrum.",
                "evidence": evidence_case_ids,
                "category": "RF Optimization"
            })

        # Baseline / Operational Hygiene Fallback
        if len(recommendations) < 3:
            recommendations.append({
                "action": "Audit Operational Telemetry Against Historical Cluster Distributions",
                "priority": "LOW",
                "reason": "Quantify deviation from normal baseline distributions to validate performance recovery.",
                "evidence": evidence_case_ids[:1],
                "category": "Operations"
            })
        if len(recommendations) < 3:
            recommendations.append({
                "action": "Initiate Automated 15-Minute Cell KPI Health Check Polling",
                "priority": "LOW",
                "reason": "Track post-mitigation recovery across air-interface and IP transport metrics.",
                "evidence": evidence_case_ids[:1],
                "category": "Monitoring"
            })

        return recommendations[:5]

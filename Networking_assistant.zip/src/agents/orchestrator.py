"""
Multi-Agent Orchestrator for NETPULSE AI.
Coordinates deterministic analytics, hybrid RAG retrieval, ML inference,
network impact analysis, LLM response synthesis, and LLM-as-a-judge validation.
"""
import time
import logging
from typing import Dict, Any, Optional, List
from src.agents.query_analyst import QueryAnalystAgent
from src.agents.incident_classifier import IncidentClassifierAgent
from src.agents.retrieval_agent import RetrievalAgent
from src.agents.network_analyst import NetworkAnalystAgent
from src.agents.risk_analyst import RiskAnalystAgent
from src.agents.root_cause_analyst import RootCauseAnalystAgent
from src.agents.recommendation_agent import RecommendationEngineAgent
from src.agents.llm_synthesizer import LLMSynthesizerAgent
from src.agents.judge_agent import JudgeAgent
from src.ml.performance_model import MLPerformanceService
from src.config import settings

logger = logging.getLogger("orchestrator")

class MultiAgentOrchestrator:
    def __init__(
        self,
        retrieval_agent: RetrievalAgent,
        risk_analyst: RiskAnalystAgent,
        performance_service: MLPerformanceService
    ):
        self.retrieval_agent = retrieval_agent
        self.risk_analyst = risk_analyst
        self.performance_service = performance_service

    def process_investigation(
        self,
        query: str,
        filters: Optional[Dict[str, Any]] = None,
        direct_metrics: Optional[Dict[str, Any]] = None,
        top_k: int = 5
    ) -> Dict[str, Any]:
        """
        Executes the end-to-end multi-agent diagnostic pipeline.
        """
        start_time = time.time()
        logger.info("Starting investigation workflow for query: '%s'", query)

        agent_trace: List[Dict[str, Any]] = []

        # 1. Query Analyst Agent: Guardrails + Condition Extraction
        t0 = time.time()
        q_analysis = QueryAnalystAgent.analyze_query(query)
        if not q_analysis["is_valid"]:
            return {
                "success": False,
                "error": q_analysis["error_message"],
                "query": query
            }

        sanitized_query = q_analysis["sanitized_query"]
        parsed_conditions = q_analysis["parsed_conditions"]
        agent_trace.append({
            "step": 1,
            "agent": "QueryAnalystAgent",
            "action": "Input Guardrailing & Condition Extraction",
            "inputs_summary": f"Raw query: '{query[:80]}'",
            "output_summary": f"Valid: domain_conf={q_analysis.get('domain_confidence', 1.0)}, extracted {len(parsed_conditions.get('conditions', []))} condition(s)",
            "latency_seconds": round(time.time() - t0, 3)
        })

        # 2. Retrieval Agent: Hybrid Search Precedents
        t_retrieval_start = time.time()
        similar_cases = self.retrieval_agent.retrieve_similar_cases(
            query=sanitized_query,
            parsed_conditions=parsed_conditions,
            filters=filters,
            top_k=top_k
        )
        retrieval_latency = round(time.time() - t_retrieval_start, 3)
        agent_trace.append({
            "step": 2,
            "agent": "RetrievalAgent",
            "action": "Hybrid Dense + BM25 + Metric Fusion Search",
            "inputs_summary": f"Top-k={top_k}, filters={filters or 'None'}",
            "output_summary": f"Retrieved {len(similar_cases)} matching incident precedent(s) from fenar/5g_netops",
            "latency_seconds": retrieval_latency
        })

        # 3. Incident Telemetry & Evidence Synthesis
        t_synth_tel = time.time()
        q_lower = sanitized_query.lower()
        is_search_only = any(s in q_lower for s in [
            "show historical", "find historical", "search historical", "list historical",
            "historical incidents similar", "historical cases similar", "retrieve historical"
        ]) and not any(s in q_lower for s in ["experiencing", "recommend corrective actions", "diagnose", "active incident", "outage"])

        if is_search_only:
            active_telemetry = None
            risk_info = {
                "score": 0,
                "level": "INSUFFICIENT_EVIDENCE",
                "factors": ["Historical search request: Individual incident risk scores evaluated per retrieved precedent"],
                "risk_factors": []
            }
            incident_info = {
                "incident_type": "Historical Incident Search",
                "severity": "INSUFFICIENT_EVIDENCE",
                "confidence": 0.95,
                "triggering_factors": ["Historical pattern retrieval across fenar/5g_netops corpus"]
            }
        elif direct_metrics:
            active_telemetry = dict(direct_metrics)
            risk_info = self.risk_analyst.analyze_risk(active_telemetry)
            incident_info = IncidentClassifierAgent.classify(
                query=sanitized_query,
                parsed_conditions=parsed_conditions,
                telemetry=active_telemetry
            )
            incident_info["severity"] = risk_info["level"]
        elif "nominal_operations" in parsed_conditions.get("conditions", []):
            active_telemetry = {
                "cell_availability": 99.6,
                "throughput": 750.0,
                "latency": 22.0,
                "packet_loss_rate": 0.4,
                "call_drop_rate": 0.05,
                "handover_success_rate": 98.8,
                "critical_alarm_count": 0,
                "alarm_count": 1,
                "signal_strength": -74.0,
                "fault_occurrence_rate": 2.0
            }
            risk_info = self.risk_analyst.analyze_risk(active_telemetry)
            incident_info = IncidentClassifierAgent.classify(
                query=sanitized_query,
                parsed_conditions=parsed_conditions,
                telemetry=active_telemetry
            )
            incident_info["severity"] = risk_info["level"]
        elif similar_cases:
            weights = [max(0.1, c.get("rerank_score", c.get("similarity_score", 0.5))) for c in similar_cases]
            w_sum = sum(weights)
            active_telemetry = {}
            k_list = ["cell_availability", "throughput", "latency", "packet_loss_rate",
                      "call_drop_rate", "handover_success_rate", "critical_alarm_count",
                      "alarm_count", "signal_strength", "fault_occurrence_rate"]
            for k in k_list:
                vals = [c.get("metrics", {}).get(k, 0.0) for c in similar_cases]
                active_telemetry[k] = round(sum(w * v for w, v in zip(weights, vals)) / w_sum, 2)
            
            p_metrics = parsed_conditions.get("metrics", {})
            for k, v_info in p_metrics.items():
                if isinstance(v_info, dict) and v_info.get("is_explicit") and "val" in v_info:
                    active_telemetry[k] = v_info["val"]

            risk_info = self.risk_analyst.analyze_risk(active_telemetry)
            incident_info = IncidentClassifierAgent.classify(
                query=sanitized_query,
                parsed_conditions=parsed_conditions,
                telemetry=active_telemetry
            )
            incident_info["severity"] = risk_info["level"]
        elif parsed_conditions.get("metrics") and any(v.get("is_explicit") for v in parsed_conditions.get("metrics", {}).values() if isinstance(v, dict)):
            p_metrics = parsed_conditions.get("metrics", {})
            active_telemetry = {
                "cell_availability": p_metrics.get("cell_availability", {}).get("val", 98.0),
                "throughput": p_metrics.get("throughput", {}).get("val", 500.0),
                "latency": p_metrics.get("latency", {}).get("val", 45.0),
                "packet_loss_rate": p_metrics.get("packet_loss_rate", {}).get("val", 1.5),
                "call_drop_rate": p_metrics.get("call_drop_rate", {}).get("val", 0.5),
                "handover_success_rate": p_metrics.get("handover_success_rate", {}).get("val", 96.0),
                "critical_alarm_count": p_metrics.get("critical_alarm_count", {}).get("val", 1),
                "alarm_count": p_metrics.get("alarm_count", {}).get("val", 3),
                "signal_strength": p_metrics.get("signal_strength", {}).get("val", -85.0),
                "fault_occurrence_rate": p_metrics.get("fault_occurrence_rate", {}).get("val", 10.0)
            }
            risk_info = self.risk_analyst.analyze_risk(active_telemetry)
            incident_info = IncidentClassifierAgent.classify(
                query=sanitized_query,
                parsed_conditions=parsed_conditions,
                telemetry=active_telemetry
            )
            incident_info["severity"] = risk_info["level"]
        else:
            active_telemetry = None
            risk_info = {
                "score": 0,
                "level": "INSUFFICIENT_EVIDENCE",
                "factors": ["Insufficient operational evidence to calculate deterministic network risk"],
                "risk_factors": []
            }
            incident_info = {
                "incident_type": "Unknown",
                "severity": "INSUFFICIENT_EVIDENCE",
                "confidence": 0.50,
                "triggering_factors": ["Insufficient operational evidence"]
            }

        agent_trace.append({
            "step": 3,
            "agent": "IncidentClassifierAgent",
            "action": "Classification & Severity Mapping",
            "inputs_summary": f"Telemetry={bool(active_telemetry)}, Query={sanitized_query[:60]}",
            "output_summary": f"Classified as '{incident_info['incident_type']}' (Severity: {incident_info['severity']}, Conf: {incident_info['confidence']})",
            "latency_seconds": round(time.time() - t_synth_tel, 3)
        })

        # 4. Risk Analyst Agent: 60/40 Deterministic & ML Blended Scoring
        agent_trace.append({
            "step": 4,
            "agent": "RiskAnalystAgent",
            "action": "60/40 Deterministic + ML Operational Risk Fusion",
            "inputs_summary": f"Observed telemetry parameters ({len(active_telemetry or {})})",
            "output_summary": f"Blended Score={risk_info['score']} ({risk_info['level']}), det={risk_info.get('deterministic_score')}, ml={risk_info.get('ml_risk_score')}",
            "latency_seconds": 0.005
        })

        # 5. Network Analyst Agent & Network Impact Analysis
        t_net = time.time()
        network_analysis = NetworkAnalystAgent.analyze_network_condition(
            parsed_conditions=parsed_conditions,
            retrieved_cases=similar_cases,
            direct_metrics=active_telemetry or {}
        )
        impact_analysis = network_analysis["impact_analysis"]
        agent_trace.append({
            "step": 5,
            "agent": "NetworkAnalystAgent",
            "action": "Deterministic Network & Impact Analysis",
            "inputs_summary": f"Active metrics ({len(active_telemetry or {})}) + {len(similar_cases)} precedents",
            "output_summary": f"Impact Score={impact_analysis['impact_score']}, {len(impact_analysis.get('affected_sectors', []))} sector(s), MTTR={impact_analysis.get('estimated_mttr_hours')}h",
            "latency_seconds": round(time.time() - t_net, 3)
        })

        # 6. Root Cause Analyst Agent
        t_rc = time.time()
        root_causes = RootCauseAnalystAgent.analyze_root_causes(
            telemetry=active_telemetry or {},
            historical_cases=similar_cases,
            conditions=parsed_conditions.get("conditions", [])
        )
        agent_trace.append({
            "step": 6,
            "agent": "RootCauseAnalystAgent",
            "action": "Historical Precedent Evidence Root Cause Identification",
            "inputs_summary": f"{len(similar_cases)} historical cases analyzed for causal patterns",
            "output_summary": f"Identified {len(root_causes)} probable root cause(s): {[rc['root_cause'] for rc in root_causes[:2]]}",
            "latency_seconds": round(time.time() - t_rc, 3)
        })

        # 7. ML Performance Prediction
        t_pred = time.time()
        predictions = self.performance_service.predict_performance(active_telemetry or {})
        agent_trace.append({
            "step": 7,
            "agent": "PerformancePredictionService",
            "action": "Random Forest Multi-KPI Projection",
            "inputs_summary": f"Feature vector from active telemetry",
            "output_summary": f"Projected fault_rate={predictions.get('predicted_fault_occurrence_rate')}%, conf={predictions.get('confidence')}",
            "latency_seconds": round(time.time() - t_pred, 3)
        })

        # 8. Troubleshooting Recommendation Engine
        t_rec = time.time()
        recommendations = RecommendationEngineAgent.generate_recommendations(
            root_causes=root_causes,
            historical_cases=similar_cases,
            telemetry=active_telemetry or {},
            incident_type=incident_info["incident_type"]
        )
        agent_trace.append({
            "step": 8,
            "agent": "RecommendationEngineAgent",
            "action": "Engineering SOP & Heuristic Remediation Derivation",
            "inputs_summary": f"Root causes ({len(root_causes)}), Incident type: {incident_info['incident_type']}",
            "output_summary": f"Generated {len(recommendations)} actionable engineering recommendation(s)",
            "latency_seconds": round(time.time() - t_rec, 3)
        })

        # 9. LLM Response Synthesis Agent
        t_synth_start = time.time()
        diagnosis = LLMSynthesizerAgent.synthesize_diagnosis(
            query=sanitized_query,
            incident=incident_info,
            risk=risk_info,
            root_causes=root_causes,
            similar_cases=similar_cases,
            recommendations=recommendations,
            network_impact=impact_analysis
        )
        llm_latency = round(time.time() - t_synth_start, 3)
        agent_trace.append({
            "step": 9,
            "agent": "LLMSynthesizerAgent",
            "action": "Multi-Agent Synthesis & Natural Language Diagnosis",
            "inputs_summary": f"Aggregated outputs from 8 preceding agent stages",
            "output_summary": f"Generated grounded diagnosis ({len(diagnosis)} chars)",
            "latency_seconds": llm_latency
        })

        # 10. Judge Agent: Grounding & Evaluation
        t_judge_start = time.time()
        evaluation = JudgeAgent.evaluate(
            query=sanitized_query,
            diagnosis=diagnosis,
            retrieved_cases=similar_cases,
            recommendations=recommendations,
            incident=incident_info,
            network_analysis=network_analysis,
            risk=risk_info,
            root_causes=root_causes,
            network_impact=impact_analysis,
            active_telemetry=active_telemetry
        )
        judge_latency = round(time.time() - t_judge_start, 3)
        agent_trace.append({
            "step": 10,
            "agent": "JudgeAgent",
            "action": "LLM-as-a-Judge & Grounding Audit",
            "inputs_summary": f"Diagnosis, {len(similar_cases)} retrieved cases, telemetry numbers",
            "output_summary": f"Decision={evaluation['decision']}, overall={evaluation['overall_score']}, faithfulness={evaluation['faithfulness']}",
            "latency_seconds": judge_latency
        })

        total_latency = round(time.time() - start_time, 3)

        # Record observability telemetry
        try:
            from src.monitoring.telemetry import log_structured_event, record_request_metrics
            record_request_metrics(
                endpoint="/api/v1/query",
                status="success",
                total_latency=total_latency,
                retrieval_latency=retrieval_latency,
                llm_latency=llm_latency,
                eval_score=evaluation.get("overall_score")
            )
            log_structured_event(
                event_type="investigation_completed",
                request_id=f"REQ-{int(start_time * 1000)}",
                endpoint="/api/v1/query",
                latency_breakdown={
                    "total": total_latency,
                    "retrieval": retrieval_latency,
                    "llm": llm_latency,
                    "judge": judge_latency
                },
                metadata={
                    "incident_type": incident_info["incident_type"],
                    "risk_score": risk_info["score"],
                    "decision": evaluation.get("decision", "PASS"),
                    "evaluator_type": evaluation.get("evaluator_type", "deterministic")
                }
            )
        except Exception as e:
            logger.debug("Telemetry logging skipped: %s", e)

        response = {
            "success": True,
            "query": sanitized_query,
            "incident": {
                "type": incident_info["incident_type"],
                "severity": incident_info["severity"],
                "confidence": incident_info["confidence"],
                "triggering_factors": incident_info["triggering_factors"]
            },
            "risk": {
                "score": risk_info["score"],
                "level": risk_info["level"],
                "deterministic_score": risk_info.get("deterministic_score", risk_info["score"]),
                "ml_risk_score": risk_info.get("ml_risk_score", risk_info["score"]),
                "blend_weights": risk_info.get("blend_weights", {"deterministic": 0.60, "ml": 0.40}),
                "factors": risk_info["factors"],
                "risk_factors": risk_info.get("risk_factors", []),
                "top_risk_factors": risk_info.get("top_risk_factors", []),
                "per_prediction_explanation": risk_info.get("per_prediction_explanation", [])
            },
            "network_analysis": {
                "summary": network_analysis["summary"],
                "anomalies": network_analysis["anomalies"],
                "affected_metrics": network_analysis["affected_metrics"],
                "current_metrics": network_analysis["current_metrics"]
            },
            "network_impact": impact_analysis,
            "root_causes": root_causes,
            "similar_cases": similar_cases,
            "recommendations": recommendations,
            "prediction": predictions,
            "ml_risk_score": risk_info.get("ml_risk_score", risk_info["score"]),
            "agent_trace": agent_trace,
            "diagnosis": diagnosis,
            "evaluation": evaluation,
            "metadata": {
                "total_latency_seconds": total_latency,
                "retrieval_latency_seconds": retrieval_latency,
                "llm_latency_seconds": llm_latency,
                "judge_latency_seconds": judge_latency,
                "cases_retrieved": len(similar_cases),
                "demo_mode": settings.DEMO_MODE,
                "llm_provider": settings.LLM_PROVIDER
            }
        }
        return response

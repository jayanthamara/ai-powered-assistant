"""
Copilot Intent Router for NETPULSE AI.
Classifies user messages into telecom-specialized intents, performs strict scope checking,
and routes to the appropriate workflow before any retrieval or diagnostic analysis occurs.
"""
import re
from typing import Dict, Any, Optional, Tuple, Set
from pydantic import BaseModel, Field

from src.guardrails.prompt_injection import check_prompt_injection

# Standard 14 Copilot Intents
INTENT_GREETING = "GREETING"
INTENT_CAPABILITIES = "CAPABILITIES"
INTENT_TELECOM_CONCEPT = "TELECOM_CONCEPT"
INTENT_INCIDENT_INVESTIGATION = "INCIDENT_INVESTIGATION"
INTENT_HISTORICAL_SEARCH = "HISTORICAL_SEARCH"
INTENT_RISK_ANALYSIS = "RISK_ANALYSIS"
INTENT_ROOT_CAUSE_ANALYSIS = "ROOT_CAUSE_ANALYSIS"
INTENT_NETWORK_IMPACT = "NETWORK_IMPACT"
INTENT_PERFORMANCE_PREDICTION = "PERFORMANCE_PREDICTION"
INTENT_RECOMMENDATION = "RECOMMENDATION"
INTENT_FOLLOW_UP = "FOLLOW_UP"
INTENT_DATASET_QUERY = "DATASET_QUERY"
INTENT_OUT_OF_SCOPE = "OUT_OF_SCOPE"
INTENT_CLARIFICATION_REQUIRED = "CLARIFICATION_REQUIRED"

ALL_INTENTS = [
    INTENT_GREETING,
    INTENT_CAPABILITIES,
    INTENT_TELECOM_CONCEPT,
    INTENT_INCIDENT_INVESTIGATION,
    INTENT_HISTORICAL_SEARCH,
    INTENT_RISK_ANALYSIS,
    INTENT_ROOT_CAUSE_ANALYSIS,
    INTENT_NETWORK_IMPACT,
    INTENT_PERFORMANCE_PREDICTION,
    INTENT_RECOMMENDATION,
    INTENT_FOLLOW_UP,
    INTENT_DATASET_QUERY,
    INTENT_OUT_OF_SCOPE,
    INTENT_CLARIFICATION_REQUIRED
]

class CopilotRoutingResult(BaseModel):
    intent: str
    scope: str  # "IN_SCOPE" or "OUT_OF_SCOPE"
    confidence: float
    requires_network_analysis: bool = False
    requires_retrieval: bool = False
    requires_current_investigation_context: bool = False
    clarification_prompt: Optional[str] = None


# Core telecom technical terminology
TELECOM_CORE_TERMS: Set[str] = {
    "packet loss", "latency", "mttr", "call drop", "call drop rate", "call drops",
    "handover", "handover success", "handover success rate", "ran", "congestion",
    "ran congestion", "cell congestion", "signal strength", "throughput", "bandwidth",
    "jitter", "cell availability", "availability", "critical alarm", "critical alarms",
    "alarm", "alarms", "authentication failure", "authentication failures", "outage",
    "cell outage", "rsrp", "rsrq", "rssi", "sinr", "dbm", "gnb", "enb", "gnodeb",
    "enodeb", "5g", "4g", "lte", "subcarrier", "backhaul", "uplink", "downlink",
    "beamforming", "mimo", "rf", "radio frequency", "sector", "cell", "cells", "tower",
    "antenna", "telecom", "telecoms", "telephony", "qos", "qoe", "carrier", "spectrum",
    "fault occurrence", "cell load index", "netpulse", "noc", "base station"
}

# Environmental terms that only become in-scope when tied to telecom/network performance
ENVIRONMENTAL_TERMS: Set[str] = {
    "monsoon", "weather", "temperature", "humidity", "rain", "storm", "heat",
    "flooding", "fog", "summer", "winter"
}

# Non-telecom general knowledge / creative triggers that indicate out-of-scope questions
OUT_OF_SCOPE_PATTERNS = [
    r"\bcapital of\b",
    r"\bwho is\b",
    r"\bwho was\b",
    r"\bwho won\b",
    r"\bwrite (?:a|me a) poem\b",
    r"\btell (?:me )?a joke\b",
    r"\bquantum physics\b",
    r"\bstock market\b",
    r"\bcricket match\b",
    r"\bfootball\b",
    r"\bphotosynthesis\b",
    r"\brecipe\b",
    r"\bcook\b",
    r"\bweather today\b",
    r"\bweather forecast\b",
    r"\bweather right now\b",
    r"\bmovie\b",
    r"\bsong\b",
    r"\bcelebrity\b",
    r"\bpresident\b",
    r"\bprime minister\b"
]


class CopilotIntentRouter:
    """
    Intelligent routing and scope determination layer for NETPULSE AI Copilot.
    Guarantees that general-knowledge questions are rejected before triggering RAG or ML models.
    """

    @classmethod
    def route(
        cls,
        query: str,
        active_context: Optional[Dict[str, Any]] = None
    ) -> CopilotRoutingResult:
        if not query or not query.strip():
            return CopilotRoutingResult(
                intent=INTENT_CLARIFICATION_REQUIRED,
                scope="IN_SCOPE",
                confidence=0.30,
                clarification_prompt="Please ask a telecom question or describe a network incident to investigate."
            )

        q = query.strip()
        q_lower = q.lower().strip("?!.,; ")

        # 1. Prompt Injection Check
        is_inj, _ = check_prompt_injection(q)
        if is_inj:
            return CopilotRoutingResult(
                intent=INTENT_OUT_OF_SCOPE,
                scope="OUT_OF_SCOPE",
                confidence=0.99
            )

        # 2. Greetings & Polite Interaction
        if cls._is_greeting(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_GREETING,
                scope="IN_SCOPE",
                confidence=0.98,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=False
            )

        # 3. Capability Questions
        if cls._is_capability_query(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_CAPABILITIES,
                scope="IN_SCOPE",
                confidence=0.98,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=False
            )

        # 4. Active Investigation Follow-up Context Checks
        has_active_context = bool(active_context and active_context.get("investigation_id"))
        if has_active_context and cls._is_follow_up(q_lower, active_context):
            return cls._route_follow_up(q_lower, active_context)

        # 5. Out-of-Scope Checks (MANDATORY BEFORE ANY NETWORK ANALYSIS OR RAG)
        # Check explicit non-telecom triggers (poems, jokes, capital of france, etc.)
        for pattern in OUT_OF_SCOPE_PATTERNS:
            if re.search(pattern, q_lower):
                return CopilotRoutingResult(
                    intent=INTENT_OUT_OF_SCOPE,
                    scope="OUT_OF_SCOPE",
                    confidence=0.98,
                    requires_network_analysis=False,
                    requires_retrieval=False,
                    requires_current_investigation_context=False
                )

        # Environmental/general queries check
        # E.g., "what is monsoon", "what is temperature", "tell me about monsoon"
        is_env_only, is_env_telecom = cls._check_environmental_scope(q_lower)
        if is_env_only:
            return CopilotRoutingResult(
                intent=INTENT_OUT_OF_SCOPE,
                scope="OUT_OF_SCOPE",
                confidence=0.98,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=False
            )

        if is_env_telecom:
            return CopilotRoutingResult(
                intent=INTENT_TELECOM_CONCEPT,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=False
            )

        # 6. Specific Telecom Concept Question Check
        if cls._is_telecom_concept(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_TELECOM_CONCEPT,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=False
            )

        # 7. Check for Low Confidence / Ambiguity requiring clarification
        if cls._is_ambiguous(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_CLARIFICATION_REQUIRED,
                scope="IN_SCOPE",
                confidence=0.45,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=False,
                clarification_prompt="Could you tell me what network issue you're seeing? For example, high latency, packet loss, call drops, poor signal, alarms, reduced throughput, or handover degradation."
            )

        # 8. Check for Telecom Historical Search
        if cls._is_historical_search(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_HISTORICAL_SEARCH,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=True,
                requires_current_investigation_context=False
            )

        # 9. Check for Risk Analysis Query
        if cls._is_risk_query(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_RISK_ANALYSIS,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=has_active_context
            )

        # 10. Check for Root Cause Query
        if cls._is_root_cause_query(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_ROOT_CAUSE_ANALYSIS,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=has_active_context
            )

        # 11. Check for Network Impact Query
        if cls._is_impact_query(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_NETWORK_IMPACT,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=has_active_context
            )

        # 12. Check for KPI Performance Prediction Query
        if cls._is_prediction_query(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_PERFORMANCE_PREDICTION,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=has_active_context
            )

        # 13. Check for Recommendation Query
        if cls._is_recommendation_query(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_RECOMMENDATION,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=has_active_context
            )

        # 14. Check for Dataset / Corpus Statistics Query
        if cls._is_dataset_query(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_DATASET_QUERY,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=False
            )

        # 15. Check for Incident Investigation
        if cls._is_incident_investigation(q_lower):
            return CopilotRoutingResult(
                intent=INTENT_INCIDENT_INVESTIGATION,
                scope="IN_SCOPE",
                confidence=0.95,
                requires_network_analysis=True,
                requires_retrieval=True,
                requires_current_investigation_context=False
            )

        # 16. Fallback Scope Evaluation:
        # If no telecom terms are present at all in the query, classify as OUT_OF_SCOPE!
        telecom_matches = [t for t in TELECOM_CORE_TERMS if t in q_lower]
        if not telecom_matches:
            return CopilotRoutingResult(
                intent=INTENT_OUT_OF_SCOPE,
                scope="OUT_OF_SCOPE",
                confidence=0.95,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=False
            )

        # Has telecom terms but intent is slightly ambiguous:
        # If asking to triage/diagnose with telecom terms -> INCIDENT_INVESTIGATION
        if any(w in q_lower for w in ["why", "how", "what", "investigate", "analyze", "issue", "problem", "degradation", "spike"]):
            return CopilotRoutingResult(
                intent=INTENT_INCIDENT_INVESTIGATION,
                scope="IN_SCOPE",
                confidence=0.85,
                requires_network_analysis=True,
                requires_retrieval=True,
                requires_current_investigation_context=False
            )

        # Low confidence fallback
        return CopilotRoutingResult(
            intent=INTENT_CLARIFICATION_REQUIRED,
            scope="IN_SCOPE",
            confidence=0.48,
            clarification_prompt="Could you tell me what network issue you're seeing? For example, high latency, packet loss, call drops, poor signal, alarms, reduced throughput, or handover degradation."
        )

    # -------------------------------------------------------------
    # Helper Matchers
    # -------------------------------------------------------------

    @staticmethod
    def _is_greeting(q: str) -> bool:
        greetings = {
            "hi", "hello", "hey", "good morning", "good evening", "good afternoon",
            "greetings", "thanks", "thank you", "thx", "appreciate it", "howdy", "sup"
        }
        if q in greetings:
            return True
        tokens = q.split()
        if len(tokens) <= 3 and any(t in greetings for t in tokens):
            return True
        return False

    @staticmethod
    def _is_capability_query(q: str) -> bool:
        cap_phrases = [
            "what can you do", "what are your capabilities", "how can you help",
            "what does netpulse ai do", "what does netpulse do", "capabilities",
            "who are you", "what is netpulse ai", "what is netpulse",
            "what features", "what can netpulse do", "help me understand what you can do"
        ]
        return any(p in q for p in cap_phrases)

    @classmethod
    def _check_environmental_scope(cls, q: str) -> Tuple[bool, bool]:
        """
        Determines if an environmental query is general (OUT_OF_SCOPE) or telecom-connected (IN_SCOPE).
        Returns (is_environmental_only, is_environmental_with_telecom).
        """
        env_matched = [e for e in ENVIRONMENTAL_TERMS if e in q]
        if not env_matched:
            return False, False

        telecom_matched = [t for t in TELECOM_CORE_TERMS if t in q]
        operational_signals = ["affect", "impact", "degrade", "performance", "signal", "tower", "network", "telecom", "propagation", "attenuation", "rf", "fade"]
        op_matched = [w for w in operational_signals if w in q]

        # Has environmental term AND either explicit telecom term or operational impact term
        if telecom_matched or (len(op_matched) >= 2) or (op_matched and "network" in q) or (op_matched and "telecom" in q):
            return False, True

        # Pure environmental question (e.g. "what is monsoon", "what is temperature", "monsoon conditions in india")
        return True, False

    @staticmethod
    def _is_telecom_concept(q: str) -> bool:
        # Check standard question pattern: "what is <term>", "define <term>", "explain <term>"
        concept_starters = ["what is", "what are", "define", "explain", "meaning of", "what does", "how does", "tell me about"]
        has_starter = any(q.startswith(s) or f" {s} " in q for s in concept_starters)

        for term in TELECOM_CORE_TERMS:
            if term in q:
                if has_starter and not any(k in q for k in ["in hyderabad", "in mumbai", "in delhi", "in bengaluru", "investigate", "diagnose", "recent case", "my network", "this incident"]):
                    return True
                if q == f"what is {term}" or q == f"what are {term}" or q == f"define {term}" or q == f"explain {term}":
                    return True

        return False

    @staticmethod
    def _is_ambiguous(q: str) -> bool:
        vague_phrases = [
            "things look bad", "it's broken", "its broken", "something is wrong",
            "having an issue", "help me fix", "network problem", "look at this",
            "check this", "bad connection", "issues happening", "cells look bad"
        ]
        if q in vague_phrases:
            return True
        if len(q.split()) <= 3 and any(w in q for w in ["bad", "broken", "issue", "problem", "down"]) and not any(t in q for t in TELECOM_CORE_TERMS):
            return True
        return False

    @staticmethod
    def _is_follow_up(q: str, context: Dict[str, Any]) -> bool:
        follow_up_cues = [
            "the root cause", "root cause", "risk score", "the risk", "why is the risk",
            "why is net-", "why is case-", "similar case", "similar incident", "why is this similar",
            "why similar", "what should i do", "what did you recommend", "recommendation",
            "recommended action", "tell me more about", "why do you think", "why did you",
            "show similar cases", "show me similar cases", "show cases"
        ]
        if any(c in q for c in follow_up_cues):
            return True

        # Check references to cases present in active context
        similar_cases = context.get("similar_cases", [])
        for c in similar_cases:
            case_id = c.get("incident_id", "").lower()
            if case_id and case_id in q:
                return True

        return False

    @classmethod
    def _route_follow_up(cls, q: str, context: Dict[str, Any]) -> CopilotRoutingResult:
        """
        Determines the specific follow-up sub-intent using current investigation context.
        """
        if any(w in q for w in ["risk", "risk score", "risk level"]):
            return CopilotRoutingResult(
                intent=INTENT_FOLLOW_UP,
                scope="IN_SCOPE",
                confidence=0.96,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=True
            )

        if any(w in q for w in ["similar", "cases", "incident id", "net-", "precedent"]):
            return CopilotRoutingResult(
                intent=INTENT_FOLLOW_UP,
                scope="IN_SCOPE",
                confidence=0.96,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=True
            )

        if any(w in q for w in ["action", "recommend", "should i do", "fix", "mitigate"]):
            return CopilotRoutingResult(
                intent=INTENT_FOLLOW_UP,
                scope="IN_SCOPE",
                confidence=0.96,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=True
            )

        if any(w in q for w in ["root cause", "congestion", "cause", "why do you think"]):
            return CopilotRoutingResult(
                intent=INTENT_FOLLOW_UP,
                scope="IN_SCOPE",
                confidence=0.96,
                requires_network_analysis=False,
                requires_retrieval=False,
                requires_current_investigation_context=True
            )

        return CopilotRoutingResult(
            intent=INTENT_FOLLOW_UP,
            scope="IN_SCOPE",
            confidence=0.92,
            requires_network_analysis=False,
            requires_retrieval=False,
            requires_current_investigation_context=True
        )

    @staticmethod
    def _is_historical_search(q: str) -> bool:
        search_triggers = [
            "find similar", "show similar", "search similar", "find historical",
            "show historical", "search historical", "previous incidents", "past incidents",
            "historical cases", "similar cases", "similar incidents", "find cases",
            "retrieve cases", "precedents"
        ]
        return any(t in q for t in search_triggers)

    @staticmethod
    def _is_risk_query(q: str) -> bool:
        risk_triggers = [
            "what is the risk", "what is the fault risk", "calculate risk",
            "assess risk", "risk score", "which cells are high risk",
            "risk analysis", "network fault risk", "why is the risk high",
            "fault risk"
        ]
        return any(t in q for t in risk_triggers)

    @staticmethod
    def _is_root_cause_query(q: str) -> bool:
        rca_triggers = [
            "what is the root cause", "identify root cause", "probable cause",
            "why is latency increasing", "why is packet loss happening",
            "why is this incident occurring", "explain the root cause",
            "root cause analysis", "rca"
        ]
        return any(t in q for t in rca_triggers)

    @staticmethod
    def _is_impact_query(q: str) -> bool:
        impact_triggers = [
            "what is the network impact", "assess customer impact", "service impact",
            "affected users", "affected services", "how serious is this",
            "impact score", "blast radius"
        ]
        return any(t in q for t in impact_triggers)

    @staticmethod
    def _is_prediction_query(q: str) -> bool:
        pred_triggers = [
            "predict throughput", "predict latency", "predict packet loss",
            "predict performance", "performance prediction", "forecast performance",
            "predict fault"
        ]
        return any(t in q for t in pred_triggers)

    @staticmethod
    def _is_recommendation_query(q: str) -> bool:
        rec_triggers = [
            "recommend corrective", "what should i do", "what should the noc team",
            "how can i fix", "troubleshooting recommendations", "action plan",
            "what actions should be taken", "mitigation steps", "recommend actions"
        ]
        return any(t in q for t in rec_triggers)

    @staticmethod
    def _is_dataset_query(q: str) -> bool:
        ds_triggers = [
            "how many incidents", "how many records", "which cities are in",
            "dataset statistics", "corpus size", "how many cells", "dataset info"
        ]
        return any(t in q for t in ds_triggers)

    @staticmethod
    def _is_incident_investigation(q: str) -> bool:
        investigation_triggers = [
            "investigate", "analyze this", "diagnose", "triage",
            "why is latency high", "high latency and packet loss",
            "declining handover", "high call drop", "multiple cells",
            "experiencing high latency", "network degradation",
            "cell outage", "critical alarms"
        ]
        has_trigger = any(t in q for t in investigation_triggers)
        has_telecom_term = any(t in q for t in TELECOM_CORE_TERMS)
        return has_trigger and has_telecom_term

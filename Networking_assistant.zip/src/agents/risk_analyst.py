"""
Risk Analyst Agent for NETPULSE AI.
Fuses deterministic prioritization severity scoring with trained Random Forest risk predictions.
"""
from typing import Dict, Any, List
from src.analytics.prioritization import calculate_deterministic_prioritization
from src.ml.risk_model import MLRiskService

class RiskAnalystAgent:
    def __init__(self, ml_risk_service: MLRiskService):
        self.ml_risk = ml_risk_service

    def analyze_risk(self, telemetry: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculates unified operational risk score, risk level, and explainable factors.
        Blends deterministic severity scoring (60%) with trained Random Forest risk predictions (40%).
        """
        # 1. Deterministic prioritization & transparent contribution scoring
        det_res = calculate_deterministic_prioritization(telemetry)
        det_score = det_res["risk_score"]

        # 2. ML Random Forest Risk prediction
        ml_res = self.ml_risk.predict_risk(telemetry)
        ml_score = ml_res.get("risk_score", det_score)

        # 3. Documented 60/40 Blended Risk
        blended_score = int(round(0.60 * det_score + 0.40 * ml_score))

        # Severity cutoffs (calibrated to fenar/5g_netops):
        # LOW (<=20), MEDIUM (21-35), HIGH (36-53), CRITICAL (54+)
        if blended_score >= 54:
            level = "CRITICAL"
        elif blended_score >= 36:
            level = "HIGH"
        elif blended_score >= 21:
            level = "MEDIUM"
        else:
            level = "LOW"

        # Merge factor descriptions
        factors = list(det_res["factors"])
        for rf in ml_res.get("top_risk_factors", []):
            factors.append(f"ML Feature Impact: {rf['feature']} ({int(rf['impact']*100)}%)")

        return {
            "score": blended_score,
            "level": level,
            "risk_score": blended_score,
            "risk_level": level,
            "blend_weights": {"deterministic": 0.60, "ml": 0.40},
            "deterministic_score": det_score,
            "deterministic_level": det_res["severity"],
            "ml_risk_score": ml_score,
            "ml_risk_level": ml_res.get("risk_level", level),
            "factors": factors[:5],
            "risk_factors": det_res.get("risk_factors", []),
            "top_risk_factors": ml_res.get("top_risk_factors", []),
            "per_prediction_explanation": ml_res.get("per_prediction_explanation", [])
        }

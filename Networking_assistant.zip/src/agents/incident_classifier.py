"""
Incident Classification Agent for NETPULSE AI.
Classifies telecom incidents across 14 categories using data-driven telemetry thresholds
and semantic natural-language intent with empirical confidence scoring.
"""
from typing import Dict, Any, List, Optional
import numpy as np
from src.analytics.thresholds import load_thresholds

VALID_CATEGORIES = [
    "Nominal Operations",
    "Congestion",
    "High Latency",
    "Packet Loss",
    "Poor Signal Quality",
    "Dropped Calls",
    "Handover Failure",
    "Service Degradation",
    "Network Fault",
    "Security Incident",
    "Authentication Failure",
    "Configuration Issue",
    "Availability Issue",
    "Multi-factor / Compound Incident",
    "Unknown"
]

class IncidentClassifierAgent:
    @staticmethod
    def classify(
        query: str,
        parsed_conditions: Dict[str, Any],
        telemetry: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Synthesizes structured metrics and query semantics to classify incident type and severity.
        Confidence is dynamically computed from supporting telemetry evidence and semantic match strength.
        """
        q_lower = query.lower()
        conditions = parsed_conditions.get("conditions", [])
        metrics = telemetry or {}
        triggering_factors = []

        # Count symptomatic flags
        flags = set(conditions)

        # Load data-driven thresholds
        thresh = load_thresholds().get("kpis", {})
        lat_p75 = thresh.get("latency", {}).get("p75", 105.0)
        loss_p75 = thresh.get("packet_loss_rate", {}).get("p75", 9.4)
        tp_p25 = thresh.get("throughput", {}).get("p25", 392.0)
        cdr_p75 = thresh.get("call_drop_rate", {}).get("p75", 1.7)
        hosr_p25 = thresh.get("handover_success_rate", {}).get("p25", 92.5)
        avail_p25 = thresh.get("cell_availability", {}).get("p25", 83.4)
        crit_p75 = thresh.get("critical_alarm_count", {}).get("p75", 8.4)
        ss_p25 = thresh.get("signal_strength", {}).get("p25", -105.6)

        lat = metrics.get("latency")
        loss = metrics.get("packet_loss_rate")
        tp = metrics.get("throughput")
        cdr = metrics.get("call_drop_rate")
        hosr = metrics.get("handover_success_rate")
        avail = metrics.get("cell_availability")
        crit_alarms = metrics.get("critical_alarm_count")
        ss = metrics.get("signal_strength")
        sec = metrics.get("security_incidents", 0)
        auth_fail = metrics.get("authentication_failures", 0)

        # Evaluate conditions against empirical thresholds
        if lat is not None and lat >= lat_p75:
            flags.add("high_latency")
        if loss is not None and loss >= loss_p75:
            flags.add("high_packet_loss")
        if tp is not None and tp <= tp_p25:
            flags.add("low_throughput")
        if cdr is not None and cdr >= cdr_p75:
            flags.add("high_call_drop")
        if hosr is not None and hosr <= hosr_p25:
            flags.add("low_handover_success")
        if avail is not None and avail <= avail_p25:
            flags.add("availability_issue")
        if crit_alarms is not None and crit_alarms >= crit_p75:
            flags.add("high_alarms")
        if ss is not None and ss <= ss_p25:
            flags.add("poor_signal")
        if (sec is not None and sec >= 2) or (auth_fail is not None and auth_fail >= 10):
            flags.add("security_incident")

        # Determine triggering factors
        if "high_latency" in flags:
            triggering_factors.append(f"Excessive latency ({lat:.1f} ms >= p75 SLA)" if lat is not None else "Reported elevated latency")
        if "high_packet_loss" in flags:
            triggering_factors.append(f"Significant packet drop ({loss:.2f}% >= p75)" if loss is not None else "Reported packet loss rate")
        if "low_throughput" in flags:
            triggering_factors.append(f"Throughput reduction ({tp:.1f} Mbps <= p25)" if tp is not None else "Degraded user plane throughput")
        if "low_handover_success" in flags:
            triggering_factors.append(f"Sub-optimal handover success ({hosr:.1f}% <= p25)" if hosr is not None else "Mobility handover failure")
        if "high_call_drop" in flags:
            triggering_factors.append(f"Elevated call drop rate ({cdr:.2f}% >= p75)" if cdr is not None else "Frequent voice/data session drops")
        if "availability_issue" in flags:
            triggering_factors.append(f"Cell availability degraded ({avail:.1f}% <= p25)" if avail is not None else "Cell site availability impairment")
        if "high_alarms" in flags:
            triggering_factors.append(f"Active critical alarms ({crit_alarms:.1f} >= p75)" if crit_alarms is not None else "Escalated alarm counts")
        if "cell_congestion" in flags:
            triggering_factors.append("Cellular PRB/capacity saturation")
        if "poor_signal" in flags:
            triggering_factors.append(f"Low radio signal strength ({ss:.1f} dBm <= p25)" if ss is not None else "Sub-standard radio coverage")
        if "security_incident" in flags:
            triggering_factors.append("Security telemetry anomaly / authentication failures")

        # Classification decision logic (with Availability Issue reachable)
        text_matches = 0
        telemetry_matches = len(flags)

        if "nominal_operations" in flags:
            incident_type = "Nominal Operations"
            text_matches = 2
        elif len(flags) >= 3:
            incident_type = "Multi-factor / Compound Incident"
            text_matches = len(flags)
        elif "availability_issue" in flags or any(w in q_lower for w in ["availability", "cell down", "cell availability", "outage", "unavailable"]):
            incident_type = "Availability Issue"
            text_matches = 2 if "availability" in q_lower else 1
        elif "security_incident" in flags or "security" in q_lower:
            incident_type = "Security Incident" if (sec and sec > 0) else "Authentication Failure"
            text_matches = 2 if "security" in q_lower else 1
        elif "low_handover_success" in flags or ("handover" in q_lower and not any(g in q_lower for g in ["high handover", "good handover", "normal handover", "optimal handover"])):
            incident_type = "Handover Failure"
            text_matches = 2 if "handover" in q_lower else 1
        elif "cell_congestion" in flags or ("low_throughput" in flags and "latency" not in flags):
            incident_type = "Congestion"
            text_matches = 2 if "congestion" in q_lower else 1
        elif "high_latency" in flags and "high_packet_loss" not in flags:
            incident_type = "High Latency"
            text_matches = 2 if "latency" in q_lower else 1
        elif "high_packet_loss" in flags:
            incident_type = "Packet Loss"
            text_matches = 2 if "packet loss" in q_lower else 1
        elif "poor_signal" in flags:
            incident_type = "Poor Signal Quality"
            text_matches = 2 if "signal" in q_lower else 1
        elif "high_call_drop" in flags:
            incident_type = "Dropped Calls"
            text_matches = 2 if "call drop" in q_lower else 1
        elif "high_alarms" in flags:
            incident_type = "Network Fault"
            text_matches = 2 if "alarm" in q_lower else 1
        elif "configuration" in q_lower or "parameter" in q_lower:
            incident_type = "Configuration Issue"
            text_matches = 2
        elif any(w in q_lower for w in ["quality", "degradation", "poor service", "sluggish"]):
            incident_type = "Service Degradation"
            text_matches = 1
        elif flags:
            incident_type = "Service Degradation"
            text_matches = 1
        else:
            incident_type = "Unknown"
            text_matches = 0

        # Data-derived confidence score:
        # Base confidence (0.65) + bonus for query evidence + bonus for telemetry evidence
        if incident_type == "Unknown":
            confidence = 0.50
        elif incident_type == "Nominal Operations":
            confidence = 0.95
        else:
            base_conf = 0.70
            bonus_text = min(0.15, text_matches * 0.08)
            bonus_telem = min(0.12, telemetry_matches * 0.04)
            confidence = min(0.96, base_conf + bonus_text + bonus_telem)

        # Deterministic severity determination grounded in network evidence
        from src.analytics.prioritization import calculate_deterministic_prioritization
        det_risk = calculate_deterministic_prioritization(metrics)
        severity = det_risk["severity"]

        if not triggering_factors:
            triggering_factors = ["General network performance inquiry"]

        return {
            "incident_type": incident_type,
            "severity": severity,
            "confidence": round(float(confidence), 2),
            "triggering_factors": triggering_factors
        }

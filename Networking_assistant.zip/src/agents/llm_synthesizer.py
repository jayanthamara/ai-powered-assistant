"""
LLM Response Synthesis module for NETPULSE AI.
Supports NVIDIA NIM (primary provider via OpenAI-compatible endpoint),
OpenAI (fallback provider), and zero-crash offline deterministic synthesis.
Strictly separates deterministic calculations from generative reasoning.
"""
import os
import json
import logging
from typing import Dict, Any, List, Optional
import requests
from src.config import settings

logger = logging.getLogger("llm_synthesizer")

class LLMSynthesizerAgent:
    @staticmethod
    def call_llm(prompt: str, system_prompt: str = "", temperature: float = 0.2, max_tokens: int = 500) -> Optional[str]:
        """
        Unified OpenAI-compatible caller for NVIDIA NIM and OpenAI.
        Selects provider according to configured environment variables with graceful fallback.
        """
        # 1. Try NVIDIA NIM if configured
        nvidia_key = settings.NVIDIA_API_KEY or os.environ.get("NVIDIA_API_KEY", "")
        if nvidia_key and settings.LLM_PROVIDER.lower() in ["nvidia", "nim"]:
            try:
                base_url = (settings.NVIDIA_BASE_URL or "https://integrate.api.nvidia.com/v1").rstrip("/")
                headers = {
                    "Authorization": f"Bearer {nvidia_key}",
                    "Content-Type": "application/json"
                }
                payload = {
                    "model": settings.NVIDIA_MODEL or "meta/llama-3.1-70b-instruct",
                    "messages": [
                        {"role": "system", "content": system_prompt or "You are an expert telecom network operations assistant."},
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": temperature,
                    "max_tokens": max_tokens
                }
                resp = requests.post(f"{base_url}/chat/completions", json=payload, headers=headers, timeout=35)
                if resp.status_code == 200:
                    data = resp.json()
                    content = data["choices"][0]["message"]["content"].strip()
                    logger.info("Successfully received synthesis from NVIDIA NIM (%s)", settings.NVIDIA_MODEL)
                    return content
                else:
                    logger.warning("NVIDIA NIM API returned status %d: %s", resp.status_code, resp.text)
            except Exception as e:
                logger.warning("NVIDIA NIM invocation failed (%s). Falling back.", e)

        # 2. Try OpenAI if configured
        openai_key = settings.OPENAI_API_KEY or os.environ.get("OPENAI_API_KEY", "")
        if openai_key and settings.LLM_PROVIDER.lower() in ["openai", "remote", "nvidia"]:
            try:
                base_url = (settings.OPENAI_API_BASE or "https://api.openai.com/v1").rstrip("/")
                headers = {
                    "Authorization": f"Bearer {openai_key}",
                    "Content-Type": "application/json"
                }
                payload = {
                    "model": settings.LLM_MODEL or "gpt-4o-mini",
                    "messages": [
                        {"role": "system", "content": system_prompt or "You are an expert telecom network operations assistant."},
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": temperature,
                    "max_tokens": max_tokens
                }
                resp = requests.post(f"{base_url}/chat/completions", json=payload, headers=headers, timeout=15)
                if resp.status_code == 200:
                    data = resp.json()
                    content = data["choices"][0]["message"]["content"].strip()
                    logger.info("Successfully received synthesis from LLM (%s)", settings.LLM_MODEL)
                    return content
                elif resp.status_code in [503, 429] and "googleapis.com" in base_url:
                    logger.warning("Gemini model %s returned status %d. Retrying with gemini-flash-latest...", settings.LLM_MODEL, resp.status_code)
                    payload["model"] = "gemini-flash-latest"
                    resp_retry = requests.post(f"{base_url}/chat/completions", json=payload, headers=headers, timeout=15)
                    if resp_retry.status_code == 200:
                        data = resp_retry.json()
                        content = data["choices"][0]["message"]["content"].strip()
                        logger.info("Successfully received synthesis from Gemini fallback (gemini-flash-latest)")
                        return content
                    else:
                        logger.warning("Gemini retry returned status %d: %s", resp_retry.status_code, resp_retry.text)
                else:
                    logger.warning("OpenAI API returned status %d: %s", resp.status_code, resp.text)
            except Exception as e:
                logger.warning("OpenAI LLM invocation failed (%s). Falling back.", e)

        return None

    @staticmethod
    def synthesize_diagnosis(
        query: str,
        incident: Dict[str, Any],
        risk: Dict[str, Any],
        root_causes: List[Dict[str, Any]],
        similar_cases: List[Dict[str, Any]],
        recommendations: List[Dict[str, Any]],
        network_impact: Dict[str, Any]
    ) -> str:
        """
        Synthesizes human-readable operational diagnosis grounded strictly in deterministic artifacts.
        Attempts NVIDIA NIM first, then OpenAI, and falls back to deterministic template synthesis in Demo Mode.
        """
        prompt = (
            f"You are the senior diagnostic reasoning engine for NETPULSE AI (Telecom Network Operations).\n"
            f"Query: {query}\n"
            f"Incident Type: {incident.get('incident_type')} (Severity: {incident.get('severity')})\n"
            f"Risk: {risk.get('score', risk.get('risk_score'))}/100 ({risk.get('level', risk.get('risk_level'))})\n"
            f"Network Impact: {network_impact.get('impact_level')} (Region: {network_impact.get('affected_region')})\n"
            f"Top Root Causes: {[rc['root_cause'] for rc in root_causes[:2]]}\n"
            f"Similar Cases: {[c['incident_id'] for c in similar_cases[:2]]}\n"
            f"Top Recommendations: {[r['action'] for r in recommendations[:2]]}\n\n"
            f"Generate a rigorous engineering diagnosis for the telecom network operations center. "
            f"MANDATORY: The operational severity is deterministically calculated as {incident.get('severity')} with Risk Score {risk.get('score', risk.get('risk_score'))}/100 ({risk.get('level', risk.get('risk_level'))}). "
            f"You MUST preserve and explain this deterministic severity without overriding or contradicting it. "
            f"DO NOT invent metrics or historical case IDs outside of what is provided above."
        )
        system_prompt = (
            "You are a telecom network operations diagnostic expert. Ground your reasoning strictly in provided telemetry. "
            "Never override or contradict the calculated operational risk score and severity level."
        )

        llm_response = LLMSynthesizerAgent.call_llm(prompt=prompt, system_prompt=system_prompt, temperature=0.2, max_tokens=400)
        if llm_response and len(llm_response) > 50:
            return llm_response

        # High-Fidelity Deterministic Fallback Synthesis (Guaranteed for Demo Mode)
        return LLMSynthesizerAgent._generate_deterministic_diagnosis(
            query=query,
            incident=incident,
            risk=risk,
            root_causes=root_causes,
            similar_cases=similar_cases,
            recommendations=recommendations,
            network_impact=network_impact
        )

    @staticmethod
    def _generate_deterministic_diagnosis(
        query: str,
        incident: Dict[str, Any],
        risk: Dict[str, Any],
        root_causes: List[Dict[str, Any]],
        similar_cases: List[Dict[str, Any]],
        recommendations: List[Dict[str, Any]],
        network_impact: Dict[str, Any]
    ) -> str:
        inc_type = incident.get("incident_type", "Operational Degradation")
        sev = incident.get("severity", "MEDIUM")
        risk_score = risk.get("score", risk.get("risk_score", 60))
        risk_level = risk.get("level", risk.get("risk_level", "HIGH"))
        region = network_impact.get("affected_region", "Metropolitan RAN cluster")
        impact_level = network_impact.get("impact_level", "HIGH")

        # Top root cause
        top_rc = root_causes[0]["root_cause"] if root_causes else "Radio & transport capacity bottleneck"
        top_rc_ev = ", ".join(root_causes[0].get("evidence", [])) if root_causes else "Telemetry variances"

        # Reference cases
        case_ids = [c["incident_id"] for c in similar_cases[:2] if c.get("incident_id")] if similar_cases else ["Active Cluster Baseline"]
        case_ref_str = " and ".join(case_ids)

        top_rec = recommendations[0]["action"] if recommendations else "Conduct sector parameter audit"

        diagnosis = (
            f"**Operational Assessment**: Incident for '{query}' classified as **{inc_type}** with **{sev}** severity across {region}. "
            f"Operational fault risk is rated at **{risk_score}/100 ({risk_level} RISK)** with **{impact_level}** customer and service impact.\n\n"
            f"**Primary Root Cause**: Analysis indicates **{top_rc}** as the most probable cause. "
            f"Supporting evidence includes: {top_rc_ev}.\n\n"
            f"**Historical Precedent**: Telemetry closely correlates with historical incident records **{case_ref_str}**, "
            f"which manifested matching air-interface and transport degradation patterns under comparable operational loading.\n\n"
            f"**Action Plan**: Priority action is to **{top_rec}** to mitigate service degradation and safeguard SLA compliance."
        )
        return diagnosis

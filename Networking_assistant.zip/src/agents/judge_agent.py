"""
LLM-as-a-Judge and Grounding Evaluation Agent for NETPULSE AI.
Evaluates diagnostic faithfulness, context relevance, answer relevance, completeness,
recommendation quality, diagnosis consistency, hallucination risk, and evidence grounding.
Uses NVIDIA NIM / OpenAI when available, with guaranteed deterministic fallback in Demo Mode.
"""
import os
import re
import json
import logging
from typing import Dict, Any, List, Optional
import requests
from src.config import settings

logger = logging.getLogger("judge_agent")

def np_clip(val: float, min_val: float, max_val: float) -> float:
    return max(min_val, min(max_val, val))

class JudgeAgent:
    @staticmethod
    def evaluate(
        query: str,
        diagnosis: str,
        retrieved_cases: List[Dict[str, Any]],
        recommendations: List[Dict[str, Any]],
        incident: Dict[str, Any],
        network_analysis: Optional[Dict[str, Any]] = None,
        risk: Optional[Dict[str, Any]] = None,
        root_causes: Optional[List[Dict[str, Any]]] = None,
        network_impact: Optional[Dict[str, Any]] = None,
        active_telemetry: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Evaluates diagnostic grounding, relevance, and hallucination risk against ground-truth evidence.
        Executes LLM-as-a-Judge evaluation when LLM provider is active, with seamless deterministic fallback.
        """
        # 1. Deterministic baseline checks (always computed as safety baseline)
        det_eval = JudgeAgent._evaluate_deterministic(
            query=query,
            diagnosis=diagnosis,
            retrieved_cases=retrieved_cases,
            recommendations=recommendations,
            incident=incident,
            root_causes=root_causes,
            active_telemetry=active_telemetry
        )

        # 2. Attempt LLM-as-a-Judge if LLM provider is available
        try:
            from src.agents.llm_synthesizer import LLMSynthesizerAgent
            llm_eval = JudgeAgent._call_llm_judge(
                query=query,
                diagnosis=diagnosis,
                retrieved_cases=retrieved_cases,
                recommendations=recommendations,
                incident=incident,
                network_analysis=network_analysis,
                risk=risk,
                root_causes=root_causes,
                network_impact=network_impact,
                active_telemetry=active_telemetry
            )
            if llm_eval:
                return llm_eval
        except Exception as e:
            logger.info("LLM judge unavailable (%s). Falling back to deterministic evaluation.", e)

        return det_eval

    @staticmethod
    def _evaluate_deterministic(
        query: str,
        diagnosis: str,
        retrieved_cases: List[Dict[str, Any]],
        recommendations: List[Dict[str, Any]],
        incident: Dict[str, Any],
        root_causes: Optional[List[Dict[str, Any]]] = None,
        active_telemetry: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Data-grounded deterministic rubric evaluator with zero arbitrary prior scores."""
        issues: List[str] = []
        diag_lower = diagnosis.lower()
        root_causes = root_causes or []

        # 1. Grounding check: verify that cited case IDs exist in retrieved cases
        # Real IDs in fenar/5g_netops are 5G-NETOPS-#### (with backward support for CASE-/NET-)
        cited_cases = re.findall(r"\b(?:5G-NETOPS|CASE|NET)-\d+\b", diagnosis, re.IGNORECASE)
        retrieved_ids = {str(c.get("incident_id", "")).upper() for c in retrieved_cases}

        grounding_penalty = 0.0
        hallucination_risk = 0.02
        if cited_cases:
            for cid in cited_cases:
                if cid.upper() not in retrieved_ids:
                    issues.append(f"Factual Hallucination: Cited incident '{cid}' was not in retrieved context.")
                    grounding_penalty += 0.25
                    hallucination_risk += 0.35

        # Metric verification: check numeric citations in diagnosis against ground-truth numbers
        known_numbers = set()
        if active_telemetry:
            for v in active_telemetry.values():
                if isinstance(v, (int, float)):
                    known_numbers.add(round(float(v), 1))
        for c in retrieved_cases:
            for v in c.get("metrics", {}).values():
                if isinstance(v, (int, float)):
                    known_numbers.add(round(float(v), 1))

        # Check explicit numeric citations (e.g. 120 ms, 4.2 h, 95.5%)
        cited_numbers = re.findall(r"\b(\d+(?:\.\d+)?)\s*(?:ms|mbps|%|h|hours|dbm)\b", diag_lower)
        unverified_metrics = 0
        if cited_numbers and known_numbers:
            for n_str in cited_numbers:
                n_val = round(float(n_str), 1)
                # Allow tolerance of +/- 1.0 or 10%
                matched = any(abs(n_val - kn) <= max(1.0, kn * 0.10) for kn in known_numbers)
                if not matched and n_val > 0:
                    unverified_metrics += 1
            if unverified_metrics > 0:
                issues.append(f"Metric Grounding: {unverified_metrics} cited numerical value(s) could not be verified in telemetry.")
                grounding_penalty += min(0.30, unverified_metrics * 0.10)
                hallucination_risk += min(0.30, unverified_metrics * 0.10)

        grounding_score = max(0.40, round(1.0 - grounding_penalty, 2))

        # 2. Context relevance check: calculate term and KPI overlap between query and retrieved cases
        if retrieved_cases:
            query_kws = [w for w in re.findall(r"\b[a-z]{4,}\b", query.lower())]
            overlap_count = 0
            for c in retrieved_cases:
                doc_text = str(c.get("document", "")).lower()
                if any(kw in doc_text for kw in query_kws):
                    overlap_count += 1
            context_relevance = round(0.50 + 0.45 * (overlap_count / len(retrieved_cases)), 2)
        else:
            context_relevance = 0.40
            issues.append("Context Relevance: Zero historical incident cases retrieved.")

        # 3. Answer relevance check: verify symptoms in query are directly addressed
        stopwords = {
            "what", "where", "which", "when", "that", "this", "these", "those",
            "have", "were", "been", "from", "with", "into", "some", "more",
            "does", "find", "show", "tell", "cell", "cells", "similar", "historical", "incidents"
        }
        query_words = [w for w in re.findall(r"\b[a-z]{4,}\b", query.lower()) if w not in stopwords]
        matched_words = [w for w in query_words if w in diag_lower]
        coverage = (len(matched_words) / len(query_words)) if query_words else 1.0
        answer_relevance = round(max(0.50, min(0.98, 0.50 + 0.48 * coverage)), 2)
        if coverage < 0.35:
            issues.append("Answer Relevance: Diagnosis omits several key operational symptoms from query.")

        # 4. Recommendation Quality check: verify alignment with root causes and actionable steps
        if not recommendations:
            rec_score = 0.40
            issues.append("Recommendation Quality: No actionable remediation steps were provided.")
        else:
            valid_recs = sum(1 for r in recommendations if r.get("action") and r.get("reason"))
            rec_ratio = valid_recs / len(recommendations)
            rec_score = round(max(0.40, min(0.96, 0.50 + 0.45 * rec_ratio)), 2)

        # 5. Completeness check: check incident type, root cause and impact coverage
        completeness_points = 0.0
        inc_type = incident.get("incident_type", "").lower()
        if inc_type and inc_type in diag_lower:
            completeness_points += 0.35
        elif "incident" in diag_lower:
            completeness_points += 0.20

        if any(str(rc.get("root_cause", "")).lower() in diag_lower for rc in root_causes):
            completeness_points += 0.35
        elif "root cause" in diag_lower:
            completeness_points += 0.20

        if recommendations and len(recommendations) > 0:
            completeness_points += 0.30

        completeness = round(max(0.40, min(0.96, completeness_points)), 2)

        faithfulness = round(float(np_clip(grounding_score, 0.0, 1.0)), 2)
        answer_relevance = round(float(np_clip(answer_relevance, 0.0, 1.0)), 2)
        rec_score = round(float(np_clip(rec_score, 0.0, 1.0)), 2)
        completeness = round(float(np_clip(completeness, 0.0, 1.0)), 2)
        hallucination_risk = round(float(np_clip(hallucination_risk, 0.0, 1.0)), 2)

        overall_score = round(
            0.30 * faithfulness +
            0.20 * context_relevance +
            0.20 * answer_relevance +
            0.15 * rec_score +
            0.15 * completeness, 2
        )

        # Unified single threshold standard across code, prompts, docs:
        # PASS >= 0.80, WARN 0.65 - 0.79, FAIL < 0.65
        decision = "PASS" if overall_score >= 0.80 and hallucination_risk <= 0.15 else ("WARN" if overall_score >= 0.65 else "FAIL")

        return {
            "faithfulness": faithfulness,
            "context_relevance": context_relevance,
            "answer_relevance": answer_relevance,
            "relevance_score": answer_relevance,  # backwards-compatible alias
            "completeness": completeness,
            "recommendation_quality": rec_score,
            "recommendation_score": rec_score,  # backwards-compatible alias
            "grounding_score": faithfulness,
            "hallucination_risk": hallucination_risk,
            "overall_score": overall_score,
            "decision": decision,
            "issues": issues,
            "evaluator_type": "deterministic_rubric"
        }

    @staticmethod
    def _call_llm_judge(
        query: str,
        diagnosis: str,
        retrieved_cases: List[Dict[str, Any]],
        recommendations: List[Dict[str, Any]],
        incident: Dict[str, Any],
        network_analysis: Optional[Dict[str, Any]] = None,
        risk: Optional[Dict[str, Any]] = None,
        root_causes: Optional[List[Dict[str, Any]]] = None,
        network_impact: Optional[Dict[str, Any]] = None,
        active_telemetry: Optional[Dict[str, Any]] = None
    ) -> Optional[Dict[str, Any]]:
        from src.agents.llm_synthesizer import LLMSynthesizerAgent

        # Include rich metric details for retrieved cases, not just IDs
        evidence_summaries = []
        for c in retrieved_cases[:5]:
            cid = c.get("incident_id", "Unknown")
            m = c.get("metrics", {})
            m_str = f"latency={m.get('latency')}ms, throughput={m.get('throughput')}mbps, loss={m.get('packet_loss_rate')}%, avail={m.get('cell_availability')}%, mttr={m.get('mttr')}h"
            evidence_summaries.append(f"{cid}: {m_str}")

        prompt = f"""You are the Telecom Operations LLM-as-a-Judge for NETPULSE AI.
Evaluate the diagnostic answer against ground-truth evidence artifacts from fenar/5g_netops.

[User Query]: {query}
[Classified Incident]: {incident.get('incident_type')} (Severity: {incident.get('severity')})
[Active Telemetry]: {active_telemetry or {}}
[Retrieved Evidence Cases & Recorded Metrics]:
{chr(10).join(evidence_summaries)}
[Root Causes]: {[rc.get('root_cause') for rc in (root_causes or [])[:2]]}
[Recommendations]: {[r.get('action') for r in recommendations[:2]]}
[Synthesized Diagnosis]:
{diagnosis}

Evaluate the response across the following metrics on a 0.0 to 1.0 scale:
- faithfulness: Are all factual claims and numerical metrics supported by the evidence cases?
- context_relevance: Did retrieved cases directly relate to the operational incident?
- answer_relevance: Does the diagnosis directly address the engineer's query?
- completeness: Are root causes, impact, and actions thoroughly covered?
- recommendation_quality: Are recommended actions technically safe and actionable?
- grounding_score: Is the reasoning grounded in verified telemetry?
- hallucination_risk: Probability that metrics or incident IDs were fabricated (0.0=none, 1.0=severe)
- overall_score: Weighted composite quality score (0.0 to 1.0)
- decision: "PASS" (score >= 0.80), "WARN" (0.65 - 0.79), or "FAIL" (< 0.65)
- issues: list of any specific errors or concerns

Return ONLY valid JSON matching this schema:
{{
  "faithfulness": 0.88,
  "context_relevance": 0.85,
  "answer_relevance": 0.90,
  "completeness": 0.86,
  "recommendation_quality": 0.88,
  "grounding_score": 0.88,
  "hallucination_risk": 0.05,
  "overall_score": 0.87,
  "decision": "PASS",
  "issues": []
}}"""

        system_prompt = "You are a strict, objective telecom network operations audit judge. Respond only with valid JSON."
        resp = None
        evaluator_name = "llm_as_a_judge"

        # 1. Primary Judge: Anthropic Claude (Gold standard evaluation)
        anthropic_key = getattr(settings, "ANTHROPIC_API_KEY", "") or os.environ.get("ANTHROPIC_API_KEY", "")
        if anthropic_key:
            try:
                headers = {
                    "x-api-key": anthropic_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json"
                }
                payload = {
                    "model": getattr(settings, "ANTHROPIC_MODEL", "claude-sonnet-4-5-20250929"),
                    "system": system_prompt,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.0,
                    "max_tokens": 400
                }
                c_resp = requests.post("https://api.anthropic.com/v1/messages", json=payload, headers=headers, timeout=20)
                if c_resp.status_code == 200:
                    resp = c_resp.json()["content"][0]["text"].strip()
                    evaluator_name = f"claude_judge ({settings.ANTHROPIC_MODEL})"
                    logger.info("Successfully evaluated via Anthropic Claude Judge (%s)", settings.ANTHROPIC_MODEL)
                else:
                    logger.warning("Anthropic Claude judge returned status %d. Falling back.", c_resp.status_code)
            except Exception as e:
                logger.warning("Anthropic Claude judge invocation failed (%s). Falling back.", e)

        # 2. Fallback Judge: LLMSynthesizer (Gemini / NVIDIA NIM)
        if not resp:
            resp = LLMSynthesizerAgent.call_llm(prompt=prompt, system_prompt=system_prompt, temperature=0.0, max_tokens=300)
            evaluator_name = "synthesizer_judge"

        if not resp:
            return None

        # Clean JSON from response
        clean_resp = resp.strip()
        if "```json" in clean_resp:
            clean_resp = clean_resp.split("```json")[1].split("```")[0].strip()
        elif "```" in clean_resp:
            clean_resp = clean_resp.split("```")[1].split("```")[0].strip()

        parsed = json.loads(clean_resp)
        parsed["evaluator_type"] = evaluator_name
        parsed["relevance_score"] = parsed.get("answer_relevance", 0.85)
        parsed["recommendation_score"] = parsed.get("recommendation_quality", 0.85)
        return parsed


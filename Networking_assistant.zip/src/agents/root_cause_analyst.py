"""
Evidence-based Root Cause Analysis (RCA) engine for NETPULSE AI.
Evaluates domain correlation rules across radio, transport, core, environmental, and configuration telemetry.
Directly uses historical retrieved cases to compute empirical correlation shares and cite real metrics.
"""
from typing import Dict, Any, List
import numpy as np
from src.analytics.thresholds import load_thresholds

class RootCauseAnalystAgent:
    @staticmethod
    def analyze_root_causes(
        telemetry: Dict[str, Any],
        historical_cases: List[Dict[str, Any]],
        conditions: List[str]
    ) -> List[Dict[str, Any]]:
        """
        Derives ranked candidate root causes with empirical confidence scores and evidence chains.
        Grounds likelihood in current telemetry breaches and retrieved historical precedent frequencies.
        """
        thresh = load_thresholds().get("kpis", {})
        lat_p75 = thresh.get("latency", {}).get("p75", 105.5)
        loss_p75 = thresh.get("packet_loss_rate", {}).get("p75", 9.4)
        tp_p25 = thresh.get("throughput", {}).get("p25", 392.6)
        user_p75 = thresh.get("user_count", {}).get("p75", 7457.5)
        data_p75 = thresh.get("data_usage", {}).get("p75", 37.5)
        hosr_p25 = thresh.get("handover_success_rate", {}).get("p25", 92.5)
        cdr_p75 = thresh.get("call_drop_rate", {}).get("p75", 1.7)
        crit_p75 = thresh.get("critical_alarm_count", {}).get("p75", 8.4)
        ss_p25 = thresh.get("signal_strength", {}).get("p25", -105.6)

        # Collect telemetry numbers
        tp = float(telemetry.get("throughput", 550.0))
        lat = float(telemetry.get("latency", 77.0))
        loss = float(telemetry.get("packet_loss_rate", 6.0))
        ss = float(telemetry.get("signal_strength", -90.0))
        users = float(telemetry.get("user_count", 5000))
        data_gb = float(telemetry.get("data_usage", 25.0))
        crit_alarms = float(telemetry.get("critical_alarm_count", 0))
        alarms = float(telemetry.get("alarm_count", 0))
        hosr = float(telemetry.get("handover_success_rate", 95.0))
        cdr = float(telemetry.get("call_drop_rate", 0.0))
        param_chgs = float(telemetry.get("parameter_changes", 0))
        weather = str(telemetry.get("weather", "Clear")).lower()
        sec_inc = float(telemetry.get("security_incidents", 0))
        auth_fail = float(telemetry.get("authentication_failures", 0))

        # Compute empirical precedent shares from historical cases
        n_hist = len(historical_cases)
        hist_crit_share = 0.0
        hist_loss_share = 0.0
        hist_lat_share = 0.0
        hist_user_share = 0.0
        hist_weather_share = 0.0
        avg_hist_mttr = 5.2

        if n_hist > 0:
            mttr_list = []
            for c in historical_cases:
                m = c.get("metrics", {})
                if float(m.get("critical_alarm_count", 0.0)) >= crit_p75:
                    hist_crit_share += 1.0
                if float(m.get("packet_loss_rate", 0.0)) >= loss_p75:
                    hist_loss_share += 1.0
                if float(m.get("latency", 0.0)) >= lat_p75:
                    hist_lat_share += 1.0
                if float(m.get("user_count", 0.0)) >= user_p75:
                    hist_user_share += 1.0
                w_str = str(c.get("environmental", {}).get("weather", c.get("weather", ""))).lower()
                if any(w in w_str for w in ["rain", "snow"]):
                    hist_weather_share += 1.0
                if m.get("mttr") is not None:
                    mttr_list.append(float(m.get("mttr")))

            hist_crit_share /= n_hist
            hist_loss_share /= n_hist
            hist_lat_share /= n_hist
            hist_user_share /= n_hist
            hist_weather_share /= n_hist
            if mttr_list:
                avg_hist_mttr = round(float(np.mean(mttr_list)), 1)

        candidates = []

        # 1. RAN Capacity / Congestion
        cong_evidence = []
        cong_score = 15.0
        if users >= user_p75 or "cell_congestion" in conditions:
            cong_score += 25.0
            cong_evidence.append(f"Elevated active subscriber load ({int(users)} users >= p75 threshold {int(user_p75)})")
        if data_gb >= data_p75:
            cong_score += 18.0
            cong_evidence.append(f"High user-plane data volume ({data_gb:.1f} GB >= p75 threshold {data_p75:.1f} GB)")
        if tp <= tp_p25 or "low_throughput" in conditions:
            cong_score += 18.0
            cong_evidence.append(f"Degraded downlink throughput capacity ({tp:.1f} Mbps <= p25 threshold {tp_p25:.1f} Mbps)")
        if lat >= lat_p75 or "high_latency" in conditions:
            cong_score += 12.0
            cong_evidence.append(f"Buffer queueing delay and elevated latency ({lat:.1f} ms >= p75 {lat_p75:.1f} ms)")
        if n_hist > 0 and hist_user_share > 0:
            boost = int(hist_user_share * 15)
            cong_score += boost
            cong_evidence.append(f"Precedent correlation: {int(hist_user_share * 100)}% of {n_hist} retrieved cases had high subscriber load (avg MTTR: {avg_hist_mttr:.1f} h)")

        if cong_evidence:
            candidates.append({
                "root_cause": "Radio Access Network (RAN) Congestion",
                "likelihood_score": min(95, int(cong_score)),
                "likelihood": "HIGH" if cong_score >= 60 else ("MEDIUM" if cong_score >= 35 else "LOW"),
                "evidence": cong_evidence,
                "domain": "Capacity / Air Interface"
            })

        # 2. RF Signal Degradation & Interference
        rf_evidence = []
        rf_score = 10.0
        if ss <= ss_p25 or "poor_signal" in conditions:
            rf_score += 30.0
            rf_evidence.append(f"Sub-optimal RSRP / signal strength ({ss:.1f} dBm <= p25 threshold {ss_p25:.1f} dBm)")
        if loss >= loss_p75 or "high_packet_loss" in conditions:
            rf_score += 20.0
            rf_evidence.append(f"Elevated air-interface frame loss rate ({loss:.2f}% >= p75 {loss_p75:.2f}%)")
        if cdr >= cdr_p75 or "high_call_drop" in conditions:
            rf_score += 20.0
            rf_evidence.append(f"Increased radio link failure & call drops ({cdr:.2f}% >= p75 {cdr_p75:.2f}%)")
        if n_hist > 0 and hist_weather_share > 0:
            boost = int(hist_weather_share * 12)
            rf_score += boost
            rf_evidence.append(f"Environmental correlation: {int(hist_weather_share * 100)}% of {n_hist} retrieved cases occurred during rain/snow precipitation")

        if rf_evidence:
            candidates.append({
                "root_cause": "Radio Frequency (RF) Signal Degradation & Interference",
                "likelihood_score": min(92, int(rf_score)),
                "likelihood": "HIGH" if rf_score >= 60 else ("MEDIUM" if rf_score >= 35 else "LOW"),
                "evidence": rf_evidence,
                "domain": "Physical Layer / RF"
            })

        # 3. IP Transport / Backhaul Link Congestion & Jitter
        trans_evidence = []
        trans_score = 10.0
        if lat >= lat_p75 or "high_latency" in conditions:
            trans_score += 28.0
            trans_evidence.append(f"Excessive round-trip transit delay ({lat:.1f} ms >= p75 {lat_p75:.1f} ms)")
        if loss >= loss_p75 or "high_packet_loss" in conditions:
            trans_score += 30.0
            trans_evidence.append(f"High transport/backhaul packet drop rate ({loss:.2f}% >= p75 {loss_p75:.2f}%)")
        if n_hist > 0 and hist_loss_share > 0:
            boost = int(hist_loss_share * 15)
            trans_score += boost
            trans_evidence.append(f"Transport precedent: {int(hist_loss_share * 100)}% of {n_hist} retrieved cases suffered packet loss >= p75 (avg MTTR: {avg_hist_mttr:.1f} h)")

        if trans_evidence:
            candidates.append({
                "root_cause": "IP Transport / Backhaul Link Congestion & Jitter",
                "likelihood_score": min(94, int(trans_score)),
                "likelihood": "HIGH" if trans_score >= 60 else ("MEDIUM" if trans_score >= 35 else "LOW"),
                "evidence": trans_evidence,
                "domain": "Transport Network"
            })

        # 4. Mobility Management / Handover
        ho_evidence = []
        ho_score = 10.0
        if hosr <= hosr_p25 or "low_handover_success" in conditions:
            ho_score += 40.0
            ho_evidence.append(f"Sub-threshold handover success rate ({hosr:.1f}% <= p25 {hosr_p25:.1f}%)")
        if param_chgs >= 2:
            ho_score += 20.0
            ho_evidence.append(f"Recent neighbor relation or parameter updates recorded ({int(param_chgs)} changes)")

        if ho_evidence:
            candidates.append({
                "root_cause": "Inter-Cell Handover Threshold Misconfiguration / Neighbor Mismatch",
                "likelihood_score": min(90, int(ho_score)),
                "likelihood": "HIGH" if ho_score >= 60 else ("MEDIUM" if ho_score >= 35 else "LOW"),
                "evidence": ho_evidence,
                "domain": "Mobility Management"
            })

        # 5. Hardware / Equipment Faults
        hw_evidence = []
        hw_score = 10.0
        if crit_alarms >= crit_p75 or "high_alarms" in conditions:
            hw_score += 40.0
            hw_evidence.append(f"Multiple active critical equipment alarms ({crit_alarms:.1f} critical / {int(alarms)} total >= p75 {crit_p75:.1f})")
        if any(w in weather for w in ["snow", "rain"]):
            hw_score += 15.0
            hw_evidence.append(f"Adverse weather condition ({weather.capitalize()}) impacting outdoor radio units")
        if n_hist > 0 and hist_crit_share > 0:
            boost = int(hist_crit_share * 15)
            hw_score += boost
            hw_evidence.append(f"Alarm precedent: {int(hist_crit_share * 100)}% of {n_hist} retrieved cases exhibited critical alarms >= p75")

        if hw_evidence:
            candidates.append({
                "root_cause": "Transceiver Hardware Anomaly / Feeder Cable Degradation",
                "likelihood_score": min(88, int(hw_score)),
                "likelihood": "HIGH" if hw_score >= 60 else ("MEDIUM" if hw_score >= 35 else "LOW"),
                "evidence": hw_evidence,
                "domain": "RAN Hardware"
            })

        # 6. Security / Signaling Storm
        if sec_inc >= 2 or auth_fail >= 10:
            candidates.append({
                "root_cause": "Signaling Storm / Unauthorized Authentication Anomaly",
                "likelihood_score": 75,
                "likelihood": "HIGH",
                "evidence": [
                    f"Authentication failure count reached {int(auth_fail)}",
                    f"{int(sec_inc)} active security events logged on control plane"
                ],
                "domain": "Security / Core"
            })

        # Sort by likelihood score descending
        candidates = sorted(candidates, key=lambda x: x["likelihood_score"], reverse=True)

        if not candidates:
            candidates = [
                {
                    "root_cause": "Transient Traffic Surge & Channel Modulation Variance",
                    "likelihood_score": 40,
                    "likelihood": "MEDIUM",
                    "evidence": [f"Nominal operational telemetry (Latency: {lat:.1f} ms, Throughput: {tp:.1f} Mbps, Loss: {loss:.2f}%)"],
                    "domain": "Air Interface"
                }
            ]

        return candidates

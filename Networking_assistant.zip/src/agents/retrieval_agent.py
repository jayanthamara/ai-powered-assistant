"""
Retrieval Agent for NETPULSE AI.
Interfaces with HybridSearchEngine to retrieve and rank historical incident precedents.
"""
from typing import Dict, Any, List, Optional
from src.rag.hybrid_search import HybridSearchEngine

class RetrievalAgent:
    def __init__(self, search_engine: HybridSearchEngine):
        self.search_engine = search_engine

    def retrieve_similar_cases(
        self,
        query: str,
        parsed_conditions: Dict[str, Any],
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        extracted_metrics = parsed_conditions.get("metrics", {})
        extracted_location = {
            "city": parsed_conditions.get("city"),
            "state": parsed_conditions.get("state")
        }
        
        return self.search_engine.search(
            query=query,
            filters=filters or {},
            extracted_metrics=extracted_metrics,
            extracted_location=extracted_location,
            top_k=top_k
        )

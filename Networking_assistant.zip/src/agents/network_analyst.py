"""
Network Analyst Agent for NETPULSE AI.
Performs deterministic telemetry anomaly analysis, network health summarization,
and executes comprehensive Network Impact Analysis.
"""
from typing import Dict, Any, List, Optional
import numpy as np
from src.analytics.network_impact import NetworkImpactAnalyzer
from src.analytics.thresholds import load_thresholds

class NetworkAnalystAgent:
    @staticmethod
    def analyze_network_condition(
        parsed_conditions: Dict[str, Any],
        retrieved_cases: List[Dict[str, Any]],
        direct_metrics: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Synthesizes network telemetry, extracts anomalies, and invokes Network Impact Analyzer.
        """
        thresh = load_thresholds().get("kpis", {})
        lat_p50 = thresh.get("latency", {}).get("p50", 77.4)
        lat_p75 = thresh.get("latency", {}).get("p75", 105.5)
        loss_p50 = thresh.get("packet_loss_rate", {}).get("p50", 6.3)
        loss_p75 = thresh.get("packet_loss_rate", {}).get("p75", 9.4)
        tp_p25 = thresh.get("throughput", {}).get("p25", 392.6)
        tp_p50 = thresh.get("throughput", {}).get("p50", 548.7)
        hosr_p25 = thresh.get("handover_success_rate", {}).get("p25", 92.5)
        cdr_p75 = thresh.get("call_drop_rate", {}).get("p75", 1.7)
        crit_p75 = thresh.get("critical_alarm_count", {}).get("p75", 8.4)

        metrics = direct_metrics or {}
        if not metrics and retrieved_cases:
            metrics = retrieved_cases[0].get("metrics", {})

        conditions = parsed_conditions.get("conditions", [])
        anomalies = []
        affected_metrics = []

        lat = float(metrics.get("latency", lat_p50))
        tp = float(metrics.get("throughput", tp_p50))
        loss = float(metrics.get("packet_loss_rate", loss_p50))
        cdr = float(metrics.get("call_drop_rate", 0.0))
        hosr = float(metrics.get("handover_success_rate", 95.0))
        crit_alarms = float(metrics.get("critical_alarm_count", 0.0))

        if "high_latency" in conditions or lat >= lat_p75:
            anomalies.append(f"Latency breach: {lat:.1f} ms exceeds p75 baseline ({lat_p75:.1f} ms)")
            affected_metrics.append("Latency")
        if "high_packet_loss" in conditions or loss >= loss_p75:
            anomalies.append(f"Packet drop spike: {loss:.2f}% exceeds p75 threshold ({loss_p75:.2f}%)")
            affected_metrics.append("Packet Loss Rate")
        if "low_throughput" in conditions or tp <= tp_p25:
            anomalies.append(f"Throughput throttling: {tp:.1f} Mbps below p25 threshold ({tp_p25:.1f} Mbps)")
            affected_metrics.append("Throughput")
        if "low_handover_success" in conditions or hosr <= hosr_p25:
            anomalies.append(f"Mobility impairment: {hosr:.1f}% handover success below p25 ({hosr_p25:.1f}%)")
            affected_metrics.append("Handover Success Rate")
        if "high_call_drop" in conditions or cdr >= cdr_p75:
            anomalies.append(f"Elevated call drop rate: {cdr:.2f}% (>= {cdr_p75:.2f}%)")
            affected_metrics.append("Call Drop Rate")
        if crit_alarms >= crit_p75:
            anomalies.append(f"{crit_alarms:.1f} active critical alarms exceeds p75 threshold ({crit_p75:.1f})")
            affected_metrics.append("Critical Alarms")

        if not anomalies:
            anomalies.append("Minor telemetry fluctuation within acceptable SLA tolerance")

        city = parsed_conditions.get("city") or (retrieved_cases[0].get("location", {}).get("city") if retrieved_cases else "Cluster")
        state = parsed_conditions.get("state") or (retrieved_cases[0].get("location", {}).get("state") if retrieved_cases else "")
        region = f"{city}, {state}".strip(", ")

        summary = (
            f"Network performance assessment for {region}: "
            f"{len(affected_metrics)} critical KPI thresholds breached ({', '.join(affected_metrics) if affected_metrics else 'Nominal'}). "
            f"Throughput measured at {tp:.1f} Mbps with {lat:.1f} ms latency and {loss:.2f}% packet loss."
        )

        # Execute dedicated Network Impact Analysis module
        impact_analysis = NetworkImpactAnalyzer.analyze_impact(
            extracted_conditions=parsed_conditions,
            historical_cases=retrieved_cases,
            parsed_metrics=metrics
        )

        return {
            "summary": summary,
            "anomalies": anomalies,
            "affected_metrics": affected_metrics,
            "current_metrics": metrics,
            "impact_analysis": impact_analysis
        }

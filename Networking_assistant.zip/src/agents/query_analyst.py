"""
Query Analyst Agent for NETPULSE AI.
Performs input guardrailing, prompt injection detection, domain classification,
and natural-language condition extraction.
"""
from typing import Dict, Any, Tuple
from src.guardrails.input_validator import validate_telecom_query
from src.guardrails.prompt_injection import check_prompt_injection
from src.guardrails.domain_classifier import is_telecom_domain
from src.analytics.condition_extractor import extract_network_conditions

class QueryAnalystAgent:
    @staticmethod
    def analyze_query(query: str) -> Dict[str, Any]:
        """
        Validates and analyzes user query.
        Returns dictionary with validation status, sanitized query, domain confidence, and extracted conditions.
        """
        # 1. Base input validation
        val_res = validate_telecom_query(query)
        if not val_res.is_valid:
            return {
                "is_valid": False,
                "error_message": val_res.error_message,
                "sanitized_query": "",
                "parsed_conditions": {}
            }

        sanitized_q = val_res.sanitized_query

        # 2. Prompt injection guardrail
        is_inj, inj_reason = check_prompt_injection(sanitized_q)
        if is_inj:
            return {
                "is_valid": False,
                "error_message": inj_reason,
                "sanitized_query": sanitized_q,
                "parsed_conditions": {}
            }

        # 3. Domain relevance check
        is_relevant, domain_conf = is_telecom_domain(sanitized_q)
        if not is_relevant:
            return {
                "is_valid": False,
                "error_message": "Query outside telecom domain scope. NETPULSE AI assists with telecom network operations, RAN metrics, and incident management.",
                "sanitized_query": sanitized_q,
                "parsed_conditions": {}
            }

        # 4. Extract conditions and metrics
        parsed = extract_network_conditions(sanitized_q)

        return {
            "is_valid": True,
            "error_message": None,
            "sanitized_query": sanitized_q,
            "domain_confidence": domain_conf,
            "parsed_conditions": parsed
        }

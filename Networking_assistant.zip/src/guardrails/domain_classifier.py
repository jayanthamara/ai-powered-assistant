"""
Telecom domain scope classifier for NETPULSE AI.
Ensures queries pertain to telecom network operations, RAN, 5G/LTE metrics, or incident management.
Uses strict word-boundary matching to prevent substring false-positives (e.g. 'ran' inside 'grand' or 'orange').
"""
import re
from typing import Tuple, Set

# Core telecom-specific technical keywords (sufficient on their own)
PRIMARY_TELECOM_KEYWORDS = [
    "cell", "cells", "tower", "antenna", "signal", "rssi", "rsrp", "rsrq", "sinr", "dbm",
    "latency", "packet loss", "throughput", "bandwidth", "jitter", "handover",
    "call drop", "call drop rate", "mttr", "cell availability", "availability", "alarm", "alarms",
    "critical alarm", "outage", "fault", "incident", "network", "ran", "core", "gnb", "enb",
    "gnodeb", "enodeb", "congestion", "radio", "telecom", "user count", "traffic", "qoe", "qos",
    "parameter", "configuration", "5g", "4g", "lte", "kpi", "telephony", "sector",
    "authentication failure", "security incident", "subcarrier", "backhaul", "uplink", "downlink",
    "service degradation", "carrier", "spectrum", "mimo", "beamforming", "rf", "telecoms", "netpulse"
]

# Environmental / diagnostic terms (require additional telecom context)
CONTEXTUAL_TERMS = [
    "weather", "season", "summer", "winter", "fall", "spring", "temperature", "humidity", "rain", "snow", "storm",
    "remediation", "action", "degradation", "performance", "investigate", "diagnose", "root cause", "metric"
]

COMPILED_PRIMARY_REGEX = [
    re.compile(r"\b" + re.escape(kw) + r"\b", re.IGNORECASE)
    for kw in PRIMARY_TELECOM_KEYWORDS
]

COMPILED_CONTEXT_REGEX = [
    re.compile(r"\b" + re.escape(kw) + r"\b", re.IGNORECASE)
    for kw in CONTEXTUAL_TERMS
]

def is_telecom_domain(query: str) -> Tuple[bool, float]:
    """
    Checks if query contains relevant telecom concepts with strict word boundary checking.
    Returns: (is_relevant, confidence_score)
    """
    query_clean = str(query).strip()

    # 1. Match primary telecom terms with word boundaries
    primary_matches = sum(1 for pattern in COMPILED_PRIMARY_REGEX if pattern.search(query_clean))

    # 2. Match contextual terms with word boundaries
    context_matches = sum(1 for pattern in COMPILED_CONTEXT_REGEX if pattern.search(query_clean))

    # If primary telecom terms exist
    if primary_matches >= 1:
        confidence = min(1.0, 0.5 + primary_matches * 0.15 + context_matches * 0.05)
        return True, round(confidence, 2)

    # General diagnostic queries with explicit troubleshooting context (minimum 4 words)
    q_lower = query_clean.lower()
    general_diagnostic = any(
        re.search(r"\b" + w + r"\b", q_lower)
        for w in ["incident", "problem", "failure", "issue", "troubleshoot", "diagnose", "metric"]
    )
    if general_diagnostic and context_matches >= 1 and len(query_clean.split()) >= 4:
        return True, 0.60

    return False, 0.05

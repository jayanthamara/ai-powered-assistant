"""
Prompt injection detection guardrail for NETPULSE AI.
Detects attempts to override system directives, leak secrets, or bypass operational domain boundaries.
Blocks classic injection vectors including instruction overrides, jailbreaks, persona attacks, and secret leakage.
"""
import re
from typing import Tuple

INJECTION_PATTERNS = [
    # Instruction / Directive overrides
    r"\bignore\s+(?:all\s+|the\s+|any\s+|prior\s+|previous\s+|system\s+)*instructions?\b",
    r"\bdisregard\s+(?:all\s+|the\s+|any\s+|prior\s+|previous\s+|system\s+)*directives?\b",
    r"\bforget\s+(?:all\s+|the\s+|any\s+|prior\s+|previous\s+|system\s+)*(?:instructions?|directives?|rules?|prompts?)\b",
    r"\boverride\s+(?:all\s+|the\s+|any\s+|prior\s+|previous\s+|system\s+)*(?:instructions?|directives?|rules?|safety)\b",

    # Jailbreak / Persona attacks
    r"\bjailbreak\b",
    r"\bDAN\b",
    r"\bdeveloper\s+mode\b",
    r"\byou\s+are\s+now\s+(?:in\s+)?(?:developer\s+mode|dan|unrestricted)\b",
    r"\bact\s+as\s+(?:an?\s+)?(?:unfiltered|unrestricted|jailbroken|evil)\b",
    r"\bbypass\s+(?:safety|guardrails?|rules?|guidelines?|filters?)\b",

    # Secret / Key revelation
    r"\b(?:reveal|show|print|display|tell\s+me|expose|leak)\s+(?:me\s+)?(?:the\s+)?(?:all\s+)?(?:api[_\s-]*keys?|passwords?|credentials?|secrets?|system\s*prompts?)\b",
    r"\bsystem\s*prompt\b",

    # SQL / Code injection / XSS
    r"\bdrop\s+table\b",
    r"\bunion\s+(?:all\s+)?select\b",
    r"<script\b",
    r"\bexec\s*\(",
    r"\beval\s*\(",
    r"\bos\.system\("
]

COMPILED_INJECTION_REGEX = [re.compile(p, re.IGNORECASE) for p in INJECTION_PATTERNS]

def check_prompt_injection(query: str) -> Tuple[bool, str]:
    """
    Evaluates text for adversarial prompt injection patterns.
    Returns: (is_injection, reason)
    """
    for pattern in COMPILED_INJECTION_REGEX:
        if pattern.search(query):
            return True, "Security policy violation: Potential prompt injection or system override detected."

    return False, ""

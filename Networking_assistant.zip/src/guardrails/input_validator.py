"""
Input validation guardrail for NETPULSE AI.
Enforces query length, structure sanity, and delegates to injection and domain filters.
"""
from typing import Tuple, Optional
from pydantic import BaseModel, Field
from fastapi import Request, HTTPException

class ValidationResult(BaseModel):
    is_valid: bool
    error_message: Optional[str] = None
    sanitized_query: str = ""

def validate_telecom_query(query: Optional[str]) -> ValidationResult:
    """
    Validates user query against nullity, brevity, length limits, and obvious spam.
    """
    if query is None or not str(query).strip():
        return ValidationResult(
            is_valid=False,
            error_message="Query cannot be empty. Please provide a telecom network condition or operational query.",
            sanitized_query=""
        )

    clean_q = str(query).strip()

    if len(clean_q) < 5:
        return ValidationResult(
            is_valid=False,
            error_message="Query is too brief to analyze. Please describe the network condition with operational context.",
            sanitized_query=clean_q
        )

    if len(clean_q) > 2000:
        return ValidationResult(
            is_valid=False,
            error_message="Query exceeds maximum allowed length of 2000 characters.",
            sanitized_query=clean_q[:2000]
        )

    # Check for repetitive garbage (e.g. 'aaaaa...')
    if len(set(clean_q.replace(" ", ""))) < 3 and len(clean_q) > 10:
        return ValidationResult(
            is_valid=False,
            error_message="Query contains invalid repetitive characters.",
            sanitized_query=clean_q
        )

    return ValidationResult(is_valid=True, error_message=None, sanitized_query=clean_q)


async def validate_free_text_guardrail(request: Request) -> None:
    """
    Shared FastAPI dependency for endpoints that accept free-text inputs.
    Enforces prompt injection detection, input sanity, and domain boundary guardrails.
    """
    from src.guardrails.prompt_injection import check_prompt_injection
    from src.guardrails.domain_classifier import is_telecom_domain

    try:
        body = await request.json()
    except Exception:
        return

    if not isinstance(body, dict):
        return

    # Extract free-text target
    text = body.get("query")
    if not text and "incident_type" in body:
        text = body.get("incident_type")

    if text is None:
        return

    text_str = str(text).strip()
    if not text_str:
        return

    # 1. Prompt Injection Guardrail (strictly applied everywhere)
    is_inj, inj_reason = check_prompt_injection(text_str)
    if is_inj:
        raise HTTPException(
            status_code=400,
            detail=inj_reason or "Security policy violation: Prompt injection or system directive override detected."
        )

    # 2. Base sanity validation (length, repetitive garbage)
    val_res = validate_telecom_query(text_str)
    if not val_res.is_valid:
        raise HTTPException(status_code=400, detail=val_res.error_message)

    # 3. Domain relevance check
    # Copilot handles out-of-scope routing gracefully via its own agent scope classifier
    path = request.url.path
    if not ("/copilot" in path or "/chat" in path):
        is_tel, _ = is_telecom_domain(text_str)
        if not is_tel:
            raise HTTPException(
                status_code=400,
                detail="Query outside telecom domain scope. NETPULSE AI assists with telecom network operations, RAN metrics, and incident management."
            )

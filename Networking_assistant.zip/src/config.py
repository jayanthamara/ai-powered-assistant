"""
NETPULSE AI configuration management using Pydantic Settings.
Supports dynamic environment loading, configurable RAG weights, LLM providers, and paths.
"""
import os
from pydantic_settings import BaseSettings
from pydantic import Field, ConfigDict

class Settings(BaseSettings):
    model_config = ConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

    # App Settings
    APP_NAME: str = "NETPULSE AI"
    APP_VERSION: str = "1.1.0"
    DEBUG: bool = False
    DEMO_MODE: bool = False  # Production mode with live operational telemetry & models
    
    # Primary LLM Provider: NVIDIA NIM (with OpenAI & Demo fallback)
    LLM_PROVIDER: str = Field(default="nvidia", description="nvidia, openai, or demo")
    NVIDIA_API_KEY: str = Field(default="", description="NVIDIA NIM API key (keep in .env only)")
    NVIDIA_BASE_URL: str = Field(default="https://integrate.api.nvidia.com/v1", description="NVIDIA NIM Base URL")
    NVIDIA_MODEL: str = Field(default="meta/llama-3.2-11b-vision-instruct", description="NVIDIA NIM model identifier")

    # Fallback LLM Settings: OpenAI
    OPENAI_API_KEY: str = Field(default="", description="OpenAI API key")
    OPENAI_API_BASE: str = Field(default="https://api.openai.com/v1", description="OpenAI Base URL")
    LLM_MODEL: str = Field(default="gpt-4o-mini", description="OpenAI Model identifier")

    # Independent Evaluator & LLM-as-a-Judge: Anthropic Claude
    ANTHROPIC_API_KEY: str = Field(default="", description="Anthropic API key for LLM-as-a-Judge evaluation")
    ANTHROPIC_MODEL: str = Field(default="claude-sonnet-4-5-20250929", description="Anthropic Claude model identifier")
    
    # Vector Database & RAG / Retrieval Settings
    VECTOR_STORE: str = "chromadb"  # "chromadb" or "dense-faiss-compat"
    CHROMA_PERSIST_DIR: str = "data/chroma"
    CHROMA_COLLECTION_NAME: str = "netpulse_telecom_incidents"
    EMBEDDING_MODEL: str = "dense-telecom-128"
    TOP_K: int = 5
    ENABLE_RERANKER: bool = True
    RERANK_CANDIDATE_POOL: int = 15

    # Hybrid Search Fusion Weights (Must sum to ~1.0)
    SEMANTIC_WEIGHT: float = 0.45
    KEYWORD_WEIGHT: float = 0.30
    METRIC_WEIGHT: float = 0.15
    METADATA_WEIGHT: float = 0.10

    # Dataset Configuration
    MAX_RECORDS: int = 10000
    DATASET_SEED: int = 42

    # Paths
    RAW_DATA_PATH: str = "data/raw/telecom_netops_raw.csv"
    PROCESSED_DATA_PATH: str = "data/processed/telecom_incidents_processed.csv"
    THRESHOLDS_PATH: str = "data/processed/thresholds.json"
    INDEX_STORAGE_PATH: str = "data/processed/search_indices.pkl"
    ML_MODELS_PATH: str = "data/processed/ml_models.pkl"
    ML_METRICS_PATH: str = "data/processed/ml_metrics.json"
    DATABASE_URL: str = "sqlite:///data/netpulse.db"

settings = Settings()

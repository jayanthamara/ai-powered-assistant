"""
Machine Learning Risk Prediction service for NETPULSE AI.
Uses trained Random Forest ensemble to predict operational fault probability and
extracts local feature contributions for explainable risk reporting.
"""
import os
import logging
from typing import Dict, Any, List
import joblib
import pandas as pd
import numpy as np
from src.config import settings

logger = logging.getLogger("risk_model")

class MLRiskService:
    def __init__(self, models_path: str = None):
        self.models_path = models_path or settings.ML_MODELS_PATH
        self.bundle = None
        self._load()

    def _load(self):
        if os.path.exists(self.models_path):
            try:
                self.bundle = joblib.load(self.models_path)
                logger.info("Loaded ML risk models successfully from %s", self.models_path)
            except Exception as e:
                logger.error("Failed to load ML models (%s). Using fallback logic.", e)
                self.bundle = None
        else:
            logger.warning("ML models file not found at %s. Model service will train or fallback.", self.models_path)

    def predict_risk(self, telemetry: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predicts operational risk probability and generates explainable feature impacts.
        """
        if not self.bundle or "risk_classifier" not in self.bundle:
            # Deterministic fallback calculation
            loss = float(telemetry.get("packet_loss_rate", 1.0))
            lat = float(telemetry.get("latency", 30.0))
            crit = float(telemetry.get("critical_alarm_count", 0))
            score = int(min(100, max(10, 15 + loss * 3 + lat * 0.2 + crit * 10)))
            level = "CRITICAL" if score >= 75 else ("HIGH" if score >= 50 else ("MEDIUM" if score >= 25 else "LOW"))
            return {
                "risk_score": score,
                "risk_level": level,
                "top_risk_factors": [
                    {"feature": "Critical Alarm Count", "impact": 0.35},
                    {"feature": "Packet Loss Rate", "impact": 0.28},
                    {"feature": "Latency", "impact": 0.22}
                ]
            }

        clf = self.bundle["risk_classifier"]
        feature_cols = self.bundle["feature_columns"]

        # Build feature vector with default values
        row_dict = {}
        for col in feature_cols:
            val = telemetry.get(col)
            if val is None:
                # Default baseline
                if col == "cell_availability": val = 99.5
                elif col == "signal_strength": val = -85.0
                elif col == "handover_success_rate": val = 98.0
                elif col == "connection_setup_success_rate": val = 99.0
                elif col == "throughput": val = 120.0
                elif col == "latency": val = 35.0
                elif col == "packet_loss_rate": val = 0.8
                elif col == "call_drop_rate": val = 0.5
                else: val = 0.0
            row_dict[col] = float(val)

        df_input = pd.DataFrame([row_dict])[feature_cols]

        # Predict probability of high fault risk class 1
        probs = clf.predict_proba(df_input)[0]
        # High risk is class 1 (if classes are [0, 1])
        prob_high = float(probs[1]) if len(probs) > 1 else float(probs[0])
        risk_score = int(round(prob_high * 100))
        risk_score = max(5, min(98, risk_score))

        if risk_score >= 75:
            risk_level = "CRITICAL"
        elif risk_score >= 50:
            risk_level = "HIGH"
        elif risk_score >= 25:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"

        # Determine top risk factors based on global importance weighted by current anomaly magnitude
        top_factors = []
        importances = self.bundle.get("feature_importances", [])
        for feat, imp in importances[:4]:
            feat_display = feat.replace("_", " ").title()
            top_factors.append({
                "feature": feat_display,
                "impact": round(float(imp), 2)
            })

        # Compute local per-prediction explanations using normalized anomaly deviations
        per_pred_explanations = []
        try:
            from src.analytics.thresholds import load_thresholds
            thresholds = load_thresholds()
            for feat, imp in importances:
                if feat in thresholds and feat in row_dict:
                    val = row_dict[feat]
                    p50 = thresholds[feat].get("p50", 0.0)
                    p75 = thresholds[feat].get("p75", p50 + 1.0)
                    spread = max(1e-3, abs(p75 - p50))
                    # For metrics where lower is worse (availability, handover, setup)
                    if feat in ["cell_availability", "handover_success_rate", "connection_setup_success_rate"]:
                        deviation = max(0.0, (p50 - val) / spread)
                    else:
                        deviation = max(0.0, (val - p50) / spread)
                    local_score = deviation * float(imp)
                    if local_score > 0.005:
                        per_pred_explanations.append({
                            "feature": feat.replace("_", " ").title(),
                            "feature_key": feat,
                            "observed_value": val,
                            "baseline_p50": p50,
                            "local_contribution": round(local_score, 3)
                        })
            per_pred_explanations.sort(key=lambda x: x["local_contribution"], reverse=True)
        except Exception as e:
            logger.debug("Could not compute local explanation: %s", e)

        return {
            "risk_score": risk_score,
            "risk_level": risk_level,
            "top_risk_factors": top_factors,
            "per_prediction_explanation": per_pred_explanations[:5]
        }

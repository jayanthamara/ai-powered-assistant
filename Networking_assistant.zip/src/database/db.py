"""
SQLite database management for NETPULSE AI feedback and audit logging.
Provides persistent recording of operator evaluations, recommendations, and query feedback.
"""
import os
import sqlite3
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger("database")

DB_FILE = "data/netpulse.db"

def init_db(db_path: str = DB_FILE):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Feedback table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS operator_feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        query TEXT NOT NULL,
        incident_type TEXT,
        diagnosis_feedback TEXT NOT NULL,
        recommendation_feedback TEXT,
        user_comment TEXT,
        grounding_rating REAL,
        case_id TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # Query audit logs table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS query_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        query TEXT NOT NULL,
        incident_type TEXT,
        risk_score INTEGER,
        risk_level TEXT,
        impact_score INTEGER,
        latency_seconds REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    conn.commit()
    conn.close()
    logger.info("Initialized SQLite database at %s", db_path)

def save_feedback(
    query: str,
    diagnosis_feedback: str,
    incident_type: Optional[str] = None,
    recommendation_feedback: Optional[str] = None,
    user_comment: Optional[str] = None,
    grounding_rating: Optional[float] = None,
    case_id: Optional[str] = None,
    db_path: str = DB_FILE
) -> int:
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("""
    INSERT INTO operator_feedback 
    (query, incident_type, diagnosis_feedback, recommendation_feedback, user_comment, grounding_rating, case_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (query, incident_type, diagnosis_feedback, recommendation_feedback, user_comment, grounding_rating, case_id))
    new_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return new_id

def log_query_execution(
    query: str,
    incident_type: str,
    risk_score: int,
    risk_level: str,
    impact_score: int,
    latency_seconds: float,
    db_path: str = DB_FILE
):
    try:
        init_db(db_path)
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("""
        INSERT INTO query_logs 
        (query, incident_type, risk_score, risk_level, impact_score, latency_seconds)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (query, incident_type, risk_score, risk_level, impact_score, latency_seconds))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.warning("Could not log query execution: %s", e)

def get_recent_feedback(limit: int = 50, db_path: str = DB_FILE) -> List[Dict[str, Any]]:
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM operator_feedback ORDER BY created_at DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    results = [dict(row) for row in rows]
    conn.close()
    return results

def get_feedback_statistics(db_path: str = DB_FILE) -> Dict[str, Any]:
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) FROM operator_feedback")
    total_feedback = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM operator_feedback WHERE diagnosis_feedback = 'Helpful' OR diagnosis_feedback = 'Correct Diagnosis'")
    positive_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM query_logs")
    total_queries = cursor.fetchone()[0]

    conn.close()
    return {
        "total_feedback_entries": total_feedback,
        "positive_feedback_count": positive_count,
        "positive_rate": round(positive_count / max(1, total_feedback), 2) if total_feedback > 0 else 1.0,
        "total_queries_logged": total_queries
    }

"""
Dataset Loading and Data-Access Layer for NETPULSE AI.
Strictly uses the official Hugging Face dataset: fenar/5g_netops.
Provides decoupled data ingestion, validation, normalization, and local caching
so the rest of the application does not depend on external network access once cached.
"""
import os
import json
import logging
from typing import Optional, Dict, Any, List
import pandas as pd
import numpy as np

logger = logging.getLogger("dataset_loader")

HF_DATASET_NAME = "fenar/5g_netops"
DEFAULT_RAW_PATH = "data/raw/telecom_netops_raw.csv"
DEFAULT_PROCESSED_PATH = "data/processed/telecom_incidents_processed.csv"
DEFAULT_THRESHOLDS_PATH = "data/processed/thresholds.json"
DEFAULT_MAX_RECORDS = 10000
DEFAULT_SEED = 42

# Canonical column mapping for fenar/5g_netops (26 key operational fields + zip)
CANONICAL_COLUMNS: Dict[str, str] = {
    "season": "season",
    "cell_availability": "cell_availability",
    "cell_availability_": "cell_availability",
    "mttr": "mttr",
    "mttr_hours": "mttr",
    "throughput": "throughput",
    "throughput_mbps": "throughput",
    "latency": "latency",
    "latency_ms": "latency",
    "packet_loss_rate": "packet_loss_rate",
    "packet_loss_rate_": "packet_loss_rate",
    "packet_loss": "packet_loss_rate",
    "packet_loss_pct": "packet_loss_rate",
    "call_drop_rate": "call_drop_rate",
    "call_drop_rate_": "call_drop_rate",
    "call_drop_pct": "call_drop_rate",
    "handover_success_rate": "handover_success_rate",
    "handover_success_rate_": "handover_success_rate",
    "handover_success_pct": "handover_success_rate",
    "alarm_count": "alarm_count",
    "alarms": "alarm_count",
    "critical_alarm_count": "critical_alarm_count",
    "critical_alarms": "critical_alarm_count",
    "parameter_changes": "parameter_changes",
    "successful_configuration_changes": "successful_configuration_changes",
    "successful_configuration_changes_": "successful_configuration_changes",
    "data_usage": "data_usage",
    "data_usage_gb": "data_usage",
    "user_count": "user_count",
    "signal_strength": "signal_strength",
    "signal_strength_dbm": "signal_strength",
    "jitter": "jitter",
    "jitter_ms": "jitter",
    "connection_setup_success_rate": "connection_setup_success_rate",
    "connection_setup_success_rate_": "connection_setup_success_rate",
    "security_incidents": "security_incidents",
    "authentication_failures": "authentication_failures",
    "temperature": "temperature",
    "temperature_c": "temperature",
    "humidity": "humidity",
    "humidity_": "humidity",
    "weather": "weather",
    "issue_reported": "issue_reported",
    "city": "city",
    "state": "state",
    "zip": "zip",
    "fault_occurrence_rate": "fault_occurrence_rate",
    "fault_occurrence_rate_": "fault_occurrence_rate"
}

NUMERIC_COLUMNS: List[str] = [
    "cell_availability", "mttr", "throughput", "latency", "packet_loss_rate",
    "call_drop_rate", "handover_success_rate", "alarm_count", "critical_alarm_count",
    "parameter_changes", "successful_configuration_changes", "data_usage",
    "user_count", "signal_strength", "jitter", "connection_setup_success_rate",
    "security_incidents", "authentication_failures", "temperature", "humidity",
    "zip", "fault_occurrence_rate"
]

CATEGORICAL_COLUMNS: List[str] = ["season", "weather", "issue_reported", "city", "state"]

def clean_column_name(col: str) -> str:
    """Sanitize column name to snake_case."""
    import re
    col = re.sub(r"[^\w\s]", "", str(col).strip())
    col = re.sub(r"\s+", "_", col).lower()
    return col

def normalize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Normalizes raw Hugging Face dataframe headers to canonical snake_case."""
    cleaned_names = {col: clean_column_name(col) for col in df.columns}
    df = df.rename(columns=cleaned_names)

    mapping = {}
    for col in df.columns:
        if col in CANONICAL_COLUMNS:
            mapping[col] = CANONICAL_COLUMNS[col]
        else:
            matched = False
            for k, v in CANONICAL_COLUMNS.items():
                if len(k) >= 3 and (col.startswith(k) or col.endswith(k) or f"_{k}" in col):
                    mapping[col] = v
                    matched = True
                    break
            if not matched:
                mapping[col] = col
    df = df.rename(columns=mapping)
    return df

def load_hf_dataset(
    split: str = "train",
    max_records: Optional[int] = DEFAULT_MAX_RECORDS,
    force_download: bool = False,
    raw_cache_path: str = DEFAULT_RAW_PATH,
    seed: int = DEFAULT_SEED
) -> pd.DataFrame:
    """
    Loads fenar/5g_netops directly from Hugging Face datasets.
    Uses local cache if available and not force_download (supports full offline mode).
    Samples randomly using a fixed seed (42) rather than taking the first N rows.
    """
    # 1. Check local cache first for fast offline startup
    if not force_download and os.path.exists(raw_cache_path):
        logger.info("Loading fenar/5g_netops from local cache: %s", raw_cache_path)
        df = pd.read_csv(raw_cache_path)
        if max_records and len(df) == max_records:
            return df
        elif max_records and len(df) > max_records:
            return df.iloc[:max_records].copy()

    logger.info("Fetching Hugging Face dataset: %s (split: %s, seed: %d)...", HF_DATASET_NAME, split, seed)
    from datasets import load_dataset
    ds = load_dataset(HF_DATASET_NAME)
    split_data = ds[split]

    if max_records and max_records < len(split_data):
        logger.info("Selecting seeded random sample (%d rows, seed=%d) from %d total...", max_records, seed, len(split_data))
        df_raw = split_data.shuffle(seed=seed).select(range(max_records)).to_pandas()
    else:
        df_raw = split_data.to_pandas()

    logger.info("Normalizing and validating %d records from %s...", len(df_raw), HF_DATASET_NAME)
    df = normalize_dataframe(df_raw)

    # Preserve dataset traceability
    if "dataset_record_idx" not in df.columns:
        df["dataset_record_idx"] = list(range(len(df)))
    if "source_dataset" not in df.columns:
        df["source_dataset"] = HF_DATASET_NAME
    if "incident_id" not in df.columns:
        df["incident_id"] = [f"5G-NETOPS-{1000 + i}" for i in range(len(df))]

    # Cache raw to disk
    os.makedirs(os.path.dirname(raw_cache_path), exist_ok=True)
    df.to_csv(raw_cache_path, index=False)
    logger.info("Saved raw normalized dataset cache to %s (%d rows)", raw_cache_path, len(df))
    return df

def compute_and_save_thresholds(
    df: pd.DataFrame,
    thresholds_path: str = DEFAULT_THRESHOLDS_PATH
) -> Dict[str, Any]:
    """
    Computes data-driven distributions (p25, p50, p75, p90, mean, std) per KPI
    and persists them to thresholds.json to serve as single source of truth.
    """
    from src.analytics.thresholds import save_thresholds
    kpi_cols = [c for c in NUMERIC_COLUMNS if c in df.columns and c != "zip"]
    thresh_data: Dict[str, Any] = {"kpis": {}}
    for c in kpi_cols:
        q = df[c].quantile([0.25, 0.50, 0.75, 0.90]).to_dict()
        thresh_data["kpis"][c] = {
            "p25": round(float(q[0.25]), 2),
            "p50": round(float(q[0.50]), 2),
            "p75": round(float(q[0.75]), 2),
            "p90": round(float(q[0.90]), 2),
            "mean": round(float(df[c].mean()), 2),
            "std": round(float(df[c].std()), 2)
        }

    p75_fault = thresh_data["kpis"].get("fault_occurrence_rate", {}).get("p75", 48.28)
    thresh_data["severity_cutoffs"] = {
        "LOW_MAX": 20,
        "MEDIUM_MAX": 35,
        "HIGH_MAX": 53,
        "CRITICAL_MIN": 54
    }
    thresh_data["high_fault_risk_cutoff"] = p75_fault

    save_thresholds(thresh_data, thresholds_path)
    return thresh_data

def build_incident_narrative(row: pd.Series, thresholds: Optional[Dict[str, Any]] = None) -> str:
    """Transforms a structured operational record into a rich semantic narrative."""
    from src.analytics.thresholds import load_thresholds

    if thresholds is None:
        thresholds = load_thresholds()

    kpis = thresholds.get("kpis", {})

    city = row.get("city", "Unknown City")
    state = row.get("state", "Unknown State")
    season = row.get("season", "Unknown Season")
    weather = row.get("weather", "Normal")
    issue = str(row.get("issue_reported", "no")).lower()
    has_issue = issue in ["yes", "1", "true"]

    tp = float(row.get("throughput", 0.0))
    lat = float(row.get("latency", 0.0))
    loss = float(row.get("packet_loss_rate", 0.0))
    cdr = float(row.get("call_drop_rate", 0.0))
    hosr = float(row.get("handover_success_rate", 0.0))
    alarms = int(float(row.get("alarm_count", 0)))
    crit_alarms = float(row.get("critical_alarm_count", 0))
    ss = float(row.get("signal_strength", -90.0))
    fault_rate = float(row.get("fault_occurrence_rate", 0.0))
    users = int(float(row.get("user_count", 0)))
    data_gb = float(row.get("data_usage", 0.0))
    jitter = float(row.get("jitter", 0.0))
    mttr = float(row.get("mttr", 0.0))
    sec = int(float(row.get("security_incidents", 0)))
    auth_fail = int(float(row.get("authentication_failures", 0)))

    # Semantic condition descriptor tags aligned with data-driven percentiles
    condition_tags = []
    crit_p75 = kpis.get("critical_alarm_count", {}).get("p75", 8.4)
    loss_p75 = kpis.get("packet_loss_rate", {}).get("p75", 9.4)
    lat_p75 = kpis.get("latency", {}).get("p75", 105.0)
    tp_p25 = kpis.get("throughput", {}).get("p25", 392.0)
    hosr_p25 = kpis.get("handover_success_rate", {}).get("p25", 92.5)
    cdr_p75 = kpis.get("call_drop_rate", {}).get("p75", 1.7)
    ss_p25 = kpis.get("signal_strength", {}).get("p25", -105.6)
    fault_p75 = thresholds.get("high_fault_risk_cutoff", 48.28)

    if crit_alarms >= crit_p75:
        condition_tags.extend(["increasing alarms", "alarm counts", "critical alarms", "network fault", "service quality degradation", "cell alarms"])
    if loss >= loss_p75:
        condition_tags.extend(["packet loss", "high packet loss", "packet drop rate", "transport degradation"])
    if lat >= lat_p75:
        condition_tags.extend(["high latency", "elevated latency", "latency spike", "delay"])
    if tp <= tp_p25:
        condition_tags.extend(["reduced throughput", "low throughput", "throughput degradation"])
    if hosr <= hosr_p25:
        condition_tags.extend(["handover failure", "declining handover", "mobility issue"])
    if cdr >= cdr_p75:
        condition_tags.extend(["call drop rate", "dropped calls", "call drops"])
    if ss <= ss_p25:
        condition_tags.extend(["poor signal strength", "weak signal", "poor signal quality", "low radio signal"])
    if fault_rate >= fault_p75:
        condition_tags.extend(["high fault occurrence", "fault risk", "network anomalies"])
    if sec >= 3 or auth_fail >= 10:
        condition_tags.extend(["security incident", "authentication failures"])
    if users >= 7500:
        condition_tags.extend(["cell congestion", "high traffic load", "user congestion"])

    tag_str = ", ".join(condition_tags) if condition_tags else "nominal operations"

    doc = (
        f"Network operational incident case in {city}, {state} during {season} with {weather} weather. "
        f"Issue reported: {'yes, operational anomaly' if has_issue else 'no, baseline variance'}. "
        f"Symptom profile and condition tags: {tag_str}. "
        f"Throughput was {tp:.1f} Mbps. Latency was {lat:.1f} ms. "
        f"Packet loss was {loss:.2f}%. Call drop rate was {cdr:.2f}%. "
        f"Handover success rate was {hosr:.1f}%. Total alarms: {alarms}. "
        f"Critical alarm count: {crit_alarms:.1f}. Active alarm counts recorded. "
        f"Signal strength was {ss:.1f} dBm. Fault occurrence rate was {fault_rate:.2f}%. "
        f"Recorded MTTR: {mttr:.1f} hours. "
        f"User load: {users} active users with {data_gb:.1f} GB data usage. "
        f"Jitter was {jitter:.1f} ms. Security incidents: {sec}, authentication failures: {auth_fail}."
    )
    return doc

def compute_deterministic_severity(row: pd.Series) -> str:
    """Calculates deterministic severity level: LOW, MEDIUM, HIGH, CRITICAL via analytics/prioritization."""
    from src.analytics.prioritization import calculate_deterministic_prioritization
    res = calculate_deterministic_prioritization(row)
    return res["severity"]

def prepare_application_dataset(
    max_records: Optional[int] = DEFAULT_MAX_RECORDS,
    output_path: str = DEFAULT_PROCESSED_PATH,
    force_download: bool = False
) -> pd.DataFrame:
    """
    End-to-end dataset preparation:
    1. Loads fenar/5g_netops via HF datasets (or cached raw CSV)
    2. Validates schema and types across 26 canonical fields
    3. Computes data-driven thresholds and persists to thresholds.json
    4. Computes calibrated severity and high_fault_risk percentile
    5. Generates rich semantic narratives
    6. Caches processed CSV
    """
    df = load_hf_dataset(max_records=max_records, force_download=force_download)

    # Impute numeric columns
    for col in NUMERIC_COLUMNS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            med = df[col].median()
            df[col] = df[col].fillna(med if not np.isnan(med) else 0.0)
        else:
            df[col] = 0.0

    # Categorical cleanup
    for col in CATEGORICAL_COLUMNS:
        if col in df.columns:
            df[col] = df[col].fillna("Unknown").astype(str)
        else:
            df[col] = "Unknown"

    # Compute and persist empirical thresholds
    thresholds = compute_and_save_thresholds(df)
    p75_fault = thresholds.get("high_fault_risk_cutoff", 48.28)

    # Derived features
    df["cell_load_index"] = (df["user_count"] * df["data_usage"] / 1000.0).round(2)
    df["alarm_severity_ratio"] = (df["critical_alarm_count"] / df["alarm_count"].replace(0, 1)).round(3)
    df["severity"] = df.apply(compute_deterministic_severity, axis=1)
    df["high_fault_risk"] = (df["fault_occurrence_rate"] >= p75_fault).astype(int)

    # Semantic incident document
    df["incident_document"] = df.apply(lambda r: build_incident_narrative(r, thresholds), axis=1)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df.to_csv(output_path, index=False)
    logger.info("Application dataset ready: %d records saved to %s", len(df), output_path)
    return df

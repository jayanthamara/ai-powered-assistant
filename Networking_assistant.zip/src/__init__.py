"""
NETPULSE AI Source Package.
Initializes sys.modules compatibility shim to support both 'src.*' and legacy 'backend.app.*' imports.
"""
import sys
from pathlib import Path

# Automatically ensure parent directory of src is on sys.path
_parent_dir = str(Path(__file__).resolve().parent.parent)
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)

# Aliasing backend.app to src for full backwards compatibility
_this_module = sys.modules[__name__]
sys.modules.setdefault("backend", _this_module)
sys.modules["backend.app"] = _this_module

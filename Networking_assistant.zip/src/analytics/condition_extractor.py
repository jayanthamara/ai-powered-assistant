"""
Natural-language network condition parser and structured entity extractor for NETPULSE AI.
Converts free-form operator queries into explicit numeric constraints, locations, and condition tags.
Extracts geographic entities using verified dataset vocabularies and word-boundary matching.
"""
import re
import os
from typing import Dict, Any, List, Optional, Set
import pandas as pd
from src.analytics.thresholds import load_thresholds

# Complete 59 state and territory codes verified in fenar/5g_netops
DATASET_STATE_CODES: Set[str] = {
    "AK", "AL", "AR", "AS", "AZ", "CA", "CO", "CT", "DC", "DE", "FL", "FM",
    "GA", "GU", "HI", "IA", "ID", "IL", "IN", "KS", "KY", "LA", "MA", "MD",
    "ME", "MH", "MI", "MN", "MO", "MP", "MS", "MT", "NC", "ND", "NE", "NH",
    "NJ", "NM", "NV", "NY", "OH", "OK", "OR", "PA", "PR", "PW", "RI", "SC",
    "SD", "TN", "TX", "UT", "VA", "VI", "VT", "WA", "WI", "WV", "WY"
}

DATASET_SEASONS = ["winter", "spring", "summer", "fall"]
DATASET_WEATHER = ["clear", "rain", "clouds", "snow"]

_cached_city_vocab: Optional[Set[str]] = None

def get_city_vocabulary() -> Set[str]:
    """Dynamically loads verified city names from processed dataset."""
    global _cached_city_vocab
    if _cached_city_vocab is not None:
        return _cached_city_vocab

    csv_path = "data/processed/telecom_incidents_processed.csv"
    if os.path.exists(csv_path):
        try:
            df = pd.read_csv(csv_path, usecols=["city"])
            _cached_city_vocab = set(df["city"].dropna().str.lower().unique())
            return _cached_city_vocab
        except Exception:
            pass

    _cached_city_vocab = set()
    return _cached_city_vocab

def extract_network_conditions(query: str) -> Dict[str, Any]:
    """
    Parses unstructured text into structured operational criteria using
    data-driven thresholds and dataset vocabularies with strict word-boundary matching.
    """
    q_lower = query.lower()
    thresh = load_thresholds().get("kpis", {})

    lat_p50 = thresh.get("latency", {}).get("p50", 77.4)
    lat_p75 = thresh.get("latency", {}).get("p75", 105.5)
    lat_p90 = thresh.get("latency", {}).get("p90", 130.3)

    loss_p50 = thresh.get("packet_loss_rate", {}).get("p50", 6.3)
    loss_p75 = thresh.get("packet_loss_rate", {}).get("p75", 9.4)
    loss_p90 = thresh.get("packet_loss_rate", {}).get("p90", 12.0)

    tp_p25 = thresh.get("throughput", {}).get("p25", 392.6)
    tp_p50 = thresh.get("throughput", {}).get("p50", 548.7)

    hosr_p25 = thresh.get("handover_success_rate", {}).get("p25", 92.5)
    hosr_p50 = thresh.get("handover_success_rate", {}).get("p50", 94.9)

    avail_p25 = thresh.get("cell_availability", {}).get("p25", 83.4)
    avail_p50 = thresh.get("cell_availability", {}).get("p50", 89.5)

    crit_p50 = thresh.get("critical_alarm_count", {}).get("p50", 6.8)
    crit_p75 = thresh.get("critical_alarm_count", {}).get("p75", 8.4)

    result: Dict[str, Any] = {
        "city": None,
        "state": None,
        "season": None,
        "weather": None,
        "conditions": [],
        "metrics": {}
    }

    # 1. State extraction with word boundaries
    state_match = re.search(r"\b(?:in|state)\s+([a-zA-Z]{2})\b", query, re.IGNORECASE)
    if state_match:
        cand_state = state_match.group(1).upper()
        if cand_state in DATASET_STATE_CODES:
            result["state"] = cand_state

    if not result["state"]:
        words = re.findall(r"\b[A-Za-z]{2}\b", query)
        for w in words:
            if w.upper() in DATASET_STATE_CODES and w.lower() not in {"in", "to", "on", "at", "by", "is", "it", "or", "an", "as", "if", "no", "we", "he", "me", "my", "us", "up", "so", "do", "go"}:
                result["state"] = w.upper()
                break

    # 2. City extraction with word boundaries against dataset vocabulary
    city_vocab = get_city_vocabulary()
    for city in city_vocab:
        if len(city) >= 4 and re.search(r"\b" + re.escape(city) + r"\b", q_lower):
            result["city"] = city.title()
            break

    # 3. Season extraction with strict word boundaries (no "fall" in "fallback")
    for s in DATASET_SEASONS:
        if re.search(r"\b" + s + r"\b", q_lower):
            result["season"] = s.capitalize()
            break

    # 4. Weather extraction with strict word boundaries
    for w in DATASET_WEATHER:
        if re.search(r"\b" + w + r"\b", q_lower):
            result["weather"] = w.capitalize()
            break

    # 5. Detect benign / normal operational state
    is_benign = any(b in q_lower for b in [
        "conditions are normal", "network conditions are normal", "conditions normal",
        "stable", "nominal", "healthy", "optimal", "baseline", "within sla", "all normal",
        "operating normally", "normal operation"
    ]) or ("normal" in q_lower and any(b in q_lower for b in ["good", "low packet loss", "high handover", "stable", "optimal"]))
    has_normal_lat = any(b in q_lower for b in ["normal latency", "low latency", "stable latency", "acceptable latency"])
    has_normal_loss = any(b in q_lower for b in ["normal packet loss", "low packet loss", "zero packet loss", "minimal packet loss"])
    has_normal_tp = any(b in q_lower for b in ["normal throughput", "high throughput", "good throughput", "stable throughput"])

    adverse_terms = [
        "high latency", "elevated latency", "severe latency", "critical latency",
        "high packet loss", "elevated packet loss", "severe packet loss", "critical packet loss",
        "reduced throughput", "low throughput", "throughput degradation",
        "declining handover", "handover failure", "poor handover",
        "critical alarm", "multiple alarms", "alarm count above",
        "call drop rate above", "high call drop", "dropped calls",
        "poor signal", "weak signal", "congestion", "outage", "failing"
    ]
    if is_benign and not any(a in q_lower for a in adverse_terms):
        result["conditions"].append("nominal_operations")
        result["metrics"]["latency"] = {"max": lat_p50, "is_explicit": False}
        result["metrics"]["packet_loss_rate"] = {"max": loss_p50, "is_explicit": False}
        result["metrics"]["throughput"] = {"min": tp_p50, "is_explicit": False}
        result["metrics"]["cell_availability"] = {"min": avail_p50, "is_explicit": False}
        result["metrics"]["critical_alarm_count"] = {"max": crit_p50, "is_explicit": False}
        result["metrics"]["handover_success_rate"] = {"min": hosr_p50, "is_explicit": False}
        result["metrics"]["call_drop_rate"] = {"max": 0.5, "is_explicit": False}
        return result

    # 6. Latency extraction
    lat_match = re.search(r"(?:latency\s*(?:above|>|over|exceeding|\:)?\s*(\d+(?:\.\d+)?)\s*(?:ms)?)|(?:(\d+(?:\.\d+)?)\s*ms\s*(?:latency)?)", q_lower)
    if lat_match:
        val = float(lat_match.group(1) or lat_match.group(2))
        result["metrics"]["latency"] = {"min": val, "val": val, "is_explicit": True}
        if val >= lat_p75:
            result["conditions"].append("high_latency")
    elif has_normal_lat:
        result["metrics"]["latency"] = {"max": lat_p50, "is_explicit": False}
    elif any(k in q_lower for k in ["extremely high latency", "severe latency", "critical latency", "latency is extremely high"]):
        result["metrics"]["latency"] = {"min": lat_p90, "is_explicit": False}
        result["conditions"].append("high_latency")
    elif any(k in q_lower for k in ["high latency", "elevated latency", "latency spike", "high delay"]):
        result["metrics"]["latency"] = {"min": lat_p75, "is_explicit": False}
        result["conditions"].append("high_latency")
    elif "latency" in q_lower and any(w in q_lower for w in ["issue", "problem", "degraded", "spike", "increasing"]):
        result["metrics"]["latency"] = {"min": lat_p75, "is_explicit": False}
        result["conditions"].append("high_latency")

    # 7. Packet Loss extraction
    pkt_match = re.search(r"(?:packet\s*loss\s*(?:rate)?\s*(?:above|>|over|exceeding|\:)?\s*(\d+(?:\.\d+)?)\s*%?)|(?:(\d+(?:\.\d+)?)\s*%\s*packet\s*loss)", q_lower)
    if pkt_match:
        val = float(pkt_match.group(1) or pkt_match.group(2))
        result["metrics"]["packet_loss_rate"] = {"min": val, "val": val, "is_explicit": True}
        if val >= 5.0 or val >= loss_p50:
            result["conditions"].append("high_packet_loss")
    elif has_normal_loss:
        result["metrics"]["packet_loss_rate"] = {"max": loss_p50, "is_explicit": False}
    elif any(k in q_lower for k in ["severe packet loss", "critical packet loss", "massive packet loss"]):
        result["metrics"]["packet_loss_rate"] = {"min": loss_p90, "is_explicit": False}
        result["conditions"].append("high_packet_loss")
    elif any(k in q_lower for k in ["high packet loss", "elevated packet loss", "packet loss spike", "packet loss"]):
        result["metrics"]["packet_loss_rate"] = {"min": loss_p75, "is_explicit": False}
        result["conditions"].append("high_packet_loss")

    # 8. Throughput extraction
    tp_match = re.search(r"throughput\s*(?:below|<|under|\:)?\s*(\d+(?:\.\d+)?)\s*(?:mbps)?", q_lower)
    if tp_match:
        val = float(tp_match.group(1))
        result["metrics"]["throughput"] = {"max": val, "val": val, "is_explicit": True}
        if val <= tp_p25:
            result["conditions"].append("low_throughput")
    elif has_normal_tp:
        result["metrics"]["throughput"] = {"min": tp_p50, "is_explicit": False}
    elif any(k in q_lower for k in ["low throughput", "reduced throughput", "throughput degradation", "throughput collapse"]):
        result["metrics"]["throughput"] = {"max": tp_p25, "is_explicit": False}
        result["conditions"].append("low_throughput")

    # 9. Handover extraction
    hosr_match = re.search(r"handover\s*(?:success)?\s*(?:rate)?\s*(?:below|<|under|\:)?\s*(\d+(?:\.\d+)?)\s*%?", q_lower)
    if hosr_match:
        val = float(hosr_match.group(1))
        result["metrics"]["handover_success_rate"] = {"max": val, "val": val, "is_explicit": True}
        if val <= hosr_p25:
            result["conditions"].append("low_handover_success")
    elif any(k in q_lower for k in ["handover failure", "declining handover", "handover drop", "handover issue", "poor handover"]):
        result["metrics"]["handover_success_rate"] = {"max": hosr_p25, "is_explicit": False}
        result["conditions"].append("low_handover_success")

    # 10. Call Drop Rate extraction
    cdr_match = re.search(r"call\s*drop\s*(?:rate)?\s*(?:above|>|over|\:)?\s*(\d+(?:\.\d+)?)\s*%?", q_lower)
    if cdr_match:
        val = float(cdr_match.group(1))
        result["metrics"]["call_drop_rate"] = {"min": val, "val": val, "is_explicit": True}
        result["conditions"].append("high_call_drop")
    elif any(k in q_lower for k in ["high call drop", "dropped calls", "call drops", "call drop rate"]):
        result["metrics"]["call_drop_rate"] = {"min": 1.7, "is_explicit": False}
        result["conditions"].append("high_call_drop")

    # 11. Alarm extraction
    alarm_match = re.search(r"(?:alarm|alarms)\s*(?:count)?\s*(?:above|>|over|\:)?\s*(\d+)", q_lower)
    if alarm_match:
        val = int(alarm_match.group(1))
        result["metrics"]["alarm_count"] = {"min": val, "val": val, "is_explicit": True}
        result["conditions"].append("high_alarms")
    elif any(k in q_lower for k in ["increasing alarms", "critical alarm", "high alarms", "alarms"]):
        result["metrics"]["critical_alarm_count"] = {"min": crit_p75, "is_explicit": False}
        result["conditions"].append("high_alarms")

    # 12. Cell Availability extraction
    avail_match = re.search(r"(?:cell\s*)?availability\s*(?:below|<|under|\:)?\s*(\d+(?:\.\d+)?)\s*%?", q_lower)
    if avail_match:
        val = float(avail_match.group(1))
        result["metrics"]["cell_availability"] = {"max": val, "val": val, "is_explicit": True}
        if val <= avail_p25:
            result["conditions"].append("availability_issue")
    elif any(k in q_lower for k in ["availability drop", "cell down", "outage", "availability"]):
        result["metrics"]["cell_availability"] = {"max": avail_p25, "is_explicit": False}
        result["conditions"].append("availability_issue")

    # 13. Signal Strength extraction
    ss_match = re.search(r"signal\s*strength\s*(?:below|<|under|\:)?\s*(-\d+(?:\.\d+)?)\s*(?:dbm)?", q_lower)
    if ss_match:
        val = float(ss_match.group(1))
        result["metrics"]["signal_strength"] = {"max": val, "val": val, "is_explicit": True}
        result["conditions"].append("poor_signal")
    elif any(k in q_lower for k in ["poor signal", "weak signal", "signal degradation", "low signal"]):
        result["metrics"]["signal_strength"] = {"max": -105.6, "is_explicit": False}
        result["conditions"].append("poor_signal")

    # 14. Congestion
    if any(k in q_lower for k in ["congestion", "prb saturation", "overloaded", "capacity exhaustion"]):
        result["conditions"].append("cell_congestion")

    # 15. Security
    if any(k in q_lower for k in ["security incident", "auth surge", "authentication failure", "auth failures", "unauthorized"]):
        result["conditions"].append("security_incident")

    return result

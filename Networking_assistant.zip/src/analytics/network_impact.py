"""
Network Impact Analysis module for NETPULSE AI.
Evaluates multi-dimensional operational degradation across RAN coverage areas, user QoE,
backhaul latency, call-retention, and infrastructure capacity.
Produces deterministic, explainable impact scores (0-100) and severity classifications.
"""
from typing import Dict, Any, List, Optional
import numpy as np
from src.analytics.thresholds import load_thresholds

class NetworkImpactAnalyzer:
    @staticmethod
    def analyze_impact(
        extracted_conditions: Dict[str, Any],
        historical_cases: List[Dict[str, Any]],
        parsed_metrics: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Calculates explainable network impact using observed/extracted telemetry
        and retrieved historical evidence without fabricating unobserved cell IDs.
        """
        conditions = extracted_conditions.get("conditions", [])
        city = extracted_conditions.get("city")
        state = extracted_conditions.get("state")
        region = f"{city}, {state}" if (city and state) else (city or state or "Metropolitan Sector Cluster")

        thresh = load_thresholds().get("kpis", {})
        lat_p50 = thresh.get("latency", {}).get("p50", 77.4)
        lat_p75 = thresh.get("latency", {}).get("p75", 105.5)
        lat_p90 = thresh.get("latency", {}).get("p90", 130.3)

        loss_p50 = thresh.get("packet_loss_rate", {}).get("p50", 6.3)
        loss_p75 = thresh.get("packet_loss_rate", {}).get("p75", 9.4)
        loss_p90 = thresh.get("packet_loss_rate", {}).get("p90", 12.0)

        tp_p25 = thresh.get("throughput", {}).get("p25", 392.6)
        tp_p50 = thresh.get("throughput", {}).get("p50", 548.7)

        hosr_p25 = thresh.get("handover_success_rate", {}).get("p25", 92.5)
        hosr_p50 = thresh.get("handover_success_rate", {}).get("p50", 94.9)

        crit_p50 = thresh.get("critical_alarm_count", {}).get("p50", 6.8)
        crit_p75 = thresh.get("critical_alarm_count", {}).get("p75", 8.4)
        crit_p90 = thresh.get("critical_alarm_count", {}).get("p90", 9.6)

        affected_metrics = []
        evidence = []
        impact_score = 10  # Baseline

        # Extract telemetry either from direct metrics or historical case average
        avg_metrics = {}
        if historical_cases:
            for k in ["latency", "packet_loss_rate", "throughput", "call_drop_rate", "handover_success_rate", "alarm_count", "critical_alarm_count", "user_count", "mttr"]:
                vals = [c.get("metrics", {}).get(k) for c in historical_cases if c.get("metrics", {}).get(k) is not None]
                if vals:
                    avg_metrics[k] = float(np.mean(vals))
        
        # Override with parsed explicit metrics if provided
        if parsed_metrics:
            for k, v in parsed_metrics.items():
                if isinstance(v, dict):
                    avg_metrics[k] = float(v.get("val", v.get("min", v.get("max", 0.0))))
                else:
                    avg_metrics[k] = float(v)

        # 1. Latency Impact
        lat = avg_metrics.get("latency", 0.0)
        if "high_latency" in conditions or lat >= lat_p75:
            weight = 24 if lat >= lat_p90 else 16
            impact_score += weight
            affected_metrics.append({
                "metric": "Latency",
                "value": f"{lat:.1f} ms" if lat else f"Elevated (>={lat_p75:.1f}ms)",
                "threshold": f"Median SLA {lat_p50:.1f} ms",
                "severity": "CRITICAL" if lat >= lat_p90 else "HIGH"
            })
            evidence.append(f"Transit latency reached {lat:.1f} ms (>= p75 threshold), increasing round-trip queueing delay.")

        # 2. Packet Loss Impact
        loss = avg_metrics.get("packet_loss_rate", 0.0)
        if "high_packet_loss" in conditions or loss >= loss_p75:
            weight = 26 if loss >= loss_p90 else 18
            impact_score += weight
            affected_metrics.append({
                "metric": "Packet Loss Rate",
                "value": f"{loss:.2f}%" if loss else f"Elevated (>={loss_p75:.2f}%)",
                "threshold": f"Median {loss_p50:.2f}%",
                "severity": "CRITICAL" if loss >= loss_p90 else "HIGH"
            })
            evidence.append(f"Transport/radio frame drop rate reached {loss:.2f}% (>= p75 threshold), degrading user session continuity.")

        # 3. Throughput Degradation
        tp = avg_metrics.get("throughput", 0.0)
        if "low_throughput" in conditions or (tp > 0 and tp <= tp_p25):
            weight = 18 if (tp > 0 and tp <= tp_p25 * 0.7) else 12
            impact_score += weight
            affected_metrics.append({
                "metric": "Throughput",
                "value": f"{tp:.1f} Mbps" if tp else f"Degraded (<={tp_p25:.1f} Mbps)",
                "threshold": f"Median {tp_p50:.1f} Mbps",
                "severity": "HIGH" if (tp > 0 and tp <= tp_p25 * 0.7) else "MEDIUM"
            })
            evidence.append(f"Downlink aggregate throughput dropped to {tp:.1f} Mbps (<= p25), causing bandwidth throttling.")

        # 4. Handover Degradation
        hosr = avg_metrics.get("handover_success_rate", 100.0)
        if "low_handover_success" in conditions or hosr <= hosr_p25:
            weight = 20 if hosr <= 85.0 else 12
            impact_score += weight
            affected_metrics.append({
                "metric": "Handover Success Rate",
                "value": f"{hosr:.1f}%" if hosr else f"Sub-nominal (<={hosr_p25:.1f}%)",
                "threshold": f"Target >={hosr_p50:.1f}%",
                "severity": "HIGH"
            })
            evidence.append(f"Inter-cell mobility handover success dropped to {hosr:.1f}%, increasing mobility drop probability.")

        # 5. Critical Alarms
        crit_alarms = avg_metrics.get("critical_alarm_count", 0.0)
        if "high_alarms" in conditions or crit_alarms >= crit_p75:
            weight = 15 if crit_alarms >= crit_p90 else 8
            impact_score += weight
            affected_metrics.append({
                "metric": "Critical Alarms",
                "value": f"{crit_alarms:.1f} active",
                "threshold": f"Median {crit_p50:.1f}",
                "severity": "CRITICAL" if crit_alarms >= crit_p90 else "HIGH"
            })
            evidence.append(f"Active critical alarms ({crit_alarms:.1f}) exceed the 75th percentile operational threshold.")

        impact_score = int(min(100, max(0, impact_score)))

        # Classification
        if impact_score >= 70:
            impact_level = "CRITICAL"
        elif impact_score >= 45:
            impact_level = "HIGH"
        elif impact_score >= 25:
            impact_level = "MEDIUM"
        else:
            impact_level = "LOW"

        # Data-derived affected coverage identifiers from retrieved cases (no invented cell tower IDs)
        affected_cells = []
        if historical_cases:
            for c in historical_cases[:3]:
                c_id = c.get("incident_id", "5G-NETOPS")
                c_city = c.get("location", {}).get("city") or c.get("city", "Sector")
                c_state = c.get("location", {}).get("state") or c.get("state", "")
                affected_cells.append(f"Coverage Sector: {c_city}, {c_state} [{c_id}]")
        else:
            affected_cells = [f"Coverage Sector: {region} [Active Cluster]"]

        # User population impact description
        users = avg_metrics.get("user_count")
        user_desc = f"~{int(users)} connected subscribers experiencing QoE degradation" if users else "Subscribers attached to affected macro/micro carriers"

        # Customer & Network Summaries
        customer_impact = (
            f"{user_desc}. Manifesting as elevated latency and packet drop "
            f"across {region}."
        )
        network_impact = (
            f"PRB utilization pressure and air-interface degradation across {region}. "
            f"Impact score calculated at {impact_score}/100 ({impact_level})."
        )

        # Historical MTTR observation
        mttr_vals = [float(c.get("metrics", {}).get("mttr", 0)) for c in historical_cases if c.get("metrics", {}).get("mttr")]
        historical_mttr_hours = round(float(np.mean(mttr_vals)), 1) if mttr_vals else round(float(avg_metrics.get("mttr", 5.2)), 1)

        return {
            "impact_score": impact_score,
            "impact_level": impact_level,
            "affected_region": region,
            "affected_cells": affected_cells,
            "affected_metrics": affected_metrics,
            "customer_impact": customer_impact,
            "network_impact": network_impact,
            "evidence": evidence,
            "historical_mttr_hours": historical_mttr_hours
        }

"""
Deterministic incident prioritization and severity engine for NETPULSE AI.
Calculates normalized multi-factor risk score (0-100) and severity categories with explicit rationale.
Calibrated to fenar/5g_netops operational distribution (LOW ~25%, MEDIUM ~35%, HIGH ~25%, CRITICAL ~15%).
"""
from typing import Dict, Any, List, Union
import numpy as np
import pandas as pd
from src.analytics.thresholds import load_thresholds

def calculate_deterministic_prioritization(metrics: Union[Dict[str, Any], pd.Series]) -> Dict[str, Any]:
    """
    Computes normalized operational severity score (0-100) and traceable factors
    calibrated against the fenar/5g_netops historical distribution.
    """
    if metrics is None:
        return {
            "risk_score": 0,
            "severity": "LOW",
            "factors": ["Insufficient operational telemetry to evaluate network risk"],
            "risk_factors": []
        }
    if isinstance(metrics, dict) and not metrics:
        return {
            "risk_score": 0,
            "severity": "LOW",
            "factors": ["Insufficient operational telemetry to evaluate network risk"],
            "risk_factors": []
        }
    if hasattr(metrics, "empty") and metrics.empty:
        return {
            "risk_score": 0,
            "severity": "LOW",
            "factors": ["Insufficient operational telemetry to evaluate network risk"],
            "risk_factors": []
        }

    # Helper getter that handles both dict and Series
    def get_val(key: str, default: float) -> float:
        try:
            v = metrics.get(key, default) if hasattr(metrics, "get") else metrics[key]
            if v is None or pd.isna(v):
                return default
            return float(v)
        except Exception:
            return default

    thresh = load_thresholds().get("kpis", {})

    crit_alarms = get_val("critical_alarm_count", 0.0)
    alarms = get_val("alarm_count", 0.0)
    lat = get_val("latency", 77.0)
    loss = get_val("packet_loss_rate", 6.0)
    cdr = get_val("call_drop_rate", 0.0)
    hosr = get_val("handover_success_rate", 95.0)
    avail = get_val("cell_availability", 90.0)
    tp = get_val("throughput", 550.0)
    ss = get_val("signal_strength", -90.0)
    fault_rate = get_val("fault_occurrence_rate", 38.0)
    sec_inc = get_val("security_incidents", 0.0)
    auth_fail = get_val("authentication_failures", 0.0)

    score = 0.0
    factors: List[str] = []
    risk_factors: List[Dict[str, Any]] = []

    # 1. Critical alarms (Weight: up to 20 pts)
    # Thresholds: p50=6.76, p75=8.42, p90=9.56
    c_alarm = 0.0
    if crit_alarms >= 9.5:
        c_alarm = 20.0
        factors.append(f"Severe critical alarm count ({crit_alarms:.1f} alarms >= p90)")
    elif crit_alarms >= 8.4:
        c_alarm = 14.0
        factors.append(f"Elevated critical alarm count ({crit_alarms:.1f} alarms >= p75)")
    elif crit_alarms >= 6.8:
        c_alarm = 7.0
        factors.append(f"Above-median critical alarms ({crit_alarms:.1f} alarms >= p50)")
    score += c_alarm
    if c_alarm > 0:
        risk_factors.append({"metric": "Critical Alarm Count", "value": round(crit_alarms, 1), "contribution": int(c_alarm)})

    # 2. Packet Loss (Weight: up to 20 pts)
    # Thresholds: p50=6.3, p75=9.4, p90=12.0
    c_loss = 0.0
    if loss >= 12.0:
        c_loss = 20.0
        factors.append(f"Critical packet drop rate ({loss:.2f}% >= p90)")
    elif loss >= 9.4:
        c_loss = 14.0
        factors.append(f"Severe packet drop rate ({loss:.2f}% >= p75)")
    elif loss >= 6.3:
        c_loss = 7.0
        factors.append(f"Elevated packet loss ({loss:.2f}% >= p50)")
    score += c_loss
    if c_loss > 0:
        risk_factors.append({"metric": "Packet Loss Rate", "value": round(loss, 2), "contribution": int(c_loss)})

    # 3. Latency (Weight: up to 15 pts)
    # Thresholds: p50=77.4, p75=105.5, p90=130.3
    c_lat = 0.0
    if lat >= 130.0:
        c_lat = 15.0
        factors.append(f"Latency exceeding p90 SLA threshold ({lat:.1f} ms)")
    elif lat >= 105.0:
        c_lat = 10.0
        factors.append(f"Elevated latency ({lat:.1f} ms >= p75)")
    elif lat >= 77.0:
        c_lat = 5.0
        factors.append(f"Above-median latency ({lat:.1f} ms >= p50)")
    score += c_lat
    if c_lat > 0:
        risk_factors.append({"metric": "Latency", "value": round(lat, 1), "contribution": int(c_lat)})

    # 4. Cell Availability (Weight: up to 15 pts - INVERSE)
    # Thresholds: p50=89.5, p25=83.5, p10=80.0
    c_avail = 0.0
    if avail < 80.0:
        c_avail = 15.0
        factors.append(f"Critical cell availability degradation ({avail:.1f}% < p10)")
    elif avail < 83.5:
        c_avail = 10.0
        factors.append(f"Severe cell availability impairment ({avail:.1f}% < p25)")
    elif avail < 89.5:
        c_avail = 5.0
        factors.append(f"Sub-median cell availability ({avail:.1f}% < p50)")
    score += c_avail
    if c_avail > 0:
        risk_factors.append({"metric": "Cell Availability", "value": round(avail, 1), "contribution": int(c_avail)})

    # 5. Handover Success Rate (Weight: up to 10 pts - INVERSE)
    # Thresholds: p50=94.9, p25=92.5, p10=90.0
    c_hosr = 0.0
    if hosr < 90.0:
        c_hosr = 10.0
        factors.append(f"Severe mobility handover degradation ({hosr:.1f}% < p10)")
    elif hosr < 92.5:
        c_hosr = 7.0
        factors.append(f"Sub-optimal mobility handover ({hosr:.1f}% < p25)")
    elif hosr < 95.0:
        c_hosr = 3.0
        factors.append(f"Minor handover variance ({hosr:.1f}% < p50)")
    score += c_hosr
    if c_hosr > 0:
        risk_factors.append({"metric": "Handover Success Rate", "value": round(hosr, 1), "contribution": int(c_hosr)})

    # 6. Call Drop Rate (Weight: up to 10 pts)
    # Thresholds: p75=1.68, p90=3.13
    c_cdr = 0.0
    if cdr >= 3.1:
        c_cdr = 10.0
        factors.append(f"Critical call drop rate ({cdr:.2f}% >= p90)")
    elif cdr >= 1.7:
        c_cdr = 6.0
        factors.append(f"Elevated call drop rate ({cdr:.2f}% >= p75)")
    elif cdr > 0.0:
        c_cdr = 2.0
        factors.append(f"Call drop detected ({cdr:.2f}%)")
    score += c_cdr
    if c_cdr > 0:
        risk_factors.append({"metric": "Call Drop Rate", "value": round(cdr, 2), "contribution": int(c_cdr)})

    # 7. Fault Occurrence Rate (Weight: up to 10 pts)
    # Thresholds: p50=39.7, p75=48.3, p90=55.8
    c_fault = 0.0
    if fault_rate >= 55.8:
        c_fault = 10.0
        factors.append(f"Critical fault occurrence rate ({fault_rate:.1f}% >= p90)")
    elif fault_rate >= 48.3:
        c_fault = 6.0
        factors.append(f"High fault occurrence rate ({fault_rate:.1f}% >= p75)")
    elif fault_rate >= 39.7:
        c_fault = 3.0
        factors.append(f"Above-median fault rate ({fault_rate:.1f}% >= p50)")
    score += c_fault
    if c_fault > 0:
        risk_factors.append({"metric": "Fault Occurrence Rate", "value": round(fault_rate, 1), "contribution": int(c_fault)})

    # Optional radio signal & security anomalies bonus
    if ss < -105.6:
        score += 5.0
        factors.append(f"Severe radio attenuation ({ss:.1f} dBm <= p25)")
    if sec_inc >= 3 or auth_fail >= 10:
        score += 5.0
        factors.append(f"Security anomalies detected ({int(sec_inc)} incidents, {int(auth_fail)} auth failures)")

    final_score = int(min(100.0, max(0.0, round(score))))

    # Calibrated severity thresholds:
    # 0-20  -> LOW (~26%)
    # 21-35 -> MEDIUM (~33%)
    # 36-53 -> HIGH (~25%)
    # 54+   -> CRITICAL (~16%)
    if final_score >= 54:
        severity = "CRITICAL"
    elif final_score >= 36:
        severity = "HIGH"
    elif final_score >= 21:
        severity = "MEDIUM"
    else:
        severity = "LOW"

    if not factors:
        factors.append("Nominal operational telemetry within baseline 5G parameters")

    return {
        "risk_score": final_score,
        "severity": severity,
        "factors": factors,
        "risk_factors": risk_factors
    }

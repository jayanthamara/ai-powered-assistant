"""
Centralized data-driven KPI thresholds module for NETPULSE AI.
Loads percentiles (p25, p50, p75, p90) computed from the official fenar/5g_netops dataset.
Guarantees consistent thresholds across classifier, impact, analyst, and prioritization modules.
"""
import os
import json
import logging
from typing import Dict, Any

logger = logging.getLogger("thresholds")

DEFAULT_THRESHOLDS_PATH = "data/processed/thresholds.json"

# Default fallback thresholds derived from 10,000-row seeded sample of fenar/5g_netops
DEFAULT_THRESHOLDS: Dict[str, Any] = {
    "kpis": {
        "latency": {"p25": 49.58, "p50": 77.39, "p75": 105.47, "p90": 130.33, "mean": 77.58, "std": 32.22},
        "throughput": {"p25": 392.62, "p50": 548.68, "p75": 743.65, "p90": 935.39, "mean": 570.61, "std": 209.68},
        "packet_loss_rate": {"p25": 3.19, "p50": 6.30, "p75": 9.44, "p90": 12.03, "mean": 6.36, "std": 3.65},
        "call_drop_rate": {"p25": 0.00, "p50": 0.00, "p75": 1.68, "p90": 3.13, "mean": 0.98, "std": 1.34},
        "handover_success_rate": {"p25": 92.46, "p50": 94.93, "p75": 97.49, "p90": 99.02, "mean": 94.94, "std": 3.01},
        "cell_availability": {"p25": 83.42, "p50": 89.55, "p75": 95.74, "p90": 99.00, "mean": 89.47, "std": 7.15},
        "alarm_count": {"p25": 8.0, "p50": 10.0, "p75": 12.0, "p90": 14.0, "mean": 10.02, "std": 2.58},
        "critical_alarm_count": {"p25": 4.58, "p50": 6.76, "p75": 8.42, "p90": 9.56, "mean": 6.54, "std": 2.37},
        "signal_strength": {"p25": -105.62, "p50": -90.33, "p75": -75.10, "p90": -66.03, "mean": -90.31, "std": 17.65},
        "jitter": {"p25": 12.65, "p50": 25.26, "p75": 37.47, "p90": 44.78, "mean": 25.13, "std": 14.40},
        "fault_occurrence_rate": {"p25": 28.34, "p50": 39.69, "p75": 48.28, "p90": 55.75, "mean": 38.31, "std": 14.09},
        "mttr": {"p25": 2.84, "p50": 5.22, "p75": 7.57, "p90": 9.06, "mean": 5.23, "std": 2.74},
        "data_usage": {"p25": 12.72, "p50": 24.84, "p75": 37.54, "p90": 45.07, "mean": 25.08, "std": 14.39},
        "user_count": {"p25": 2617.0, "p50": 5061.5, "p75": 7457.5, "p90": 8995.3, "mean": 5054.6, "std": 2776.4}
    },
    "severity_cutoffs": {
        "LOW_MAX": 20,
        "MEDIUM_MAX": 35,
        "HIGH_MAX": 53,
        "CRITICAL_MIN": 54
    },
    "high_fault_risk_cutoff": 48.28  # 75th percentile of fault_occurrence_rate (%)
}

_cached_thresholds: Dict[str, Any] = None

def load_thresholds(file_path: str = DEFAULT_THRESHOLDS_PATH) -> Dict[str, Any]:
    """Loads KPI thresholds from disk or falls back to data-calibrated defaults."""
    global _cached_thresholds
    if _cached_thresholds is not None:
        return _cached_thresholds

    if os.path.exists(file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                _cached_thresholds = json.load(f)
                return _cached_thresholds
        except Exception as e:
            logger.warning("Could not read thresholds from %s: %s. Using default thresholds.", file_path, e)

    _cached_thresholds = DEFAULT_THRESHOLDS
    return _cached_thresholds

def get_kpi_threshold(kpi: str, level: str = "p75", default: float = 0.0) -> float:
    """Convenience getter for a KPI threshold percentile value."""
    thresh = load_thresholds()
    kpi_dict = thresh.get("kpis", {}).get(kpi, {})
    return float(kpi_dict.get(level, default))

def save_thresholds(thresholds_data: Dict[str, Any], file_path: str = DEFAULT_THRESHOLDS_PATH) -> None:
    """Persists computed thresholds to JSON."""
    global _cached_thresholds
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(thresholds_data, f, indent=2)
    _cached_thresholds = thresholds_data
    logger.info("Saved data-driven thresholds to %s", file_path)

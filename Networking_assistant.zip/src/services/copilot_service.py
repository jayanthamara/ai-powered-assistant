"""
Copilot Service for NETPULSE AI.
Implements the telecom-specialized Copilot orchestration layer with strict scope enforcement,
evidence relevance gating, context-aware follow-up memory, and structured logging.
"""
import uuid
import json
import logging
from typing import Dict, Any, Optional, List, Tuple
import pandas as pd


from src.agents.copilot_router import (
    CopilotIntentRouter, CopilotRoutingResult,
    INTENT_GREETING, INTENT_CAPABILITIES, INTENT_TELECOM_CONCEPT,
    INTENT_INCIDENT_INVESTIGATION, INTENT_HISTORICAL_SEARCH, INTENT_RISK_ANALYSIS,
    INTENT_ROOT_CAUSE_ANALYSIS, INTENT_NETWORK_IMPACT, INTENT_PERFORMANCE_PREDICTION,
    INTENT_RECOMMENDATION, INTENT_FOLLOW_UP, INTENT_DATASET_QUERY,
    INTENT_OUT_OF_SCOPE, INTENT_CLARIFICATION_REQUIRED
)
from src.schemas.api_schemas import (
    CopilotRequest, CopilotResponse, CopilotRoutingSchema
)
from src.agents.orchestrator import MultiAgentOrchestrator
from src.rag.hybrid_search import HybridSearchEngine
from src.agents.risk_analyst import RiskAnalystAgent
from src.agents.root_cause_analyst import RootCauseAnalystAgent
from src.agents.recommendation_agent import RecommendationEngineAgent
from src.analytics.network_impact import NetworkImpactAnalyzer
from src.analytics.condition_extractor import extract_network_conditions
from src.ml.performance_model import MLPerformanceService

logger = logging.getLogger("copilot_service")

# Comprehensive telecom concept knowledge base for grounded, deterministic explanations
TELECOM_CONCEPTS_KB = {
    "packet loss": (
        "Packet loss is the percentage of transmitted data packets that fail to reach their destination. "
        "In telecom networks, elevated packet loss degrades throughput, increases round-trip latency, triggers TCP "
        "retransmissions, and severely impacts real-time voice (VoLTE) and streaming services."
    ),
    "latency": (
        "Latency is the time delay required for a data packet to travel from a user device (UE) to the network core "
        "or destination server and back (round-trip time). High latency causes perceived buffering, delayed call setup, "
        "and degraded interactive application performance."
    ),
    "mttr": (
        "MTTR (Mean Time to Resolve / Repair) represents the average duration required by the NOC and field engineering teams "
        "to detect, diagnose, troubleshoot, and restore service following a telecom incident or cell outage. It is a core SLA metric."
    ),
    "call drop rate": (
        "Call Drop Rate (CDR) is the percentage of successfully established voice calls that are terminated prematurely due to "
        "radio link failures, handover drops, or core signaling timeouts. High CDR indicates severe air-interface degradation."
    ),
    "handover success rate": (
        "Handover Success Rate (HOSR) measures the percentage of seamless user session transfers between adjacent cells or sectors "
        "without connection interruption. Low HOSR leads to call drops, momentary data stalling, and poor mobile mobility."
    ),
    "ran congestion": (
        "Radio Access Network (RAN) congestion occurs when user traffic demand exceeds available Physical Resource Blocks (PRBs) "
        "or scheduler capacity at a cell tower, resulting in queued packets, throttled throughput, and elevated latency."
    ),
    "signal strength": (
        "Signal strength represents the received RF power at the antenna or user equipment, typically quantified via RSRP (Reference "
        "Signal Received Power) in dBm. Poor signal strength (e.g., below -110 dBm) induces modulation degradation and link drops."
    ),
    "throughput": (
        "Throughput is the actual volume of payload data successfully transmitted over the network per second (measured in Mbps or Gbps). "
        "It is constrained by spectral efficiency, modulation schemes, carrier bandwidth, and radio channel quality."
    ),
    "jitter": (
        "Jitter is the statistical variation in packet transit delay over time. In telecom networks, high jitter disrupts real-time "
        "audio/video streams, forcing jitter-buffer overflows or packet discards."
    ),
    "cell availability": (
        "Cell Availability measures the percentage of time a cell's radio transceiver equipment is fully operational and capable of "
        "providing radio access to subscribers. Downtime directly impairs network coverage and capacity SLAs."
    ),
    "critical alarm": (
        "A Critical Alarm indicates an acute network fault—such as transceiver hardware failure, fiber backhaul loss, or power disruption—"
        "that causes immediate service outage or severe degradation requiring urgent operational intervention."
    ),
    "authentication failure": (
        "Authentication failure occurs when a subscriber device cannot successfully authenticate against the Core Network (HSS/UDM/AMF), "
        "often caused by SIM profile mismatches, authentication vector timeouts, or security anomaly surges."
    ),
    "rsrp": (
        "RSRP (Reference Signal Received Power) measures the average received power across resource elements carrying cell-specific reference "
        "signals in LTE/5G. Values above -85 dBm indicate excellent coverage, while values below -115 dBm represent poor coverage."
    ),
    "rsrq": (
        "RSRQ (Reference Signal Received Quality) reflects the ratio of signal power to total received interference and thermal noise, "
        "indicating channel quality and interference levels across the cell."
    ),
    "sinr": (
        "SINR (Signal-to-Interference-plus-Noise Ratio) measures the desired RF signal power relative to interference and noise. Higher SINR "
        "enables higher-order modulation schemes (e.g. 256-QAM) and maximum throughput."
    ),
    "gnodeb": (
        "A gNodeB (gNB) is the 5G New Radio (NR) base station responsible for transmitting and receiving radio signals to and from user equipment (UE), "
        "managing radio resource control, packet scheduling, and backhaul transmission."
    ),
    "enodeb": (
        "An eNodeB (eNB) is the 4G LTE base station that handles radio transmission, handover coordination, and data ciphering in E-UTRAN networks."
    ),
    "beamforming": (
        "Beamforming is an advanced antenna technique that uses phase arrays to focus RF signals directionally toward individual user devices, "
        "increasing received signal gain, extending range, and minimizing inter-cell interference in 5G networks."
    ),
    "mimo": (
        "MIMO (Multiple-Input Multiple-Output) utilizes multiple transmit and receive antennas to multiplex separate spatial data streams, "
        "multiplying capacity and spectral efficiency without requiring additional radio spectrum."
    ),
    "backhaul": (
        "Backhaul refers to the intermediate transport network (microwave links or optical fiber) connecting distributed cell towers to the central "
        "telecom core network."
    )
}

ENVIRONMENTAL_TELECOM_EXPLANATIONS = {
    "monsoon": (
        "Monsoon conditions directly degrade telecom network operations through several physical and operational mechanisms:\n\n"
        "1. **Rain Fade & RF Attenuation**: Precipitation droplets scatter and absorb high-frequency radio waves, particularly impacting "
        "microwave backhaul links and mid/high-band 5G/LTE radio carriers.\n"
        "2. **Physical Antenna Stress**: Severe wind shear and water ingress can displace antenna mechanical tilt or cause moisture ingress into coaxial connectors.\n"
        "3. **Power Grid Instability**: Storm-induced power outages shift cell towers to battery backup and diesel generators, triggering auxiliary alarms.\n"
        "4. **Traffic Surges**: Severe weather confines subscribers indoors, concentrating mobile data demand and causing localized cell congestion.\n\n"
        "In the NETPULSE historical corpus, monsoon records reflect heightened latency, elevated packet loss, and higher fault occurrence rates during heavy rain events."
    ),
    "temperature": (
        "Ambient temperature extremes directly affect telecom infrastructure:\n\n"
        "1. **Thermal Throttling**: Extreme heat causes baseband units and remote radio heads (RRHs) to throttle transmission power to protect power amplifiers.\n"
        "2. **Air Conditioning Failure**: Shelter cooling faults trigger critical temperature alarms and thermal shutdowns.\n"
        "3. **Battery Degradation**: High temperatures rapidly shorten battery backup life and induce voltage instabilities.\n\n"
        "In the NETPULSE dataset, high-temperature events in summer correlate with cell hardware failures and degraded availability."
    ),
    "weather": (
        "Weather phenomena (storms, extreme heat, precipitation, fog) affect wireless propagation paths and tower physical infrastructure, "
        "increasing path loss, inducing microwave link fades, and triggering environmental alarms."
    )
}


class CopilotService:
    """
    Core service coordinating the Copilot dialog lifecycle.
    """

    def __init__(
        self,
        orchestrator: MultiAgentOrchestrator,
        search_engine: HybridSearchEngine,
        risk_analyst: RiskAnalystAgent,
        performance_service: MLPerformanceService,
        df: pd.DataFrame
    ):
        self.orchestrator = orchestrator
        self.search_engine = search_engine
        self.risk_analyst = risk_analyst
        self.performance_service = performance_service
        self.df = df
        # In-memory session store for active investigation context
        self._sessions: Dict[str, Dict[str, Any]] = {}

    def handle_message(
        self,
        query: str,
        session_id: Optional[str] = None,
        investigation_context: Optional[Dict[str, Any]] = None,
        telemetry: Optional[Dict[str, Any]] = None,
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = 5
    ) -> CopilotResponse:
        request_id = f"COP-{uuid.uuid4().hex[:8].upper()}"
        sid = session_id or "default_session"

        # 1. Resolve Active Investigation Context
        active_context = investigation_context or self._sessions.get(sid)

        # 2. Scope & Intent Routing
        routing_res: CopilotRoutingResult = CopilotIntentRouter.route(
            query=query,
            active_context=active_context
        )

        intent = routing_res.intent
        scope = routing_res.scope

        # Flags for logging and evidence gating
        retrieval_used = False
        risk_model_used = False
        workflow_selected = intent
        response_mode = "CONVERSATIONAL"

        # Result containers
        bot_message = ""
        res_incident = None
        res_risk = None
        res_root_causes = None
        res_impact = None
        res_predictions = None
        res_recommendations = None
        res_similar_cases = None
        updated_context = active_context

        # =========================================================================
        # WORKFLOW EXECUTION BASED ON INTENT
        # =========================================================================

        # CASE 1: OUT OF SCOPE (MANDATORY GATE BEFORE ANY RAG / ML)
        if scope == "OUT_OF_SCOPE" or intent == INTENT_OUT_OF_SCOPE:
            response_mode = "OUT_OF_SCOPE"
            workflow_selected = "SCOPE_GATE_REJECTION"
            bot_message = (
                "That topic is outside my telecom network operations scope. "
                "I can help with telecom concepts, network incidents, RAN metrics, historical cases, "
                "network risk, root-cause analysis, network impact, performance prediction, and troubleshooting recommendations."
            )
            # Evidence Relevance Gate: strictly discard all operational fields
            res_incident = None
            res_risk = None
            res_root_causes = None
            res_impact = None
            res_predictions = None
            res_recommendations = None
            res_similar_cases = None

        # CASE 2: CLARIFICATION REQUIRED (Confidence < 0.50 or ambiguous query)
        elif intent == INTENT_CLARIFICATION_REQUIRED:
            response_mode = "CLARIFICATION"
            workflow_selected = "CLARIFICATION_PROMPT"
            bot_message = routing_res.clarification_prompt or (
                "Could you tell me what network issue you're seeing? "
                "For example, high latency, packet loss, call drops, poor signal, alarms, reduced throughput, or handover degradation."
            )

        # CASE 3: GREETING
        elif intent == INTENT_GREETING:
            response_mode = "CONVERSATIONAL"
            workflow_selected = "CONVERSATIONAL_GREETING"
            q_clean = query.lower().strip()
            if any(t in q_clean for t in ["thanks", "thank you", "thx"]):
                bot_message = (
                    "You're welcome! Let me know if you need to investigate any cell incidents, "
                    "analyze risk scores, or search historical cases."
                )
            else:
                bot_message = (
                    "Hello! I'm NETPULSE AI, your telecom network operations copilot. "
                    "I can help investigate network incidents, analyze network risk, find similar historical cases, "
                    "identify root causes, and recommend corrective actions."
                )

        # CASE 4: CAPABILITIES
        elif intent == INTENT_CAPABILITIES:
            response_mode = "CAPABILITIES"
            workflow_selected = "CAPABILITY_OVERVIEW"
            bot_message = (
                "I am **NETPULSE AI**, a specialized Telecom Network Operations Copilot designed for 5G/LTE NOC teams. "
                "My integrated capabilities include:\n\n"
                "• **Incident Investigation**: End-to-end multi-agent triage of RAN degradation, anomalies, and critical alarms.\n"
                "• **Hybrid Retrieval**: Dense vector and BM25 historical incident search across 1,800+ telecom cases.\n"
                "• **RAN Metric Analysis**: Telemetry evaluation across latency, packet loss, throughput, call drop rate, and handover success.\n"
                "• **Incident Classification & Severity**: Operational categorization and severity determination.\n"
                "• **Risk Prediction**: Dual-engine fault risk scoring combining deterministic rules and trained ML models.\n"
                "• **Probable Root-Cause Analysis (RCA)**: Multi-factor root-cause attribution grounded in telemetry evidence.\n"
                "• **Network Impact Assessment**: Quantification of customer impact, affected metrics, and blast radius.\n"
                "• **KPI Performance Prediction**: Random Forest KPI estimation under observed operating conditions.\n"
                "• **Troubleshooting Recommendations**: Grounded, non-destructive remediation action plans.\n"
                "• **Historical Precedent Comparison**: Metric-level similarity matching against resolved historical incidents.\n"
                "• **Evaluation & Grounding**: LLM-as-a-judge validation ensuring factual, hallucination-free guidance."
            )

        # CASE 5: TELECOM CONCEPT
        elif intent == INTENT_TELECOM_CONCEPT:
            response_mode = "TELECOM_CONCEPT"
            workflow_selected = "CONCEPT_EXPLANATION"
            bot_message = self._explain_telecom_concept(query)

        # CASE 6: FOLLOW-UP CONTEXT
        elif intent == INTENT_FOLLOW_UP and active_context:
            response_mode, bot_message, res_data = self._handle_follow_up(query, active_context)
            if "similar_cases" in res_data:
                res_similar_cases = res_data["similar_cases"]
                retrieval_used = True
            if "risk" in res_data:
                res_risk = res_data["risk"]
                risk_model_used = True
            if "recommendations" in res_data:
                res_recommendations = res_data["recommendations"]
            if "root_causes" in res_data:
                res_root_causes = res_data["root_causes"]

        # CASE 7: HISTORICAL SEARCH
        elif intent == INTENT_HISTORICAL_SEARCH:
            response_mode = "RETRIEVAL"
            workflow_selected = "HYBRID_RETRIEVAL"
            retrieval_used = True
            parsed_cond = extract_network_conditions(query)
            results = self.search_engine.search(
                query=query,
                filters=filters or {},
                extracted_metrics=parsed_cond.get("metrics", {}),
                extracted_location={"city": parsed_cond.get("city"), "state": parsed_cond.get("state")},
                top_k=top_k
            )
            res_similar_cases = results
            
            top_cases_summary = []
            for c in results[:3]:
                top_cases_summary.append(
                    f"• **{c['incident_id']}** ({c['location']['city']}, {c['issue_reported']}) — "
                    f"Similarity: {int(c['similarity_score'] * 100)}% | Severity: {c['severity']} | "
                    f"Outcome: {c['historical_outcome']}"
                )
            
            bot_message = (
                f"Retrieved **{len(results)} historical incidents** matching your search criteria:\n\n"
                + "\n".join(top_cases_summary) +
                "\n\nYou can ask about any specific case (e.g., 'Why is NET-9007 similar?') or view full details in Historical Cases."
            )

        # CASE 8: RISK ANALYSIS
        elif intent == INTENT_RISK_ANALYSIS:
            response_mode = "RISK"
            workflow_selected = "RISK_ENGINE"
            risk_model_used = True
            
            # Use active telemetry or parsed metrics
            target_telemetry = telemetry or (active_context.get("metrics") if active_context else None)
            if not target_telemetry:
                parsed_cond = extract_network_conditions(query)
                metrics_dict = {}
                for k, v in parsed_cond.get("metrics", {}).items():
                    metrics_dict[k] = v.get("val", v.get("min", 0.0))
                target_telemetry = metrics_dict

            if target_telemetry:
                risk_res = self.risk_analyst.analyze_risk(target_telemetry)
                res_risk = risk_res
                factors_str = ", ".join(risk_res.get("factors", ["Elevated telemetry variances"]))
                bot_message = (
                    f"**Operational Risk Assessment**: Evaluated fault risk is **{risk_res['score']}/100 ({risk_res['level']} RISK)**.\n\n"
                    f"**Key Risk Drivers**: {factors_str}."
                )
            else:
                bot_message = (
                    "To assess operational risk, please provide telemetry indicators or specify an incident "
                    "(e.g. 'Assess risk for latency above 120ms and packet loss 6%')."
                )

        # CASE 9: ROOT CAUSE ANALYSIS
        elif intent == INTENT_ROOT_CAUSE_ANALYSIS:
            response_mode = "ROOT_CAUSE"
            workflow_selected = "RCA_ANALYSIS"
            target_telemetry = telemetry or (active_context.get("metrics") if active_context else {})
            parsed_cond = extract_network_conditions(query)
            rcs = RootCauseAnalystAgent.analyze_root_causes(
                telemetry=target_telemetry,
                historical_cases=active_context.get("similar_cases", []) if active_context else [],
                conditions=parsed_cond.get("conditions", [])
            )
            res_root_causes = rcs
            if rcs:
                top_rc = rcs[0]
                ev_str = ", ".join(top_rc.get("evidence", []))
                bot_message = (
                    f"**Probable Root Cause**: Analysis identifies **{top_rc['root_cause']}** as the most likely trigger "
                    f"(Likelihood: **{top_rc['likelihood']}**, confidence score: {top_rc['likelihood_score']}%).\n\n"
                    f"**Observed Evidence**: {ev_str}."
                )
            else:
                bot_message = "Root cause analysis indicates operating metrics are within normal variance thresholds."

        # CASE 10: NETWORK IMPACT
        elif intent == INTENT_NETWORK_IMPACT:
            response_mode = "NETWORK_IMPACT"
            workflow_selected = "IMPACT_ANALYSIS"
            target_telemetry = telemetry or (active_context.get("metrics") if active_context else {})
            parsed_cond = extract_network_conditions(query)
            impact = NetworkImpactAnalyzer.analyze_impact(
                parsed_conditions=parsed_cond,
                historical_cases=active_context.get("similar_cases", []) if active_context else [],
                parsed_metrics=target_telemetry
            )
            res_impact = impact
            bot_message = (
                f"**Network Impact Assessment**: Impact score is rated at **{impact['impact_score']}/100 ({impact['impact_level']} IMPACT)** "
                f"for region **{impact['affected_region']}**.\n\n"
                f"• **Customer Impact**: {impact['customer_impact']}\n"
                f"• **Network Impact**: {impact['network_impact']}"
            )

        # CASE 11: PERFORMANCE PREDICTION
        elif intent == INTENT_PERFORMANCE_PREDICTION:
            response_mode = "PREDICTION"
            workflow_selected = "ML_PREDICTION"
            target_telemetry = telemetry or (active_context.get("metrics") if active_context else {})
            preds = self.performance_service.predict_performance(target_telemetry)
            res_predictions = preds
            bot_message = (
                f"**Performance KPI Predictions** (Random Forest ML Models):\n\n"
                f"• **Predicted Throughput**: {preds.get('predicted_throughput_mbps', 'N/A')} Mbps\n"
                f"• **Predicted Latency**: {preds.get('predicted_latency_ms', 'N/A')} ms\n"
                f"• **Predicted Packet Loss**: {preds.get('predicted_packet_loss_rate', 'N/A')}%\n"
                f"• **Predicted Handover Success**: {preds.get('predicted_handover_success_rate', 'N/A')}%\n"
                f"• **Predicted Fault Occurrence**: {preds.get('predicted_fault_occurrence_rate', 'N/A')}\n\n"
                f"*Confidence*: {int(preds.get('confidence', 0.8) * 100)}% (Note: Values are model predictions based on current conditions)."
            )

        # CASE 12: RECOMMENDATION
        elif intent == INTENT_RECOMMENDATION:
            response_mode = "RECOMMENDATION"
            workflow_selected = "RECOMMENDATION_ENGINE"
            target_telemetry = telemetry or (active_context.get("metrics") if active_context else {})
            rcs = active_context.get("root_causes", []) if active_context else []
            recs = RecommendationEngineAgent.generate_recommendations(
                root_causes=rcs,
                historical_cases=active_context.get("similar_cases", []) if active_context else [],
                telemetry=target_telemetry,
                incident_type=active_context.get("incident_type", "Network Degradation") if active_context else "Network Degradation"
            )
            res_recommendations = recs
            rec_lines = [f"{i+1}. **{r['action']}** [{r['priority']} Priority]: {r['reason']}" for i, r in enumerate(recs[:3])]
            bot_message = (
                "**Recommended Troubleshooting Actions**:\n\n" + "\n".join(rec_lines)
            )

        # CASE 13: DATASET QUERY
        elif intent == INTENT_DATASET_QUERY:
            response_mode = "DATASET_QUERY"
            workflow_selected = "CORPUS_STATISTICS"
            total_records = len(self.df)
            top_cities = ", ".join(self.df["city"].value_counts().head(5).index.tolist())
            avg_lat = round(float(self.df["latency"].mean()), 1)
            avg_loss = round(float(self.df["packet_loss_rate"].mean()), 2)
            bot_message = (
                f"**NETPULSE Corpus Statistics**:\n\n"
                f"• **Total Indexed Incident Records**: {total_records}\n"
                f"• **Covered Metropolitan Regions**: {top_cities}\n"
                f"• **Fleet Average Latency**: {avg_lat} ms\n"
                f"• **Fleet Average Packet Loss**: {avg_loss}%\n"
                f"• **Active ML Risk & Prediction Models**: Random Forest Classifiers & Regressors operational."
            )

        # CASE 14: INCIDENT INVESTIGATION (Runs full multi-agent diagnostic pipeline)
        else:
            response_mode = "INVESTIGATION"
            workflow_selected = "FULL_INVESTIGATION_PIPELINE"
            retrieval_used = True
            risk_model_used = True

            inv_res = self.orchestrator.process_investigation(
                query=query,
                filters=filters,
                direct_metrics=telemetry,
                top_k=top_k
            )

            if not inv_res.get("success", False):
                response_mode = "OUT_OF_SCOPE"
                bot_message = (
                    "That query does not appear to describe an operational telecom incident or network condition. "
                    "Please provide specific network symptoms such as high latency, packet loss, or city location."
                )
            else:
                bot_message = inv_res.get("diagnosis") or "Investigation completed successfully."
                res_incident = inv_res.get("incident")
                res_risk = inv_res.get("risk")
                res_root_causes = inv_res.get("root_causes")
                res_impact = inv_res.get("network_impact")
                res_predictions = inv_res.get("prediction")
                res_recommendations = inv_res.get("recommendations")
                res_similar_cases = inv_res.get("similar_cases")

                # Build updated active investigation context
                updated_context = {
                    "investigation_id": f"INV-{uuid.uuid4().hex[:8].upper()}",
                    "user_query": query,
                    "incident_type": inv_res["incident"]["type"],
                    "severity": inv_res["incident"]["severity"],
                    "location": inv_res["network_impact"].get("affected_region", "Metropolitan RAN cluster"),
                    "metrics": inv_res["network_analysis"].get("current_metrics", {}),
                    "risk_score": inv_res["risk"]["score"],
                    "risk_level": inv_res["risk"]["level"],
                    "risk_factors": inv_res["risk"].get("factors", []),
                    "root_causes": inv_res.get("root_causes", []),
                    "network_impact": inv_res.get("network_impact", {}),
                    "similar_cases": inv_res.get("similar_cases", []),
                    "predictions": inv_res.get("prediction", {}),
                    "recommendations": inv_res.get("recommendations", [])
                }
                self._sessions[sid] = updated_context

        # =========================================================================
        # STRUCTURED ROUTING LOG (Section 29)
        # =========================================================================
        copilot_log = {
            "request_id": request_id,
            "user_query": query,
            "scope": scope,
            "intent": intent,
            "confidence": routing_res.confidence,
            "workflow_selected": workflow_selected,
            "retrieval_used": retrieval_used,
            "risk_model_used": risk_model_used,
            "active_investigation": bool(active_context or updated_context),
            "response_mode": response_mode
        }
        logger.info("Copilot routing: %s", json.dumps(copilot_log))

        # =========================================================================
        # EVIDENCE RELEVANCE GATE (Section 19)
        # =========================================================================
        # Discard irrelevant sections if response mode does not call for them
        if response_mode in ["OUT_OF_SCOPE", "CONVERSATIONAL", "CAPABILITIES", "TELECOM_CONCEPT", "CLARIFICATION", "DATASET_QUERY"]:
            res_incident = None
            res_risk = None
            res_root_causes = None
            res_impact = None
            res_predictions = None
            res_recommendations = None
            res_similar_cases = None

        return CopilotResponse(
            request_id=request_id,
            response_mode=response_mode,
            message=bot_message,
            routing=CopilotRoutingSchema(
                intent=intent,
                scope=scope,
                confidence=routing_res.confidence,
                requires_network_analysis=routing_res.requires_network_analysis,
                requires_retrieval=routing_res.requires_retrieval,
                requires_current_investigation_context=routing_res.requires_current_investigation_context,
                clarification_prompt=routing_res.clarification_prompt
            ),
            investigation_context=updated_context,
            incident=res_incident,
            risk=res_risk,
            root_causes=res_root_causes,
            network_impact=res_impact,
            predictions=res_predictions,
            recommendations=res_recommendations,
            similar_cases=res_similar_cases
        )

    # -------------------------------------------------------------
    # Helper: Explain Telecom Concept
    # -------------------------------------------------------------
    def _explain_telecom_concept(self, query: str) -> str:
        q_lower = query.lower()

        # Check environmental connections first
        for env_term, explanation in ENVIRONMENTAL_TELECOM_EXPLANATIONS.items():
            if env_term in q_lower:
                return explanation

        # Check standard technical concept definitions
        for term, explanation in TELECOM_CONCEPTS_KB.items():
            if term in q_lower:
                return explanation

        # Generic grounded telecom concept explanation
        return (
            "In telecom network operations, performance and quality of service (QoS) depend on continuous monitoring "
            "of key performance indicators such as latency, packet loss, cell throughput, handover success rate, and call drops. "
            "Telemetry anomalies in these metrics typically indicate air-interface interference, capacity exhaustion, or transport bottlenecks."
        )

    # -------------------------------------------------------------
    # Helper: Context-Aware Follow-Up Handling
    # -------------------------------------------------------------
    def _handle_follow_up(self, query: str, context: Dict[str, Any]) -> Tuple[str, str, Dict[str, Any]]:
        q_lower = query.lower()
        res_data: Dict[str, Any] = {}

        # 1. User asks why risk is high
        if any(w in q_lower for w in ["why is the risk", "risk score", "risk high", "why is risk"]):
            score = context.get("risk_score", 0)
            level = context.get("risk_level", "NORMAL")
            factors = context.get("risk_factors", [])
            factors_str = ", ".join(factors) if factors else "elevated telemetry variance beyond SLA thresholds"
            msg = (
                f"The current operational fault risk was evaluated at **{score}/100 ({level} RISK)** "
                f"because of the following detected factors:\n\n"
                f"• {factors_str}\n\n"
                f"These conditions indicate high probability of cell performance degradation or SLA breach under ongoing network load."
            )
            res_data["risk"] = {
                "score": score,
                "level": level,
                "factors": factors
            }
            return "RISK", msg, res_data

        # 2. User asks about a specific case (e.g. NET-9007 or similar cases)
        similar_cases = context.get("similar_cases", [])
        matched_case = None
        for c in similar_cases:
            if c.get("incident_id", "").lower() in q_lower:
                matched_case = c
                break

        if matched_case:
            cid = matched_case["incident_id"]
            sim_score = int(matched_case.get("similarity_score", 0.8) * 100)
            issue = matched_case.get("issue_reported", "Network issue")
            loc = f"{matched_case.get('location', {}).get('city', '')}, {matched_case.get('location', {}).get('state', '')}"
            weather = f"{matched_case.get('season', '')} ({matched_case.get('weather', '')})"
            metrics = matched_case.get("metrics", {})
            metrics_str = f"Latency: {metrics.get('latency', 'N/A')} ms, Packet Loss: {metrics.get('packet_loss_rate', 'N/A')}%, Throughput: {metrics.get('throughput', 'N/A')} Mbps"

            msg = (
                f"**{cid}** was retrieved as a highly similar historical precedent (Similarity: **{sim_score}%**):\n\n"
                f"• **Reported Issue**: {issue}\n"
                f"• **Location & Environmental**: {loc} during {weather}\n"
                f"• **Recorded Telemetry**: {metrics_str}\n"
                f"• **Historical Resolution**: {matched_case.get('historical_outcome', 'Resolved')}\n\n"
                f"It matches the active incident due to comparable air-interface degradation patterns and localized operational loading."
            )
            res_data["similar_cases"] = [matched_case]
            return "RETRIEVAL", msg, res_data

        # 3. User asks to show similar cases
        if any(w in q_lower for w in ["similar cases", "show cases", "matched cases", "similar incidents"]):
            if similar_cases:
                lines = [
                    f"• **{c['incident_id']}** ({c['location']['city']}) — Similarity: {int(c['similarity_score'] * 100)}% | {c['issue_reported']}"
                    for c in similar_cases[:3]
                ]
                msg = (
                    f"The active investigation matched the following **{len(similar_cases)} historical precedents**:\n\n"
                    + "\n".join(lines)
                )
                res_data["similar_cases"] = similar_cases
                return "RETRIEVAL", msg, res_data
            else:
                return "FOLLOW_UP", "No historical cases were matched for the current investigation.", res_data

        # 4. User asks why congestion or specific root cause was identified
        if any(w in q_lower for w in ["root cause", "congestion", "why do you think", "cause"]):
            rcs = context.get("root_causes", [])
            if rcs:
                top_rc = rcs[0]
                ev = ", ".join(top_rc.get("evidence", []))
                msg = (
                    f"Analysis identified **{top_rc['root_cause']}** as the primary probable cause "
                    f"(Likelihood: **{top_rc['likelihood']}**, score: {top_rc.get('likelihood_score', 80)}%).\n\n"
                    f"**Supporting Telemetry Evidence**: {ev}."
                )
                res_data["root_causes"] = rcs
                return "FOLLOW_UP", msg, res_data

        # 5. User asks what to do / recommended actions
        if any(w in q_lower for w in ["what should i do", "what action", "recommend", "remediation", "how to fix"]):
            recs = context.get("recommendations", [])
            if recs:
                rec_lines = [f"{i+1}. **{r['action']}** [{r['priority']}]: {r['reason']}" for i, r in enumerate(recs[:3])]
                msg = (
                    f"For active incident **{context.get('incident_type', 'Network Incident')}**, "
                    f"the recommended remediation actions are:\n\n" + "\n".join(rec_lines)
                )
                res_data["recommendations"] = recs
                return "RECOMMENDATION", msg, res_data

        # Default Follow-Up response using context
        msg = (
            f"Regarding the active investigation **{context.get('investigation_id', 'Current')}** "
            f"({context.get('incident_type', 'Incident')} in {context.get('location', 'Metropolitan Cluster')}, "
            f"Severity: {context.get('severity', 'MEDIUM')}, Risk: {context.get('risk_score', 0)}/100):\n\n"
            f"You can ask about the root cause evidence, why specific historical cases were matched, "
            f"or details on the recommended remediation steps."
        )
        return "FOLLOW_UP", msg, res_data

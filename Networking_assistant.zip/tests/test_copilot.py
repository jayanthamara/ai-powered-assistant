"""
Comprehensive Automated Test Suite for NETPULSE AI Copilot.
Tests:
- Scope determination (IN_SCOPE vs OUT_OF_SCOPE)
- CopilotIntentRouter 14 intents classification
- Clarification requests for low confidence / ambiguous inputs
- Prevention of hallucinations on general knowledge queries
- Context-aware follow-up reasoning
- Evidence relevance gating
- Mandatory bug regression test for 'what is monsoon'
"""
import os
import sys
import pytest
from fastapi.testclient import TestClient

# Ensure root directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from src.main import app
from src.agents.copilot_router import (
    CopilotIntentRouter,
    INTENT_GREETING, INTENT_CAPABILITIES, INTENT_TELECOM_CONCEPT,
    INTENT_INCIDENT_INVESTIGATION, INTENT_HISTORICAL_SEARCH, INTENT_RISK_ANALYSIS,
    INTENT_ROOT_CAUSE_ANALYSIS, INTENT_NETWORK_IMPACT, INTENT_PERFORMANCE_PREDICTION,
    INTENT_RECOMMENDATION, INTENT_FOLLOW_UP, INTENT_DATASET_QUERY,
    INTENT_OUT_OF_SCOPE, INTENT_CLARIFICATION_REQUIRED
)

client = TestClient(app)

# =========================================================================
# REQUIRED TESTS SPECIFIED IN SECTION 27 & 28
# =========================================================================

# Test 1: "hello" -> GREETING (No network analysis)
def test_copilot_test_1_greeting():
    route = CopilotIntentRouter.route("hello")
    assert route.intent == INTENT_GREETING
    assert route.scope == "IN_SCOPE"
    assert route.requires_network_analysis is False
    assert route.requires_retrieval is False

    resp = client.post("/api/v1/copilot", json={"query": "hello"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["intent"] == INTENT_GREETING
    assert data["response_mode"] == "CONVERSATIONAL"
    assert data["risk"] is None
    assert data["incident"] is None
    assert data["similar_cases"] is None
    assert data["recommendations"] is None
    assert "NETPULSE AI" in data["message"]


# Test 2: "what is monsoon" -> OUT_OF_SCOPE (No RAG, no risk model, no RCA, no recommendations)
def test_copilot_test_2_what_is_monsoon_out_of_scope():
    route = CopilotIntentRouter.route("what is monsoon")
    assert route.intent == INTENT_OUT_OF_SCOPE
    assert route.scope == "OUT_OF_SCOPE"
    assert route.requires_network_analysis is False
    assert route.requires_retrieval is False

    resp = client.post("/api/v1/copilot", json={"query": "what is monsoon"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["scope"] == "OUT_OF_SCOPE"
    assert data["routing"]["intent"] == INTENT_OUT_OF_SCOPE
    assert data["response_mode"] == "OUT_OF_SCOPE"
    assert "outside my telecom network operations scope" in data["message"]
    # Verify no operational diagnostics
    assert data["incident"] is None
    assert data["risk"] is None
    assert data["root_causes"] is None
    assert data["similar_cases"] is None
    assert data["recommendations"] is None


# Test 3: "what is the capital of France" -> OUT_OF_SCOPE (No network analysis)
def test_copilot_test_3_capital_of_france_out_of_scope():
    route = CopilotIntentRouter.route("what is the capital of France")
    assert route.intent == INTENT_OUT_OF_SCOPE
    assert route.scope == "OUT_OF_SCOPE"
    assert route.requires_network_analysis is False

    resp = client.post("/api/v1/copilot", json={"query": "what is the capital of France"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["scope"] == "OUT_OF_SCOPE"
    assert data["response_mode"] == "OUT_OF_SCOPE"
    assert data["incident"] is None
    assert data["risk"] is None


# Test 4: "what is packet loss?" -> TELECOM_CONCEPT (Telecom explanation, no incident investigation)
def test_copilot_test_4_what_is_packet_loss():
    route = CopilotIntentRouter.route("what is packet loss?")
    assert route.intent == INTENT_TELECOM_CONCEPT
    assert route.scope == "IN_SCOPE"
    assert route.requires_network_analysis is False
    assert route.requires_retrieval is False

    resp = client.post("/api/v1/copilot", json={"query": "what is packet loss?"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["intent"] == INTENT_TELECOM_CONCEPT
    assert data["response_mode"] == "TELECOM_CONCEPT"
    assert "Packet loss" in data["message"]
    # Must NOT run incident investigation
    assert data["incident"] is None
    assert data["risk"] is None
    assert data["similar_cases"] is None
    assert data["recommendations"] is None


# Test 5: "what is MTTR?" -> TELECOM_CONCEPT (Telecom explanation)
def test_copilot_test_5_what_is_mttr():
    route = CopilotIntentRouter.route("what is MTTR?")
    assert route.intent == INTENT_TELECOM_CONCEPT
    assert route.scope == "IN_SCOPE"
    assert route.requires_network_analysis is False

    resp = client.post("/api/v1/copilot", json={"query": "what is MTTR?"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["intent"] == INTENT_TELECOM_CONCEPT
    assert data["response_mode"] == "TELECOM_CONCEPT"
    assert "MTTR" in data["message"]
    assert "Mean Time to Resolve" in data["message"]


# Test 6: "How can monsoon conditions affect telecom network performance?" -> IN_SCOPE
def test_copilot_test_6_monsoon_environmental_telecom_in_scope():
    route = CopilotIntentRouter.route("How can monsoon conditions affect telecom network performance?")
    assert route.scope == "IN_SCOPE"
    assert route.intent in [INTENT_TELECOM_CONCEPT, INTENT_INCIDENT_INVESTIGATION]

    resp = client.post("/api/v1/copilot", json={"query": "How can monsoon conditions affect telecom network performance?"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["scope"] == "IN_SCOPE"
    # Grounded in telecom environmental variables
    assert any(term in data["message"].lower() for term in ["attenuation", "rain fade", "latency", "packet loss", "radio", "microwave"])


# Test 7: "find historical incidents with high latency in Hyderabad" -> HISTORICAL_SEARCH
def test_copilot_test_7_historical_search():
    route = CopilotIntentRouter.route("find historical incidents with high latency in Hyderabad")
    assert route.intent == INTENT_HISTORICAL_SEARCH
    assert route.scope == "IN_SCOPE"
    assert route.requires_retrieval is True

    resp = client.post("/api/v1/copilot", json={"query": "find historical incidents with high latency in Hyderabad"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["intent"] == INTENT_HISTORICAL_SEARCH
    assert data["response_mode"] == "RETRIEVAL"
    assert data["similar_cases"] is not None
    assert len(data["similar_cases"]) > 0


# Test 8: "Why is latency high in Hyderabad?" -> INCIDENT_INVESTIGATION
def test_copilot_test_8_incident_investigation():
    route = CopilotIntentRouter.route("Why is latency high in Hyderabad?")
    assert route.intent == INTENT_INCIDENT_INVESTIGATION
    assert route.scope == "IN_SCOPE"
    assert route.requires_network_analysis is True

    resp = client.post("/api/v1/copilot", json={"query": "Why is latency high in Hyderabad?"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["intent"] == INTENT_INCIDENT_INVESTIGATION
    assert data["response_mode"] == "INVESTIGATION"
    assert data["incident"] is not None
    assert data["risk"] is not None
    assert data["similar_cases"] is not None
    assert data["recommendations"] is not None
    assert data["investigation_context"] is not None


# Test 9: "Why is the risk score high?" (with active investigation) -> FOLLOW_UP / RISK_ANALYSIS
def test_copilot_test_9_risk_follow_up():
    mock_context = {
        "investigation_id": "INV-TEST01",
        "user_query": "Why is latency high in Hyderabad?",
        "incident_type": "High Latency",
        "severity": "HIGH",
        "location": "Hyderabad, Telangana",
        "metrics": {"latency": 175.4, "packet_loss_rate": 11.2},
        "risk_score": 88.0,
        "risk_level": "CRITICAL",
        "risk_factors": ["High latency (175.4 ms)", "Severe packet loss (11.2%)"],
        "similar_cases": [{"incident_id": "NET-9006"}],
        "recommendations": [{"action": "Check antenna tilt", "priority": "HIGH", "reason": "High latency"}]
    }

    route = CopilotIntentRouter.route("Why is the risk score high?", active_context=mock_context)
    assert route.scope == "IN_SCOPE"
    assert route.requires_current_investigation_context is True

    resp = client.post("/api/v1/copilot", json={
        "query": "Why is the risk score high?",
        "investigation_context": mock_context
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["response_mode"] in ["RISK", "FOLLOW_UP"]
    assert "88" in data["message"]
    assert "CRITICAL" in data["message"]


# Test 10: "Show me similar cases." (with active investigation) -> HISTORICAL_SEARCH / FOLLOW_UP
def test_copilot_test_10_similar_cases_follow_up():
    mock_context = {
        "investigation_id": "INV-TEST02",
        "user_query": "Investigate packet loss",
        "incident_type": "Packet Loss",
        "similar_cases": [
            {
                "incident_id": "NET-9001",
                "similarity_score": 0.91,
                "location": {"city": "Mumbai", "state": "Maharashtra"},
                "issue_reported": "Throughput Degradation"
            }
        ]
    }

    route = CopilotIntentRouter.route("Show me similar cases.", active_context=mock_context)
    assert route.scope == "IN_SCOPE"
    assert route.requires_current_investigation_context is True

    resp = client.post("/api/v1/copilot", json={
        "query": "Show me similar cases.",
        "investigation_context": mock_context
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "NET-9001" in data["message"]
    assert data["similar_cases"] is not None


# Test 11: "Why is NET-9007 similar?" (with NET-9007 in context) -> FOLLOW_UP / HISTORICAL_SEARCH
def test_copilot_test_11_case_similarity_follow_up():
    mock_context = {
        "investigation_id": "INV-TEST03",
        "similar_cases": [
            {
                "incident_id": "NET-9007",
                "similarity_score": 0.88,
                "location": {"city": "Kolkata", "state": "West Bengal"},
                "season": "Monsoon",
                "weather": "Rain",
                "issue_reported": "Signal Degradation / RF Interference",
                "metrics": {"latency": 118.0, "packet_loss_rate": 6.5, "throughput": 52.0},
                "historical_outcome": "Resolved via RF re-tuning"
            }
        ]
    }

    route = CopilotIntentRouter.route("Why is NET-9007 similar?", active_context=mock_context)
    assert route.scope == "IN_SCOPE"
    assert route.requires_current_investigation_context is True

    resp = client.post("/api/v1/copilot", json={
        "query": "Why is NET-9007 similar?",
        "investigation_context": mock_context
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "NET-9007" in data["message"]
    assert "Signal Degradation" in data["message"] or "Kolkata" in data["message"] or "118" in data["message"]


# Test 12: "What should I do?" (with active investigation) -> RECOMMENDATION / FOLLOW_UP
def test_copilot_test_12_recommendation_follow_up():
    mock_context = {
        "investigation_id": "INV-TEST04",
        "incident_type": "Congestion Incident",
        "recommendations": [
            {
                "action": "Adjust electrical antenna downtilt by -2 degrees",
                "priority": "HIGH",
                "reason": "Reduce inter-cell interference and focus power on high-density user cluster"
            }
        ]
    }

    route = CopilotIntentRouter.route("What should I do?", active_context=mock_context)
    assert route.scope == "IN_SCOPE"
    assert route.requires_current_investigation_context is True

    resp = client.post("/api/v1/copilot", json={
        "query": "What should I do?",
        "investigation_context": mock_context
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "Adjust electrical antenna downtilt" in data["message"]
    assert data["recommendations"] is not None


# Test 13: "Write me a poem about the ocean." -> OUT_OF_SCOPE
def test_copilot_test_13_poem_out_of_scope():
    route = CopilotIntentRouter.route("Write me a poem about the ocean.")
    assert route.intent == INTENT_OUT_OF_SCOPE
    assert route.scope == "OUT_OF_SCOPE"
    assert route.requires_network_analysis is False

    resp = client.post("/api/v1/copilot", json={"query": "Write me a poem about the ocean."})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["scope"] == "OUT_OF_SCOPE"
    assert data["response_mode"] == "OUT_OF_SCOPE"
    assert data["incident"] is None


# Test 28: MANDATORY BUG REGRESSION TEST
def test_copilot_test_28_mandatory_bug_regression():
    """
    MANDATORY BUG REGRESSION TEST:
    The exact query 'what is monsoon' MUST NEVER produce:
    - incident classification
    - severity
    - risk score
    - NET-9007
    - NET-9010
    - user count
    - throughput
    - latency
    - packet loss
    - root cause
    - operational recommendations
    """
    resp = client.post("/api/v1/copilot", json={"query": "what is monsoon"})
    assert resp.status_code == 200
    data = resp.json()

    # Must be categorized as OUT_OF_SCOPE
    assert data["routing"]["scope"] == "OUT_OF_SCOPE"
    assert data["routing"]["intent"] == INTENT_OUT_OF_SCOPE
    assert data["response_mode"] == "OUT_OF_SCOPE"

    # Strictly null operational outputs
    assert data["incident"] is None
    assert data["risk"] is None
    assert data["root_causes"] is None
    assert data["similar_cases"] is None
    assert data["recommendations"] is None
    assert data["network_impact"] is None
    assert data["predictions"] is None

    # Message must NOT hallucinate operational records or cases
    msg_lower = data["message"].lower()
    assert "net-9007" not in msg_lower
    assert "net-9010" not in msg_lower
    assert "case-" not in msg_lower
    assert "user count" not in msg_lower
    assert "risk score" not in msg_lower
    assert "severity" not in msg_lower


# Test Clarification on Ambiguous Query (Confidence < 0.50)
def test_copilot_clarification_on_vague_query():
    route = CopilotIntentRouter.route("Things look bad.")
    assert route.intent == INTENT_CLARIFICATION_REQUIRED
    assert route.confidence < 0.50

    resp = client.post("/api/v1/copilot", json={"query": "Things look bad."})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["intent"] == INTENT_CLARIFICATION_REQUIRED
    assert data["response_mode"] == "CLARIFICATION"
    assert "Could you tell me what network issue you're seeing" in data["message"]


# Test Capabilities Question
def test_copilot_capabilities_query():
    route = CopilotIntentRouter.route("What can you do?")
    assert route.intent == INTENT_CAPABILITIES
    assert route.scope == "IN_SCOPE"

    resp = client.post("/api/v1/copilot", json={"query": "What can you do?"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["routing"]["intent"] == INTENT_CAPABILITIES
    assert data["response_mode"] == "CAPABILITIES"
    assert "Incident Investigation" in data["message"]
    assert "Hybrid Retrieval" in data["message"]

# NETPULSE AI — AI-Powered Telecom Network Operations Assistant

[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-009688.svg?logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com)
[![React](https://img.shields.io/badge/React-18.2+-61DAFB.svg?logo=react&logoColor=black)](https://react.dev)
[![Vite](https://img.shields.io/badge/Vite-5.0+-646CFF.svg?logo=vite&logoColor=white)](https://vitejs.dev)
[![TailwindCSS](https://img.shields.io/badge/TailwindCSS-3.4+-38B2AC.svg?logo=tailwind-css&logoColor=white)](https://tailwindcss.com)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.4+-F7931E.svg?logo=scikit-learn&logoColor=white)](https://scikit-learn.org)
[![Python](https://img.shields.io/badge/Python-3.11+-3776AB.svg?logo=python&logoColor=white)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

---

## 👥 Project & Contributor Details
* **Project Name:** NETPULSE AI — AI-Powered Telecom Network Operations Assistant
* **Project Type:** Individual Capstone / Production Submission
* **Author / Developer:** Individual Project Submission
* **Domain:** 5G / LTE Telecom Radio Access Network (RAN) Operations & Automated NOC Triage

---

## 📌 Project Overview
**NETPULSE AI** is an enterprise-grade, deterministic, and retrieval-augmented artificial intelligence copilot tailored for **5G and LTE Telecom Network Operations Centers (NOC)**. It provides real-time triage, anomaly detection, multi-agent root cause analysis (RCA), SLA breach detection, and standard operating procedure (SOP) mitigation recommendations.

Operating over high-velocity radio access network (RAN) and transport telemetry, NETPULSE AI fuses sub-millisecond latent semantic retrieval with calibrated machine learning models and strict operational guardrails to deliver auditable decision support for network operations engineers.

---

## 🏛️ System Architecture

The complete vector architecture diagram is provided in [`architecture/Architecture_Diagram.pdf`](architecture/Architecture_Diagram.pdf).

```
Operator Query / Telemetry Alert
               │
               ▼
┌─────────────────────────────────┐
│     Query Validation Gateway    │ ── (Sanitization & Domain Classifier)
└────────────────┬────────────────┘
                 │
                 ▼
┌─────────────────────────────────┐
│    10-Agent Operational Swarm   │
│  - IncidentClassifierAgent      │
│  - NetworkAnalystAgent          │
│  - RiskAnalystAgent (60/40 ML)  │
│  - RootCauseAnalystAgent        │
│  - RecommendationEngineAgent    │
│  - LLMSynthesizerAgent          │
│  - JudgeAgent (Quality Gate)    │
└────────────────┬────────────────┘
                 │
                 ├───────────────────────────────┐
                 ▼                               ▼
┌─────────────────────────────────┐   ┌─────────────────────────────────┐
│     4-Way Hybrid Retriever      │   │    ML Performance Predictor     │
│   (128-d LSA + BM25 + Proximity)│   │  (Random Forest KPI Regressor)  │
└────────────────┬────────────────┘   └────────────────┬────────────────┘
                 │                                     │
                 └───────────────┬─────────────────────┘
                                 ▼
                 ┌─────────────────────────────────┐
                 │ FastAPI Async REST API Layer    │
                 └───────────────┬─────────────────┘
                                 ▼
                 ┌─────────────────────────────────┐
                 │ React 18 / Tailwind NOC Cockpit │
                 └─────────────────────────────────┘
```

---

## 📁 Repository Directory Structure

```
ProjectRepository/
├── architecture/
│   └── Architecture_Diagram.pdf      # Complete System Architecture (Vector PDF)
├── design/
│   └── Design_Document.pdf           # Technical Architecture & Design Document (PDF)
├── presentation/
│   └── Project_Presentation.pptx     # 11-Slide Executive Presentation Deck (PPTX)
├── docs/
│   ├── API_Documentation.pdf         # REST API Specification (PDF)
│   └── Evaluation_Report.pdf         # RAGAS & DeepEval Empirical Evaluation Report (PDF)
├── data/
│   ├── sample_data/
│   │   ├── sample_telecom_incidents.csv  # 500 Verified Sample NOC Incidents
│   │   └── README.md                 # Dataset Schema & Attribute Dictionary
│   └── processed/                    # Processed Telemetry, Models & Search Indices
├── src/
│   ├── api/                          # FastAPI REST Endpoints & Route Handlers
│   ├── agents/                       # 10-Agent Autonomous Reasoning Swarm
│   ├── rag/                          # 4-Way Hybrid Vector + BM25 Retrieval Engine
│   ├── services/                     # Copilot Orchestration & Business Logic
│   ├── utils/                        # Data Preprocessing & Index Building Utilities
│   ├── ml/                           # Random Forest Classifier & Regressors
│   ├── analytics/                    # Deterministic SLA & Network Impact Analysis
│   ├── guardrails/                   # Prompt Injection & Telecom Domain Filtering
│   ├── database/                     # SQLite Feedback Storage & Dataset Loaders
│   ├── schemas/                      # Pydantic v2 Request/Response Schemas
│   └── main.py                       # FastAPI Application Entry Point
├── frontend/
│   ├── src/                          # React Components, Pages, and API Client
│   ├── package.json                  # Frontend Dependencies & Scripts
│   ├── vite.config.ts                # Vite Configuration & Dev Server
│   └── tailwind.config.js            # Telecom NOC Dark Palette Design Tokens
├── scripts/                          # Preprocessing, Index Building, & Verifier Scripts
├── tests/
│   ├── test_copilot.py               # 16 Automated Copilot Intent & Scope Tests
│   └── test_netpulse.py              # End-to-End Pipeline & SLA Analytics Tests
├── requirements.txt                  # Python Backend Dependencies
├── pytest.ini                        # Pytest Test Runner Configuration
├── .env.example                      # Safe Environment Variable Template (No Secrets)
├── .gitignore                        # Git Ignore Rules (Protects .env, node_modules)
└── README.md                         # Main Documentation
```

---

## 🚀 Local Deployment Instructions

### 1. Prerequisites
- **Python 3.11+** installed (`python --version`)
- **Node.js 18+** & **npm** installed (`node --version`)
- **Git** installed

---

### 2. Backend Setup & Startup

1. **Create and Activate Python Virtual Environment:**
   ```bash
   python -m venv venv
   
   # Windows (PowerShell):
   .\venv\Scripts\Activate.ps1
   
   # Windows (CMD):
   .\venv\Scripts\activate.bat
   
   # Linux / macOS:
   source venv/bin/activate
   ```

2. **Install Backend Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure Environment Variables:**
   ```bash
   # Copy sample configuration
   copy .env.example .env     # Windows
   cp .env.example .env       # Linux / macOS
   ```
   *Note:* By default, `LLM_PROVIDER=demo` is pre-configured for **100% offline, zero-API-key execution**. To use cloud LLMs, add your `NVIDIA_API_KEY` or `OPENAI_API_KEY` in `.env`.

4. **Run the Backend Server:**
   ```bash
   uvicorn src.main:app --reload --port 8000
   ```
   * The API server will start at `http://127.0.0.1:8000`.
   * Interactive Swagger UI docs are live at `http://127.0.0.1:8000/docs`.

---

### 3. Frontend Setup & Startup

1. **Navigate to Frontend Directory and Install Dependencies:**
   ```bash
   cd frontend
   npm install
   ```

2. **Start the Frontend Development Server:**
   ```bash
   npm run dev
   ```
   * The NOC Cockpit will be accessible at `http://localhost:5173`.
   * The frontend is pre-configured to communicate seamlessly with `http://127.0.0.1:8000`.

---

### 4. Running the Automated Test Suite

Run all verification and copilot regression tests:
```bash
pytest tests/ -v
```
All tests validate intent classification, scope gating, prompt injection defense, and recommendation generation.

---

## 🔒 Security & Secrets Compliance
* **Zero Committed Secrets:** This repository strictly excludes active `.env` files and production credentials via [`.gitignore`](.gitignore).
* **Safe Offline Execution:** The application includes a self-contained offline demo synthesizer mode (`LLM_PROVIDER=demo`) allowing complete evaluation without external API calls or keys.
* **Input Guardrails:** All inputs are inspected for prompt injections, command escapes, and out-of-scope queries before processing.

---

## 📜 Deliverables Checklist
- [x] **Source code is complete** (Full backend in `src/` and frontend in `frontend/`)
- [x] **README is updated** (Includes team/developer info, deployment, and architecture)
- [x] **Architecture diagram included** (`architecture/Architecture_Diagram.pdf`)
- [x] **Design document included** (`design/Design_Document.pdf`)
- [x] **Presentation deck included** (`presentation/Project_Presentation.pptx`)
- [x] **APIs are working** (FastAPI with 24 endpoints and automated test coverage)
- [x] **Sample data included** (`data/sample_data/sample_telecom_incidents.csv`)
- [x] **Repository is accessible** (Clean GitHub-ready layout)
- [x] **Team details provided** (Individual Project Details documented above)
- [x] **All deliverables follow naming conventions** (Exact casing and standard naming)
- [x] **Local deployment instructions included** (Step-by-step for backend & frontend)
- [x] **No secrets or API keys committed** (Protected via `.env.example` & `.gitignore`)

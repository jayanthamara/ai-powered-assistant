@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ======================================================================
echo NETPULSE AI - Automated Setup for Office Laptop
echo ======================================================================
echo.

:: 1. Check Python
python --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Python is not installed or not in your PATH!
    echo Please install Python 3.11+ from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('python --version') do echo [OK] Found %%i

:: 2. Check Node.js
node --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Node.js is not installed or not in your PATH!
    echo Please install Node.js 18 or 20 LTS from https://nodejs.org/
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('node --version') do echo [OK] Found Node.js %%i

:: 3. Create Virtual Environment
if not exist "venv\Scripts\python.exe" (
    echo.
    echo [1/4] Creating Python virtual environment (venv)...
    python -m venv venv
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Failed to create virtual environment!
        pause
        exit /b 1
    )
) else (
    echo.
    echo [1/4] Virtual environment already exists.
)

:: 4. Install Python Dependencies
echo [2/4] Installing backend dependencies...
venv\Scripts\python.exe -m pip install --upgrade pip
venv\Scripts\pip.exe install -r requirements.txt
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to install backend dependencies!
    pause
    exit /b 1
)

:: 5. Prepare Environment Configuration (.env)
echo [3/4] Checking environment configuration (.env)...
if not exist ".env" (
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo   [OK] Created .env from .env.example (configured for offline demo mode, zero API keys required).
    )
) else (
    echo   [OK] .env already present.
)

:: 6. Install Frontend Dependencies
echo [4/4] Installing frontend packages (npm install)...
cd frontend
call npm install
cd ..
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to install frontend packages!
    pause
    exit /b 1
)

:: 7. Run Verification
echo.
echo Running self-test verification...
venv\Scripts\python.exe scripts\verify_system.py

echo.
echo ======================================================================
echo [SUCCESS] Setup is complete and verified!
echo You can now start the application anytime by double-clicking run.bat
echo ======================================================================
echo.
set /p LAUNCH="Do you want to launch the application now? (Y/N): "
if /i "%LAUNCH%"=="Y" (
    call "%~dp0run.bat"
)
pause

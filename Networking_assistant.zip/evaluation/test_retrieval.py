"""
Retrieval Evaluation Suite for NETPULSE AI.
Tests retrieval relevance, contextual precision, contextual recall, and metadata alignment.
"""
import os
import sys
import json
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.app.api.routes import get_app_state, initialize_services

@pytest.fixture(scope="module")
def app_state():
    return get_app_state()

def load_eval_dataset():
    path = os.path.join(os.path.dirname(__file__), "datasets", "eval_samples.json")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def test_retrieval_relevance_and_ranking(app_state):
    search_engine = app_state["search_engine"]
    samples = load_eval_dataset()

    for item in samples:
        results = search_engine.search(query=item["query"], top_k=5)
        assert len(results) > 0, f"Query '{item['id']}' failed to retrieve any candidates."
        
        top_result = results[0]
        # Assert minimum similarity threshold
        assert top_result["similarity_score"] >= item.get("minimum_retrieval_relevance", 0.50), \
            f"Top result similarity {top_result['similarity_score']} below threshold for {item['id']}"

        # Contextual precision: Top result should have meaningful why_similar reasoning
        assert len(top_result["why_similar"]) >= 1

def test_retrieval_geographic_coherence(app_state):
    search_engine = app_state["search_engine"]
    df = app_state["df"]
    target_city = str(df["city"].iloc[0])
    target_state = str(df["state"].iloc[0])
    results = search_engine.search(
        query=f"High latency and packet loss in {target_city}",
        extracted_location={"city": target_city, "state": target_state},
        top_k=5
    )
    # Check that matching target city cases are prioritized in retrieved results
    cities = [str(r["location"]["city"]).lower() for r in results]
    assert target_city.lower() in cities, f"Retrieved results did not prioritize matching target city '{target_city}'."


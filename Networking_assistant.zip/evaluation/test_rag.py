"""
RAG Quality Evaluation Suite for NETPULSE AI.
Evaluates end-to-end RAG pipeline, faithfulness, grounding, and multi-agent synthesis.
"""
import os
import sys
import json
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.app.api.routes import get_app_state

@pytest.fixture(scope="module")
def app_state():
    return get_app_state()

def test_rag_faithfulness_and_grounding(app_state):
    orchestrator = app_state["orchestrator"]
    query = "A cell is experiencing high latency, packet loss and reduced throughput in state MN. Find similar historical incidents."
    
    res = orchestrator.process_investigation(query=query, top_k=4)
    assert res["success"] is True

    eval_meta = res["evaluation"]
    # DeepEval / LLM-as-a-judge score requirements
    assert eval_meta["grounding_score"] >= 0.80, "Grounding score failed threshold"
    assert eval_meta["relevance_score"] >= 0.80, "Relevance score failed threshold"
    assert eval_meta["overall_score"] >= 0.80, "Overall RAG score failed threshold"

def test_rag_no_metric_hallucination(app_state):
    orchestrator = app_state["orchestrator"]
    query = "Several cells have poor service quality and increasing alarm counts."
    
    res = orchestrator.process_investigation(query=query)
    assert res["success"] is True
    # Ensure all cited cases in diagnosis exist in similar_cases
    diagnosis = res["diagnosis"]
    retrieved_case_ids = {c["incident_id"] for c in res["similar_cases"]}
    
    import re
    cited = re.findall(r"\b(?:CASE|NET)-\d+\b", diagnosis)
    for c in cited:
        assert c in retrieved_case_ids, f"Diagnosis hallucinated case ID '{c}' not in retrieved cases."

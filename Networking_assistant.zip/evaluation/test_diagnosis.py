"""
Diagnosis Quality and LLM-as-a-Judge Evaluation Suite for NETPULSE AI.
Tests clarity, incident classification alignment, and judge rubric consistency.
"""
import os
import sys
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.app.agents.judge_agent import JudgeAgent
from backend.app.agents.llm_synthesizer import LLMSynthesizerAgent

def test_diagnosis_synthesis_and_judge_coherence():
    incident = {"incident_type": "High Latency", "severity": "HIGH"}
    risk = {"risk_score": 82, "risk_level": "HIGH"}
    root_causes = [
        {"root_cause": "Transport Backhaul Bottleneck", "likelihood_score": 85, "evidence": ["Latency 140ms", "Loss 6%"]}
    ]
    similar_cases = [{"incident_id": "CASE-1042"}]
    recommendations = [
        {"action": "Inspect router queue depth", "priority": "HIGH", "reason": "Buffer overflow", "evidence": ["CASE-1042"]}
    ]
    network_impact = {"affected_region": "Minneapolis, MN", "impact_level": "HIGH"}

    diagnosis = LLMSynthesizerAgent.synthesize_diagnosis(
        query="High latency in Minneapolis cells",
        incident=incident,
        risk=risk,
        root_causes=root_causes,
        similar_cases=similar_cases,
        recommendations=recommendations,
        network_impact=network_impact
    )

    assert "High Latency" in diagnosis
    assert "Minneapolis" in diagnosis

    # Judge agent evaluation
    eval_res = JudgeAgent.evaluate(
        query="High latency in Minneapolis cells",
        diagnosis=diagnosis,
        retrieved_cases=similar_cases,
        recommendations=recommendations,
        incident=incident
    )

    assert eval_res["grounding_score"] >= 0.85
    assert eval_res["relevance_score"] >= 0.85
    assert eval_res["recommendation_score"] >= 0.85
    assert eval_res["overall_score"] >= 0.85
    assert len(eval_res["issues"]) == 0

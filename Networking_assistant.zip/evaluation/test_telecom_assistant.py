"""
Alias entry point for tests/deepeval/test_telecom_assistant.py
Allows running:
pytest evaluation/test_telecom_assistant.py
or
pytest tests/deepeval/
"""
from tests.deepeval.test_telecom_assistant import *

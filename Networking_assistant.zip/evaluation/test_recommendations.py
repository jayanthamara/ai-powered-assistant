"""
Recommendation Quality Evaluation Suite for NETPULSE AI.
Evaluates recommendation safety, actionability, prioritized ranking, and historical traceability.
"""
import os
import sys
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.app.agents.recommendation_agent import RecommendationEngineAgent

def test_recommendation_traceability_and_evidence():
    root_causes = [
        {"root_cause": "Radio Access Network (RAN) Congestion", "likelihood_score": 88}
    ]
    historical = [{"incident_id": "CASE-1042"}, {"incident_id": "CASE-1088"}]
    telemetry = {"critical_alarm_count": 2, "packet_loss_rate": 5.4}

    recs = RecommendationEngineAgent.generate_recommendations(
        root_causes=root_causes,
        historical_cases=historical,
        telemetry=telemetry,
        incident_type="Congestion"
    )

    assert len(recs) >= 3
    for r in recs:
        # Every recommendation must have action, priority, reason, evidence
        assert "action" in r and len(r["action"]) > 10
        assert r["priority"] in ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
        assert "reason" in r and len(r["reason"]) > 10
        assert len(r["evidence"]) >= 1, "Recommendation missing historical case evidence."

def test_recommendation_safety_constraints():
    """Ensure no unsafe, irreversible destructive commands (e.g. rm, drop, shutdown) exist in recommendations."""
    root_causes = [{"root_cause": "Configuration Anomaly", "likelihood_score": 75}]
    recs = RecommendationEngineAgent.generate_recommendations(
        root_causes=root_causes,
        historical_cases=[{"incident_id": "CASE-101"}],
        telemetry={},
        incident_type="Configuration Issue"
    )
    forbidden_terms = ["factory reset", "format", "shutdown cell", "power cut", "delete all"]
    for r in recs:
        action_lower = r["action"].lower()
        for forbidden in forbidden_terms:
            assert forbidden not in action_lower, f"Unsafe command '{forbidden}' detected in recommendations."

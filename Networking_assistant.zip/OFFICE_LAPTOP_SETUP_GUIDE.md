# NETPULSE AI - Office Laptop Setup & Run Guide

**AI-Powered Telecom Network Operations Assistant**

---

## Quick Start (Automated 1-Click Setup)

Once you extract the zip file (`Networking_assistant.zip`) on your office laptop:

### Step 1: Run Setup
- **Windows (Double-click):** Double-click **`setup.bat`**
- **PowerShell:** Run `.\setup.ps1`

The setup script will automatically:
1. Verify **Python 3.11+** and **Node.js 18+** are installed.
2. Create an isolated Python virtual environment (`venv`).
3. Install all backend dependencies from `requirements.txt`.
4. Create `.env` configured for **100% offline, zero-API-key execution** (`LLM_PROVIDER=demo`).
5. Install all frontend packages (`npm install` in `frontend/`).
6. Run the verification test suite to confirm model readiness.

### Step 2: Start the Application Anytime
- **Double-click:** **`run.bat`**
- **Or PowerShell:** `.\run.ps1`

This simultaneously launches:
- **FastAPI Backend:** [http://localhost:8000](http://localhost:8000) (Interactive Swagger Docs: [http://localhost:8000/docs](http://localhost:8000/docs))
- **React Frontend NOC Cockpit:** [http://localhost:5173](http://localhost:5173)

---

## Manual Command-Line Setup (Alternative)

If you prefer running terminal commands manually:

```bash
# 1. Create and activate virtual environment
python -m venv venv
.\venv\Scripts\activate.bat   # Windows CMD
# or .\venv\Scripts\Activate.ps1 # PowerShell

# 2. Install backend dependencies
pip install --upgrade pip
pip install -r requirements.txt

# 3. Configure environment file
copy .env.example .env

# 4. Install frontend packages
cd frontend
npm install
cd ..

# 5. Run verification
python scripts/verify_system.py

# 6. Start servers in two separate terminals
# Terminal 1:
uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2:
cd frontend
npm run dev
```

---

## How to Upload to GitHub

This repository is already configured with a comprehensive [`.gitignore`](.gitignore) that prevents uploading secrets, `node_modules`, `venv`, or generated cache files.

To push changes to GitHub:

```bash
git add .
git commit -m "Add office laptop setup scripts and clean deployment configuration"
git push origin main
```

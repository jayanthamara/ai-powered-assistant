# NETPULSE AI - One-Click PowerShell Setup for Office Laptop
$ErrorActionPreference = "Stop"
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $SCRIPT_DIR

Write-Host "`n======================================================================" -ForegroundColor Cyan
Write-Host "  NETPULSE AI: AUTOMATED OFFICE LAPTOP SETUP" -ForegroundColor Yellow
Write-Host "======================================================================`n" -ForegroundColor Cyan

# 1. Check Python
try {
    $pyVer = python --version 2>&1
    Write-Host "[OK] Python: $pyVer" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Python 3.11+ is required but not found in PATH." -ForegroundColor Red
    exit 1
}

# 2. Check Node.js
try {
    $nodeVer = node --version 2>&1
    Write-Host "[OK] Node.js: $nodeVer" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Node.js is required but not found in PATH." -ForegroundColor Red
    exit 1
}

# 3. Create venv
if (-not (Test-Path "venv\Scripts\python.exe")) {
    Write-Host "`n[1/4] Creating Python virtual environment (venv)..." -ForegroundColor Cyan
    python -m venv venv
} else {
    Write-Host "`n[1/4] Virtual environment already exists." -ForegroundColor Green
}

# 4. Install backend requirements
Write-Host "`n[2/4] Installing backend dependencies..." -ForegroundColor Cyan
& ".\venv\Scripts\python.exe" -m pip install --upgrade pip
& ".\venv\Scripts\pip.exe" install -r requirements.txt

# 5. Environment file
Write-Host "`n[3/4] Checking environment configuration..." -ForegroundColor Cyan
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "  [OK] Created .env from .env.example (Safe offline demo mode, zero API keys required)." -ForegroundColor Green
} else {
    Write-Host "  [OK] .env already exists." -ForegroundColor Green
}

# 6. Install frontend
Write-Host "`n[4/4] Installing frontend dependencies (npm install)..." -ForegroundColor Cyan
Set-Location (Join-Path $SCRIPT_DIR "frontend")
npm install
Set-Location $SCRIPT_DIR

# 7. Verification
Write-Host "`nRunning verification..." -ForegroundColor Cyan
& ".\venv\Scripts\python.exe" scripts\verify_system.py

Write-Host "`n======================================================================" -ForegroundColor Cyan
Write-Host "  [SUCCESS] All systems ready! Run .\run.bat or .\run.ps1 to launch." -ForegroundColor Green
Write-Host "======================================================================`n" -ForegroundColor Cyan

@echo off
setlocal
cd /d "%~dp0"

echo ======================================================================
echo NETPULSE AI - Starting Application Services
echo ======================================================================
echo.

if not exist "venv\Scripts\python.exe" (
    echo [ERROR] Virtual environment not found!
    echo Please run setup.bat first to set up Python and dependencies.
    pause
    exit /b 1
)

if not exist ".env" (
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo [OK] Created .env from .env.example
    )
)

echo [1/2] Starting Backend API Server (FastAPI on http://localhost:8000)...
start "NETPULSE AI - Backend API" cmd /k "venv\Scripts\python.exe -m uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload"

timeout /t 3 /nobreak >nul

echo [2/2] Starting Frontend UI (Vite on http://localhost:5173)...
start "NETPULSE AI - Frontend UI" cmd /k "cd frontend && npm run dev"

timeout /t 3 /nobreak >nul

echo.
echo ======================================================================
echo Services started!
echo   - Backend Swagger Docs: http://localhost:8000/docs
echo   - Frontend NOC Cockpit: http://localhost:5173
echo ======================================================================
echo Opening browser to http://localhost:5173...

start http://localhost:5173

# Sample Telecom Incident Dataset

This directory contains verified sample operational records from 5G/LTE Network Operations Centers.

## Files
- `sample_telecom_incidents.csv`: 500 representative telemetry records including Cell IDs, Cell Availability (%), Throughput (Mbps), Latency (ms), Packet Drop Rate (%), Alarm Counts, Weather, and Root Cause incident classifications.

## Key Attributes
| Field | Description | Unit / Range |
|---|---|---|
| `incident_id` | Canonical Incident Identifier | `5G-NETOPS-XXXX` |
| `cell_availability` | Radio Cell Up-time Percentage | 0.0 – 100.0% (SLA breach < 95%) |
| `throughput` | User plane downlink throughput | Mbps |
| `latency` | RAN round-trip latency | Milliseconds (Critical > 100 ms) |
| `packet_loss_rate` | Packet drop probability | Percentage (Breach > 5.0%) |
| `critical_alarm_count`| Active Grade-1 alarms | Integer count |
| `weather` | Ambient environmental conditions | Clear, Rain, Snow, Storm |
| `issue_reported` | Telemetry alarm trigger | yes / no |

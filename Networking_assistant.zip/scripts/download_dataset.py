"""
Dataset download and ingestion script for NETPULSE AI.
Strictly downloads and ingests the Hugging Face dataset: fenar/5g_netops.
Ensures zero synthetic data substitution as required by architecture specifications.
"""
import os
import sys
import logging
import pandas as pd

# Add workspace to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.database.dataset_loader import (
    load_hf_dataset,
    HF_DATASET_NAME,
    DEFAULT_RAW_PATH,
    DEFAULT_MAX_RECORDS,
    DEFAULT_SEED
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("download_dataset")

def download_dataset(
    raw_path: str = DEFAULT_RAW_PATH,
    max_records: int = DEFAULT_MAX_RECORDS,
    force_download: bool = True,
    seed: int = DEFAULT_SEED
) -> str:
    """
    Downloads and caches the official fenar/5g_netops dataset from Hugging Face with seeded sampling.
    """
    logger.info("Initiating download for Hugging Face dataset '%s'...", HF_DATASET_NAME)
    df = load_hf_dataset(
        split="train",
        max_records=max_records,
        force_download=force_download,
        raw_cache_path=raw_path,
        seed=seed
    )
    logger.info("Successfully acquired %d records from %s into %s", len(df), HF_DATASET_NAME, raw_path)
    return raw_path

if __name__ == "__main__":
    download_dataset()

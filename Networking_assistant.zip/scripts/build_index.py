"""
Build script for NETPULSE AI:
1. Generates dense embeddings and constructs DenseVectorStore.
2. Builds BM25 keyword index.
3. Trains explainable Random Forest fault risk model and performance prediction regressors.
4. Serializes models and search indices to disk for instantaneous zero-latency startup.
"""
import os
import sys
import logging
import joblib
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split

# Add workspace to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.config import settings
from src.rag.embedder import DenseTelecomEmbedder
from src.rag.vector_store import DenseVectorStore, ChromaVectorStore
from src.rag.bm25_retriever import BM25Retriever

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("build_index")

FEATURE_COLUMNS = [
    "cell_availability", "mttr", "throughput", "latency", "packet_loss_rate",
    "call_drop_rate", "handover_success_rate", "alarm_count", "critical_alarm_count",
    "parameter_changes", "successful_configuration_changes", "data_usage",
    "user_count", "signal_strength", "jitter", "connection_setup_success_rate",
    "security_incidents", "authentication_failures", "temperature", "humidity"
]

def build_search_indices(df: pd.DataFrame, output_path: str = "data/processed/search_indices.pkl"):
    logger.info("Building hybrid search indices for %d records...", len(df))
    documents = df["incident_document"].tolist()
    metadata = df.to_dict(orient="records")
    ids = [str(m.get("incident_id", f"CASE-{1000 + i}")) for i, m in enumerate(metadata)]

    embedder = DenseTelecomEmbedder(n_components=128)
    embedder.fit(documents)
    embeddings = embedder.embed_documents(documents)

    # 1. Initialize and populate persistent ChromaDB collection
    chroma_store = ChromaVectorStore(
        persist_dir=settings.CHROMA_PERSIST_DIR,
        collection_name=settings.CHROMA_COLLECTION_NAME
    )
    chroma_store.index_documents(
        ids=ids,
        documents=documents,
        embeddings=embeddings,
        metadatas=metadata
    )

    # 2. In-memory compatibility adapter
    dense_store = DenseVectorStore(embeddings=embeddings, documents=documents, metadata=metadata)
    bm25 = BM25Retriever(corpus=documents)

    bundle = {
        "embedder": embedder,
        "vector_store": chroma_store,
        "dense_vector_store": dense_store,
        "bm25": bm25
    }

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    joblib.dump(bundle, output_path)
    logger.info("Saved search index bundle to %s (Chroma count: %d)", output_path, chroma_store.count())
    return bundle

def train_ml_models(
    df: pd.DataFrame,
    output_path: str = "data/processed/ml_models.pkl",
    metrics_path: str = "data/processed/ml_metrics.json"
):
    import json
    from sklearn.metrics import roc_auc_score, f1_score, precision_score, recall_score, mean_absolute_error, r2_score

    logger.info("Training explainable ML risk and performance models with train/test split on %d records...", len(df))
    X = df[FEATURE_COLUMNS].copy()
    y_risk = df["high_fault_risk"].values
    y_fault_rate = df["fault_occurrence_rate"].values

    # Train/test split (80/20, seed 42)
    X_train, X_test, y_risk_train, y_risk_test, y_fr_train, y_fr_test = train_test_split(
        X, y_risk, y_fault_rate, test_size=0.20, random_state=42, stratify=y_risk
    )

    # 1. Random Forest Classifier for High Operational Risk
    rf_risk = RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42)
    rf_risk.fit(X_train, y_risk_train)

    y_risk_pred = rf_risk.predict(X_test)
    y_risk_proba = rf_risk.predict_proba(X_test)[:, 1]

    roc_auc = float(roc_auc_score(y_risk_test, y_risk_proba))
    f1 = float(f1_score(y_risk_test, y_risk_pred))
    precision = float(precision_score(y_risk_test, y_risk_pred))
    recall = float(recall_score(y_risk_test, y_risk_pred))

    # 2. Random Forest Regressor for Continuous Fault Occurrence Rate
    rf_reg = RandomForestRegressor(n_estimators=80, max_depth=8, random_state=42)
    rf_reg.fit(X_train, y_fr_train)
    y_fr_pred = rf_reg.predict(X_test)
    fr_mae = float(mean_absolute_error(y_fr_test, y_fr_pred))
    fr_r2 = float(r2_score(y_fr_test, y_fr_pred))

    # 3. Performance Regressors for predicted KPIs
    perf_targets = ["throughput", "latency", "packet_loss_rate", "handover_success_rate"]
    perf_models = {}
    perf_metrics = {}
    for target in perf_targets:
        sub_features = [f for f in FEATURE_COLUMNS if f != target]
        y_target = df[target].values
        X_sub = df[sub_features]
        X_t_train, X_t_test, y_t_train, y_t_test = train_test_split(
            X_sub, y_target, test_size=0.20, random_state=42
        )
        reg = RandomForestRegressor(n_estimators=50, max_depth=6, random_state=42)
        reg.fit(X_t_train, y_t_train)
        y_t_pred = reg.predict(X_t_test)
        perf_mae = float(mean_absolute_error(y_t_test, y_t_pred))
        perf_r2 = float(r2_score(y_t_test, y_t_pred))
        perf_models[target] = {
            "model": reg,
            "features": sub_features
        }
        perf_metrics[target] = {
            "mae": round(perf_mae, 3),
            "r2": round(perf_r2, 3)
        }

    # Extract global feature importances for risk model
    feature_importances = dict(zip(FEATURE_COLUMNS, rf_risk.feature_importances_))
    sorted_importances = sorted(feature_importances.items(), key=lambda item: item[1], reverse=True)

    ml_metrics = {
        "dataset": "fenar/5g_netops",
        "sample_size": len(df),
        "test_size": len(X_test),
        "risk_classifier": {
            "roc_auc": round(roc_auc, 4),
            "f1": round(f1, 4),
            "precision": round(precision, 4),
            "recall": round(recall, 4)
        },
        "fault_regressor": {
            "mae": round(fr_mae, 4),
            "r2": round(fr_r2, 4)
        },
        "performance_models": perf_metrics,
        "feature_importances": [
            {"feature": f, "importance": round(float(imp), 4)}
            for f, imp in sorted_importances
        ]
    }

    os.makedirs(os.path.dirname(metrics_path), exist_ok=True)
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(ml_metrics, f, indent=2)
    logger.info("Saved ML metrics to %s: ROC-AUC=%.4f, F1=%.4f", metrics_path, roc_auc, f1)

    ml_bundle = {
        "feature_columns": FEATURE_COLUMNS,
        "risk_classifier": rf_risk,
        "fault_regressor": rf_reg,
        "performance_models": perf_models,
        "feature_importances": sorted_importances,
        "ml_metrics": ml_metrics
    }

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    joblib.dump(ml_bundle, output_path)
    logger.info("Saved ML models bundle to %s. Top risk factor: %s (%.2f)",
                output_path, sorted_importances[0][0], sorted_importances[0][1])
    return ml_bundle

def main():
    csv_path = settings.PROCESSED_DATA_PATH
    if not os.path.exists(csv_path):
        from scripts.preprocess_dataset import preprocess_dataset
        csv_path = preprocess_dataset()

    df = pd.read_csv(csv_path)
    build_search_indices(df, settings.INDEX_STORAGE_PATH)
    train_ml_models(df, settings.ML_MODELS_PATH)
    logger.info("Build index & ML training pipeline finished successfully!")

if __name__ == "__main__":
    main()

import json
from src.api.routes import initialize_services, get_app_state

initialize_services()
state = get_app_state()
orchestrator = state["orchestrator"]

query = "Cell 104 in North Sector is experiencing high latency of 145ms, 8% packet loss, low throughput of 45 Mbps, and increasing dropped calls at 4.8%"
metrics = {
    "latency": 145.0,
    "packet_loss_rate": 8.0,
    "throughput": 45.0,
    "call_drop_rate": 4.8,
    "cell_availability": 94.2,
    "handover_success_rate": 88.5,
    "critical_alarm_count": 6.0,
    "alarm_count": 14.0
}

res = orchestrator.process_investigation(query=query, direct_metrics=metrics, top_k=3)

print("=== INCIDENT CLASSIFICATION ===")
print("Type:", res['incident']['type'])
print("Severity:", res['incident']['severity'])
print("Confidence:", res['incident']['confidence'])
print("Triggering Factors:", res['incident']['triggering_factors'])

print("\n=== RISK ASSESSMENT ===")
print("Risk Score:", res['risk']['score'])
print("Risk Level:", res['risk']['level'])
print("Deterministic Score:", res['risk']['deterministic_score'])
print("ML Risk Score:", res['risk']['ml_risk_score'])
print("Blend Weights:", res['risk']['blend_weights'])

print("\n=== TOP ROOT CAUSES ===")
for rc in res['root_causes'][:3]:
    print(f"- {rc.get('root_cause')} (Score/Prob: {rc.get('probability', rc.get('score', rc.get('confidence')))})")

print("\n=== TOP RECOMMENDATIONS ===")
for rec in res['recommendations'][:3]:
    print(f"- {rec.get('action', rec.get('recommendation', rec))} [Priority: {rec.get('priority', 'N/A')}]")

print("\n=== SIMILAR HISTORICAL CASES ===")
for c in res['similar_cases'][:3]:
    reasons = c.get('match_reasons', [])[:2]
    print(f"- Case {c.get('incident_id')}: Sim={c.get('similarity_score')} | Rerank={c.get('rerank_score')} | Issue={c.get('issue_reported')}")
    safe_reasons = [str(r).encode('ascii', 'ignore').decode() for r in reasons]
    print(f"  Match Reasons: {safe_reasons}")

print("\n=== AGENT TRACE ===")
for tr in res['agent_trace']:
    print(f"Step {tr['step']}: {tr['agent']} ({tr['action']}) - Latency: {tr['latency_seconds']}s")

print("\n=== TOTAL METRICS ===")
print("Latency breakdown:", res['metadata'])

# Also save full result to a JSON for reference
with open("evaluation/results/representative_incident_run.json", "w", encoding="utf-8") as f:
    json.dump(res, f, indent=2)
print("\nSaved full result to evaluation/results/representative_incident_run.json")

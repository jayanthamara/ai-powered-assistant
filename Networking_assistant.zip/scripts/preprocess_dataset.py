"""
Robust dataset preprocessing pipeline for NETPULSE AI.
Strictly processes Hugging Face dataset: fenar/5g_netops.
Normalizes columns, imputes missing values, validates schemas, engineers derived features,
computes empirical thresholds, and generates narrative incident documents.
"""
import os
import sys
import logging
from typing import Dict, List, Tuple, Optional
import pandas as pd
import numpy as np

# Add workspace to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.database.dataset_loader import (
    CANONICAL_COLUMNS,
    NUMERIC_COLUMNS,
    CATEGORICAL_COLUMNS,
    clean_column_name,
    normalize_dataframe as normalize_dataframe_columns,
    build_incident_narrative,
    compute_deterministic_severity,
    compute_and_save_thresholds,
    prepare_application_dataset,
    DEFAULT_RAW_PATH,
    DEFAULT_PROCESSED_PATH,
    DEFAULT_MAX_RECORDS
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("preprocess_dataset")

def find_raw_csv(raw_dir: str = "data/raw") -> Optional[str]:
    """Find candidate raw CSV in data/raw."""
    if not os.path.exists(raw_dir):
        return None
    files = [os.path.join(raw_dir, f) for f in os.listdir(raw_dir) if f.endswith(".csv")]
    if not files:
        return None
    for f in files:
        if "5g" in f.lower() or "netops" in f.lower():
            return f
    return files[0]

def preprocess_dataset(
    raw_path: Optional[str] = None,
    output_path: str = DEFAULT_PROCESSED_PATH
) -> str:
    """Main ingestion and preprocessing pipeline using fenar/5g_netops."""
    if raw_path and os.path.exists(raw_path):
        logger.info("Ingesting specified raw dataset from %s", raw_path)
        df_raw = pd.read_csv(raw_path)
        df = normalize_dataframe_columns(df_raw)

        if "dataset_record_idx" not in df.columns:
            df["dataset_record_idx"] = list(range(len(df)))
        if "source_dataset" not in df.columns:
            df["source_dataset"] = "fenar/5g_netops"
        if "incident_id" not in df.columns:
            df["incident_id"] = [f"5G-NETOPS-{1000 + i}" for i in range(len(df))]
        else:
            df["incident_id"] = df["incident_id"].astype(str)

        for col in NUMERIC_COLUMNS:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
                med = df[col].median()
                df[col] = df[col].fillna(med if not np.isnan(med) else 0.0)
            else:
                df[col] = 0.0

        for col in CATEGORICAL_COLUMNS:
            if col in df.columns:
                df[col] = df[col].fillna("Unknown").astype(str)
            else:
                df[col] = "Unknown"

        # Compute data-driven thresholds
        thresholds = compute_and_save_thresholds(df)
        p75_fault = thresholds.get("high_fault_risk_cutoff", 48.28)

        df["cell_load_index"] = (df["user_count"] * df["data_usage"] / 1000.0).round(2)
        df["alarm_severity_ratio"] = (df["critical_alarm_count"] / df["alarm_count"].replace(0, 1)).round(3)
        df["severity"] = df.apply(compute_deterministic_severity, axis=1)
        df["high_fault_risk"] = (df["fault_occurrence_rate"] >= p75_fault).astype(int)
        df["incident_document"] = df.apply(lambda r: build_incident_narrative(r, thresholds), axis=1)

        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        df.to_csv(output_path, index=False)
        logger.info("Preprocessed %d records from %s into %s", len(df), raw_path, output_path)
        return output_path

    # Otherwise prepare directly from fenar/5g_netops
    logger.info("Preparing application dataset from fenar/5g_netops...")
    prepare_application_dataset(max_records=DEFAULT_MAX_RECORDS, output_path=output_path)
    return output_path

if __name__ == "__main__":
    preprocess_dataset()
